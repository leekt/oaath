import { TransportError } from '../errors.js'
import type { Transport, RpcRequest, RequestOptions } from '../types.js'
import { createReadBatch } from '../internal/readBatch.js'
import { createNodeHttp, type HttpNodeOptions } from './internal/nodeHttp.js'

export type HttpBatchNodeOptions = HttpNodeOptions & { maxSize?: number }

/** Opt-in bounded Node read batching. Writes and held receipt calls remain direct. */
export function httpBatchNode(
  address: string,
  options: HttpBatchNodeOptions = {},
): Transport & { close(): void } {
  const maximum = options.maxPending ?? 1024
  const connection = createNodeHttp(address, options)
  const batch = createReadBatch(
    connection,
    (body, signal) =>
      connection.request({ method: 'JSON-RPC batch' }, { signal }, body),
    options,
  )
  const retained = new Set<AbortController>()
  let closed = false
  return {
    close() {
      if (closed) return
      closed = true
      const reason = new TransportError('Transport is closed.')
      for (const controller of retained) controller.abort(reason)
      connection.close()
    },
    request<T>(rpc: RpcRequest, options?: RequestOptions): Promise<T> {
      const signal = options?.signal
      if (closed)
        return Promise.reject(new TransportError('Transport is closed.'))
      if (signal?.aborted) return Promise.reject(signal.reason)
      if (retained.size >= maximum)
        return Promise.reject(
          new TransportError('Transport request capacity exceeded.'),
        )
      // Reserve before serialization, including caller toJSON reentrancy.
      const controller = new AbortController()
      retained.add(controller)
      const abort = () => controller.abort(signal!.reason)
      signal?.addEventListener('abort', abort, { once: true })
      return batch
        .request<T>(rpc, { signal: controller.signal }, () => {
          retained.delete(controller)
        })
        .finally(() => {
          signal?.removeEventListener('abort', abort)
        })
    },
  }
}
