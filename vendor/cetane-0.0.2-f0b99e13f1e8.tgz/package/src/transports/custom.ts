import type { RpcRequest, Transport } from '../types.js'

/** Accepts an EIP-1193 provider or an in-process request function. */
export function custom(provider: {
  request(request: RpcRequest): Promise<unknown>
}): Transport {
  return {
    request: (request, options) => {
      options?.signal?.throwIfAborted()
      return provider.request(request) as ReturnType<Transport['request']>
    },
  } as Transport
}
