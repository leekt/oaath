import { CetaneError } from './errors.js'
import { createHashingEnabler } from './internal/hashing.js'
import { createNativeKeccakBackend } from './internal/nativeHashing/backend.js'

/**
 * Experimental Darwin arm64 Keccak hashing, loaded and verified on first use.
 * A successful subsequent call synchronously reselects this module's verified
 * backend and returns the original setup promise. Concurrent cold backends are
 * installed in verification-completion order; the last completion wins.
 */
export const enableNativeHashing = createHashingEnabler(async () => {
  const runtime = (
    globalThis as typeof globalThis & {
      process?: { platform?: string; arch?: string }
    }
  ).process
  if (runtime?.platform !== 'darwin' || runtime.arch !== 'arm64')
    throw new CetaneError(
      'Native hashing currently supports Darwin arm64 only.',
    )
  const { loadAddon } = await import('./internal/nativeHashing/node.js')
  return createNativeKeccakBackend(await loadAddon())
})
