import { CetaneError } from './errors.js'
import type {
  Account,
  Chain,
  Client,
  Sponsor,
  SponsorContext,
  Signer,
  NativeAA,
  Request,
  Transport,
} from './types.js'
import { fromQuantity } from './utils/hex.js'
import { preserveIdentity } from './internal/identity.js'
import { getDefaultTrace } from './internal/defaultTrace.js'
import {
  scopeContext,
  startOperation,
  traceAsync,
  traceSync,
} from './internal/trace.js'
import type { TraceSink } from './trace/types.js'

/** Internal identity survives action decorators without a public client ID. */
export { identity } from './internal/identity.js'

export type ClientParameters = {
  /** Stage timings override registered defaults; false disables tracing for this client. */
  trace?: TraceSink | false
  chain?: Chain
  transport: Transport
  relay?: Transport
  account?: Account
  signer?: Signer
  sponsor?: Sponsor
  sponsorContext?: SponsorContext
  pollingInterval?: number
  /** Injectable until native-AA capability discovery has a stable RPC. Defaults to unknown. */
  discoverNativeAA?: (parameters: {
    chainId: number
    request: Request
  }) => Promise<NativeAA | false | 'unknown'>
}

export function createClient(parameters: ClientParameters): Client {
  const { transport, account } = parameters
  const request = transport.request.bind(transport)
  const discoverNativeAA = parameters.discoverNativeAA
  let chainId = parameters.chain?.id
  if (chainId !== undefined && (!Number.isSafeInteger(chainId) || chainId <= 0))
    throw new CetaneError('Invalid chain ID.')
  const submission = parameters.chain?.submission
  if (submission) {
    if (
      submission.maxSigning !== undefined &&
      (!Number.isSafeInteger(submission.maxSigning) ||
        submission.maxSigning < 1 ||
        submission.maxSigning > submission.maxInFlight)
    )
      throw new CetaneError(
        'Submission maxSigning must be a positive safe integer no greater than maxInFlight.',
      )
    if (
      (submission.maxSigning ?? 1) > 1 &&
      !parameters.chain?.execution?.supportsParallelSigning
    )
      throw new CetaneError(
        'This execution module does not support parallel signing.',
      )
    if (
      !Number.isSafeInteger(submission.maxInFlight) ||
      submission.maxInFlight < 1
    )
      throw new CetaneError(
        'Submission maxInFlight must be a positive safe integer.',
      )
    if (
      submission.maxQueued !== undefined &&
      (!Number.isSafeInteger(submission.maxQueued) || submission.maxQueued < 0)
    )
      throw new CetaneError(
        'Submission maxQueued must be a nonnegative safe integer.',
      )
    if (
      !Number.isSafeInteger(
        submission.maxInFlight + (submission.maxQueued ?? 1024),
      )
    )
      throw new CetaneError('Submission capacity exceeds a safe integer.')
    if (
      submission.maxInFlight > 1 &&
      !parameters.chain?.execution?.supportsNoncePipelining
    )
      throw new CetaneError(
        'This execution module does not support nonce pipelining.',
      )
  }
  const chain: Chain = Object.freeze(
    parameters.chain
      ? {
          ...parameters.chain,
          id: chainId!,
          ...(parameters.chain.fees
            ? { fees: Object.freeze({ ...parameters.chain.fees }) }
            : {}),
          ...(parameters.chain.limits
            ? { limits: Object.freeze({ ...parameters.chain.limits }) }
            : {}),
          ...(submission
            ? { submission: Object.freeze({ ...submission }) }
            : {}),
        }
      : {
          get id() {
            if (chainId === undefined)
              throw new CetaneError(
                'Await client.ready before accessing a discovered chain ID.',
              )
            return chainId
          },
          name: 'Discovered chain',
        },
  )
  const pollingInterval =
    parameters.pollingInterval ?? chain.pollingInterval ?? 1_000
  if (!Number.isFinite(pollingInterval) || pollingInterval <= 0)
    throw new CetaneError('Polling interval must be positive.')
  const trace =
    parameters.trace === false
      ? undefined
      : parameters.trace
        ? { sink: parameters.trace, operationId: 0 }
        : getDefaultTrace()
  const initialization = trace
    ? startOperation(
        { chain, request, relay: request, trace },
        'client.initialize',
      )
    : undefined
  const initializationContext = initialization?.context
  const idReady =
    chainId !== undefined
      ? Promise.resolve(
          initializationContext
            ? traceSync(
                initializationContext.trace,
                'metadata.chain_id',
                () => chainId!,
                { source: 'configured' },
              )
            : chainId,
        )
      : (initializationContext
          ? traceAsync(
              initializationContext.trace,
              'metadata.chain_id',
              (span) =>
                scopeContext(initializationContext, span).request({
                  method: 'eth_chainId',
                }),
              { source: 'rpc' },
            )
          : request({ method: 'eth_chainId' })
        ).then((value) => {
          const id = Number(fromQuantity(value))
          if (!Number.isSafeInteger(id) || id <= 0)
            throw new CetaneError('Invalid RPC chain ID.')
          return (chainId = id)
        })
  const ready = idReady.then(async (id) =>
    Object.freeze({
      chainId: id,
      nativeAA: initializationContext
        ? await traceAsync(
            initializationContext.trace,
            'metadata.native_aa',
            async (span) =>
              chain.nativeAA ??
              (await discoverNativeAA?.({
                chainId: id,
                request: scopeContext(initializationContext, span).request,
              })) ??
              'unknown',
            {
              source:
                chain.nativeAA !== undefined
                  ? 'configured'
                  : discoverNativeAA
                    ? 'discovery'
                    : 'mock',
            },
          )
        : (chain.nativeAA ??
          (await discoverNativeAA?.({
            chainId: id,
            request,
          })) ??
          ('unknown' as const)),
    }),
  )
  if (initialization)
    void ready.then(
      () => initialization.span.end(),
      () => initialization.span.end('error'),
    )
  // Initialization starts immediately, but consumers observe errors through ready/actions.
  void ready.catch(() => {})
  const client: Client = {
    ...(trace ? { trace } : {}),
    ready,
    chain,
    request,
    relay: parameters.relay
      ? parameters.relay.request.bind(parameters.relay)
      : request,
    ...(account ? { account } : {}),
    ...(parameters.signer ? { signer: parameters.signer } : {}),
    ...(parameters.sponsor ? { sponsor: parameters.sponsor } : {}),
    ...(parameters.sponsorContext
      ? { sponsorContext: parameters.sponsorContext }
      : {}),
    pollingInterval,
    extend(extension) {
      const additions = extension(this)
      for (const key of Object.keys(additions)) {
        if (key in this)
          throw new CetaneError(`Extension cannot replace ${key}.`)
      }
      const extended = Object.assign(
        Object.create(Object.getPrototypeOf(this)),
        this,
        additions,
      )
      preserveIdentity(this, extended)
      return extended
    },
  }
  preserveIdentity(client, client)
  chain.setup?.(client)
  return client
}

/** Preserves literal chain fields; no registry or automatic chain probing. */
export function defineChain<const T extends Chain>(chain: T): T {
  if (!Number.isSafeInteger(chain.id) || chain.id <= 0)
    throw new CetaneError('Invalid chain ID.')
  return Object.freeze(chain)
}
