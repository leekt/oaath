import { RpcError, TimeoutError, TransportError } from '../errors.js'
import type { Transport, RpcRequest, RequestOptions } from '../types.js'
import { validateReply, type Reply } from './rpcReply.js'

// Explicit read allowlist. Unknown/custom methods and every write go directly to
// fetch, so batching cannot alter transaction submission ordering or admission.
const batchable = new Set([
  'eth_chainId',
  'net_version',
  'eth_blockNumber',
  'eth_call',
  'eth_estimateGas',
  'eth_gasPrice',
  'eth_maxPriorityFeePerGas',
  'eth_feeHistory',
  'eth_getBalance',
  'eth_getCode',
  'eth_getStorageAt',
  'eth_getTransactionCount',
  'eth_getBlockByHash',
  'eth_getBlockByNumber',
  'eth_getTransactionByHash',
  'eth_getTransactionReceipt',
  'eth_getLogs',
  'eth_getProof',
  'eth_supportedEntryPoints',
  'eth_estimateUserOperationGas',
  'eth_getUserOperationReceipt',
  'eth_getUserOperationByHash',
  'pimlico_getUserOperationGasPrice',
])

type BatchState = {
  controller: AbortController
  active: number
  complete: boolean
}
type BatchEntry = {
  id: number
  method: string
  body: string
  done: boolean
  state?: BatchState
  retire?: () => void
  finish(success: boolean, value: unknown): void
}

/** Shared JSON-RPC read batching; lifecycle retirement is internal to bounded backends. */
export function createReadBatch(
  direct: Transport,
  send: (body: string, signal: AbortSignal) => Promise<unknown>,
  options: { timeout?: number; maxSize?: number } = {},
) {
  const timeout = options.timeout ?? 10_000
  if (!Number.isFinite(timeout) || timeout <= 0)
    throw new TransportError('HTTP timeout must be positive.')
  const maxSize = options.maxSize ?? 20
  if (!Number.isSafeInteger(maxSize) || maxSize < 2 || maxSize > 1_024)
    throw new TransportError(
      'HTTP batch maxSize must be an integer from 2 to 1024.',
    )
  let id = 0
  let queued: BatchEntry[] = []
  let scheduled = false

  function flush() {
    const entries = queued.filter((entry) => !entry.done)
    queued = []
    if (!entries.length) return
    void dispatch(entries)
  }

  async function dispatch(entries: BatchEntry[]) {
    const state: BatchState = {
      controller: new AbortController(),
      active: entries.length,
      complete: false,
    }
    for (const entry of entries) entry.state = state
    try {
      const body = await send(
        entries.length === 1
          ? entries[0]!.body
          : `[${entries.map((entry) => entry.body).join(',')}]`,
        state.controller.signal,
      )
      const responses = entries.length === 1 ? [body] : body
      if (!Array.isArray(responses) || responses.length !== entries.length)
        throw new TransportError('Invalid JSON-RPC batch response.')
      const pending = new Map(entries.map((entry) => [entry.id, entry]))
      const results: { entry: BatchEntry; reply: Reply }[] = []
      // Validate the complete envelope before resolving anything. Duplicate,
      // missing and unknown IDs invalidate the batch instead of misrouting data.
      for (const data of responses) {
        const entry =
          data && typeof data === 'object' ? pending.get(data.id) : undefined
        if (!entry)
          throw new TransportError('Invalid JSON-RPC batch response ID.')
        const reply = validateReply(data, entry.id, entry.method)
        pending.delete(entry.id)
        results.push({ entry, reply })
      }
      state.complete = true
      for (const { entry, reply } of results)
        entry.finish(
          !reply.error,
          reply.error ? new RpcError(entry.method, reply.error) : reply.result,
        )
    } catch (cause) {
      state.complete = true
      const error =
        cause instanceof TransportError
          ? cause
          : new TransportError('JSON-RPC batch request failed.', { cause })
      for (const entry of entries) entry.finish(false, error)
    } finally {
      for (const entry of entries) entry.retire?.()
    }
  }

  function enqueue<T>(
    requestId: number,
    method: string,
    body: string,
    signal?: AbortSignal,
    retire?: () => void,
  ): Promise<T> {
    signal?.throwIfAborted()
    return new Promise((resolve, reject) => {
      const abort = signal
        ? () => entry.finish(false, signal.reason)
        : undefined
      const timer = setTimeout(
        () => entry.finish(false, new TimeoutError(`${method} timed out.`)),
        timeout,
      )
      const entry: BatchEntry = {
        id: requestId,
        method,
        body,
        done: false,
        ...(retire ? { retire } : {}),
        finish(success, value) {
          if (entry.done) return
          entry.done = true
          clearTimeout(timer)
          if (abort) signal!.removeEventListener('abort', abort)
          if (success) resolve(value as T)
          else reject(value)
          const state = entry.state
          if (!state) {
            const index = queued.indexOf(entry)
            if (index >= 0) queued.splice(index, 1)
            entry.retire?.()
          }
          if (state && --state.active === 0 && !state.complete)
            state.controller.abort(value)
        },
      }
      if (abort) signal!.addEventListener('abort', abort, { once: true })
      queued.push(entry)
      if (queued.length === maxSize) flush()
      else if (!scheduled) {
        scheduled = true
        queueMicrotask(() => {
          scheduled = false
          flush()
        })
      }
    })
  }

  return {
    async request<T>(
      request: RpcRequest,
      requestOptions?: RequestOptions,
      retire?: () => void,
    ): Promise<T> {
      try {
        // Property access can invoke caller getters. Keep it inside the
        // retirement boundary so a thrown getter releases reserved capacity.
        const { method, params = [] } = request
        // Writes, unknown calls and held-receipt extensions bypass batching.
        if (
          !batchable.has(method) ||
          ((method === 'eth_getUserOperationReceipt' ||
            method === 'eth_getTransactionReceipt') &&
            params.length > 1)
        ) {
          const result = direct.request<T>({ method, params }, requestOptions)
          return retire ? result.finally(retire) : result
        }
        const requestId = ++id
        const signal = requestOptions?.signal
        signal?.throwIfAborted()
        let body: string
        try {
          body = JSON.stringify({
            jsonrpc: '2.0',
            id: requestId,
            method,
            params,
          })
        } catch (cause) {
          throw new TransportError(`Request failed for ${method}.`, { cause })
        }
        return enqueue<T>(requestId, method, body, signal, retire)
      } catch (cause) {
        retire?.()
        throw cause
      }
    },
  }
}
