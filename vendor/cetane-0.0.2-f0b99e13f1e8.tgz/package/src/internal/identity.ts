import type { Client, Request } from '../types.js'

const clients = new WeakMap<Client, object>()
const requests = new WeakMap<Request, Request>()

/** Decorators and operation scopes share the original client's nonce/preparation identity. */
export function identity(client: Client): object {
  return clients.get(client) ?? client
}

export function preserveIdentity(source: Client, target: Client): void {
  clients.set(target, identity(source))
}

/** Cache identity is independent of the wrapper that supplies per-operation RPC timings. */
export function requestIdentity(request: Request): Request {
  return requests.get(request) ?? request
}

export function preserveRequestIdentity(
  source: Request,
  target: Request,
): void {
  requests.set(target, requestIdentity(source))
}
