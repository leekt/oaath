import { abytes } from '@noble/hashes/utils.js'
import { bytesToHex, hexToBytes, withHexBytes } from '../../utils/bytes.js'
import type { Hash } from '../../types.js'
import type { KeccakBackend } from '../hashing.js'
import type { NativeKeccakAddon } from './types.js'

const set = Uint8Array.prototype.set
const empty = new Uint8Array()
const ordinaryByteLength = Object.getOwnPropertyDescriptor(
  ArrayBuffer.prototype,
  'byteLength',
)!.get!
const resizable = Object.getOwnPropertyDescriptor(
  ArrayBuffer.prototype,
  'resizable',
)?.get

function fixed(view: Uint8Array): Uint8Array {
  // This only receives a plain local view after every caller property was read.
  // Intrinsic getters work across realms and do not consult a caller's property.
  try {
    if (
      resizable
        ? !resizable.call(view.buffer)
        : (ordinaryByteLength.call(view.buffer), true)
    )
      return view
  } catch {
    // A shared backing store fails the ordinary ArrayBuffer intrinsic check.
  }
  // RAB/SAB storage is copied into an owned fixed buffer; no species hook or
  // caller iterator/subarray method is invoked. set also rejects invalid views.
  const owned = new Uint8Array(view.byteLength)
  set.call(owned, view)
  return owned
}

export function createNativeKeccakBackend(
  addon: NativeKeccakAddon,
): KeccakBackend {
  if (!addon || typeof addon.hash !== 'function')
    throw Error('Invalid native Keccak addon.')
  const trusted = (head: Uint8Array, tail?: Uint8Array): Hash => {
    const digest =
      tail === undefined ? addon.hash(head) : addon.hash(head, tail)
    if (
      typeof digest !== 'string' ||
      digest.length !== 66 ||
      !/^0x[0-9a-f]{64}$/.test(digest)
    )
      throw Error('Invalid native Keccak digest.')
    return digest
  }
  const normalized = (first: Uint8Array, second?: Uint8Array): Hash => {
    abytes(first)
    if (second !== undefined) abytes(second)
    // Reject already-OOB originals before their offset/length can collapse to0.
    set.call(first, empty)
    if (second !== undefined) set.call(second, empty)
    const head = new Uint8Array(
      first.buffer,
      first.byteOffset,
      first.byteLength,
    )
    const tail =
      second === undefined
        ? undefined
        : new Uint8Array(second.buffer, second.byteOffset, second.byteLength)
    // A second-view getter may have resized/detached head's buffer. Empty set
    // performs intrinsic typed-array validation even if an OOB view reports0.
    set.call(first, empty)
    if (second !== undefined) set.call(second, empty)
    set.call(head, empty)
    if (tail !== undefined) set.call(tail, empty)
    return trusted(fixed(head), tail === undefined ? undefined : fixed(tail))
  }
  const hash: KeccakBackend = (value, second) =>
    typeof value === 'string' && second === undefined
      ? withHexBytes(value, trusted, normalized)
      : normalized(
          typeof value === 'string' ? hexToBytes(value) : value,
          second,
        )
  const sample = Uint8Array.from({ length: 273 }, (_, i) => (i * 17 + 3) & 255)
  const emptyHash =
    '0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
  const sampleHash =
    '0x21cdfe1022deefc98568fe3b6fa178e231ea59b445b5118d162f018dac5610be'
  if (
    hash(empty) !== emptyHash ||
    hash('0x') !== emptyHash ||
    hash(sample) !== sampleHash ||
    hash(bytesToHex(sample)) !== sampleHash ||
    hash(sample.subarray(0, 135), sample.subarray(135)) !== sampleHash ||
    hash(empty) !== emptyHash
  )
    throw Error('Native Keccak self-test failed.')
  return hash
}
