import { CetaneError } from '../errors.js'
import type {
  Account,
  Hash,
  Hex,
  Signer,
  TransactionParameters,
  Awaitable,
} from '../types.js'

export function signTransaction(
  account: Account,
  parameters: TransactionParameters,
  hash: Hash,
  signer?: Signer,
): Awaitable<Hex> {
  try {
    signer ??= parameters.signer
    if (!signer)
      throw new CetaneError(
        'A signer is required to authorize this transaction.',
      )
    return account.signTransaction
      ? account.signTransaction({
          hash,
          signer,
          ...(parameters.authorization
            ? { authorization: parameters.authorization }
            : {}),
        })
      : signer.sign({ hash })
  } catch (error) {
    // Keep sibling authorizations reachable during Promise.all argument evaluation.
    return Promise.reject(error)
  }
}
