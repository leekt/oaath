import { CetaneError } from '../errors.js'
import { createNativeLoader } from './internal/native/loader.js'
import { createNativeSigner } from './internal/native/signer.js'

const load = createNativeLoader(async () => {
  const runtime = (
    globalThis as typeof globalThis & {
      process?: { platform?: string; arch?: string }
    }
  ).process
  if (runtime?.platform !== 'darwin' || runtime.arch !== 'arm64')
    throw new CetaneError(
      'Native signing currently supports Darwin arm64 only.',
    )
  return (await import('./internal/native/node.js')).loadAddon()
})

/** Experimental Darwin arm64 signer; loads the packaged addon on first use. */
export const privateKeyToSigner = createNativeSigner(load)

/** Signing capability remains independent of the transaction/account address. */
export const privateKeyToAccount = privateKeyToSigner
