import { CetaneError } from '../errors.js'
import type { AccountFactory, Address, Hex } from '../types.js'
import { encodeAbiParameters } from '../utils/abi.js'
import { hashMessage } from '../utils/hash.js'
import { addressWord, assertHex, word } from '../utils/hex.js'
import { readDeploymentCode } from './internal/deployment.js'

const executeArgs = [
  { type: 'address' },
  { type: 'uint256' },
  { type: 'bytes' },
] as const
const batchArgs = [
  { type: 'address[]' },
  { type: 'uint256[]' },
  { type: 'bytes[]' },
] as const
// A recoverable R point (the generator's x coordinate), low S, and no zero
// bytes. Invalid curve points make OpenZeppelin ECDSA.recover revert during
// estimation instead of returning the account's expected validation failure.
const stub: Hex = `0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798${'7f'.repeat(32)}1b`

/** Infrastructure configuration. Applications use createAccount. */
export function defineAccount(
  options: { factory?: Address } = {},
): AccountFactory {
  return async ({ owner, client, address, index = 0n }) => {
    if (index < 0n) throw new CetaneError('Account index cannot be negative.')
    if (options.factory && !owner)
      throw new CetaneError(
        'Factory deployment requires a public owner address.',
      )
    const args = owner ? addressWord(owner) + word(index) : ''
    let resolved = address
    if (!resolved) {
      if (!options.factory)
        throw new CetaneError(
          'Provide an account address or configure a factory on the chain.',
        )
      const result = await client.request<Hex>({
        method: 'eth_call',
        params: [{ to: options.factory, data: `0x8cb84e18${args}` }, 'latest'],
      })
      assertHex(result, 32)
      resolved = `0x${result.slice(-40)}`
    }
    const accountAddress = resolved
    return {
      address: accountAddress,
      signTransaction: ({ hash, signer }) =>
        signer.sign({ hash: hashMessage({ raw: hash }) }),
      stubSignature: stub,
      encodeCalls(calls) {
        if (calls.length === 1) {
          const call = calls[0]!
          return `0xb61d27f6${encodeAbiParameters(executeArgs, [call.to, call.value ?? 0n, call.data ?? '0x']).slice(2)}`
        }
        return `0x47e1da2a${encodeAbiParameters(batchArgs, [calls.map((c) => c.to), calls.map((c) => c.value ?? 0n), calls.map((c) => c.data ?? '0x')]).slice(2)}`
      },
      async getDeployment(context) {
        if (!options.factory) return undefined
        const code = await readDeploymentCode(context, accountAddress, 'latest')
        if (code !== '0x') return undefined
        return { factory: options.factory, data: `0x5fbfb9cf${args}` }
      },
    }
  }
}
