import { CetaneError } from '../../../errors.js'
import { bytesToHex, hexToBytes } from '../../../utils/bytes.js'
import type { NativeAddon, NativeSigner } from './types.js'

export function randomize(seed: Uint8Array<ArrayBuffer>): void {
  if (typeof globalThis.crypto?.getRandomValues !== 'function')
    throw new CetaneError('Native signing requires crypto.getRandomValues.')
  globalThis.crypto.getRandomValues(seed)
}

function verify(candidate: NativeAddon): NativeAddon {
  if (!candidate || typeof candidate.createSigner !== 'function')
    throw new CetaneError('Invalid native secp256k1 addon.')
  const key = new Uint8Array(32)
  key[31] = 1
  const seed = new Uint8Array(32)
  let signer: NativeSigner | undefined
  try {
    randomize(seed)
    signer = candidate.createSigner(key, seed)
    const publicKey =
      '0x0479be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798' +
      '483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8'
    const signature =
      '0xa0b37f8fba683cc68f6574cd43b39f0343a50008bf6ccea9d13231d9e7e2e1e4' +
      '11edc8d307254296264aebfc3dc76cd8b668373a072fd64665b50000e9fcce521c'
    const order = hexToBytes(
      '0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141',
    )
    if (
      bytesToHex(signer.publicKey()) !== publicKey ||
      bytesToHex(signer.sign(new Uint8Array(32))) !== signature ||
      bytesToHex(signer.sign(order)) !== signature
    )
      throw new CetaneError('Native secp256k1 self-test failed.')
    return candidate
  } finally {
    try {
      signer?.dispose()
    } finally {
      key.fill(0)
      seed.fill(0)
    }
  }
}

/** Cache only successful known-answer validation; failed initialization can retry. */
export function createNativeLoader(load: () => Promise<NativeAddon>) {
  let setup: Promise<NativeAddon> | undefined
  return function loadNative(): Promise<NativeAddon> {
    return (setup ??= Promise.resolve()
      .then(load)
      .then(verify)
      .catch((error: unknown) => {
        setup = undefined
        throw error
      }))
  }
}
