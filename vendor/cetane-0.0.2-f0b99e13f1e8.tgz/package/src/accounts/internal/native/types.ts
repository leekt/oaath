export type NativeSigner = {
  publicKey(): Uint8Array
  sign(message: Uint8Array): Uint8Array
  dispose(): void
}

export type NativeAddon = {
  createSigner(key: Uint8Array, seed: Uint8Array): NativeSigner
}
