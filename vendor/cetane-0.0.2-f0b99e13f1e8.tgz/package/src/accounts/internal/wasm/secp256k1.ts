import { CetaneError } from '../../../errors.js'
import { bytesToHex, hexToBytes } from '../../../utils/bytes.js'

type Secp256k1Exports = {
  memory: WebAssembly.Memory
  _initialize(): void
  buffer(): number
  initialize(): number
  public_key(): number
  sign(): number
  wipe(): void
}
export type Secp256k1State = { exports: Secp256k1Exports; io: Uint8Array }
type BinaryLoader = () => Promise<{ wasmBase64: string }>

function selfTest({ exports, io }: Secp256k1State): void {
  const key = new Uint8Array(32)
  key[31] = 1
  const order = hexToBytes(
    '0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141',
  )
  const publicKey =
    '0x0479be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798' +
    '483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8'
  const signature =
    '0xa0b37f8fba683cc68f6574cd43b39f0343a50008bf6ccea9d13231d9e7e2e1e4' +
    '11edc8d307254296264aebfc3dc76cd8b668373a072fd64665b50000e9fcce521c'
  const fail = () => {
    throw new CetaneError('WASM secp256k1 self-test failed.')
  }
  try {
    io.set(key)
    if (
      exports.public_key() !== 1 ||
      bytesToHex(io.subarray(64, 129)) !== publicKey
    )
      fail()
    // RFC 6979 bits2octets reduces n to zero. Both messages must produce the
    // same independently checked, low-S recoverable signature for key 1.
    for (const message of [new Uint8Array(32), order]) {
      exports.wipe()
      io.set(key)
      io.set(message, 32)
      if (
        exports.sign() !== 1 ||
        bytesToHex(io.subarray(64, 129)) !== signature
      )
        fail()
    }
    for (const invalid of [new Uint8Array(32), order]) {
      exports.wipe()
      io.set(invalid)
      if (exports.public_key() !== 0) fail()
      io.set(invalid)
      if (exports.sign() !== 0) fail()
    }
  } finally {
    exports.wipe()
  }
}

async function initialize(loadBinary: BinaryLoader): Promise<Secp256k1State> {
  if (
    typeof globalThis.crypto?.getRandomValues !== 'function' ||
    typeof WebAssembly === 'undefined'
  )
    throw new CetaneError(
      'WASM signing requires WebAssembly and crypto.getRandomValues.',
    )
  const { wasmBase64 } = await loadBinary()
  const encoded = atob(wasmBase64)
  const binary = Uint8Array.from(encoded, (character) =>
    character.charCodeAt(0),
  )
  const module = await WebAssembly.compile(binary)
  const imports = WebAssembly.Module.imports(module)
  if (
    imports.length !== 1 ||
    imports[0]!.module !== 'wasi_snapshot_preview1' ||
    imports[0]!.name !== 'random_get' ||
    imports[0]!.kind !== 'function'
  )
    throw new CetaneError('Unexpected WASM secp256k1 imports.')
  let exports: Secp256k1Exports | undefined
  const instance = await WebAssembly.instantiate(module, {
    wasi_snapshot_preview1: {
      // WASI libc's reactor initialization seeds its stack-protection canary.
      // No WASI filesystem, process, clock, or network imports are provided.
      random_get(pointer: number, length: number) {
        if (!exports)
          throw new CetaneError(
            'WASM requested randomness before initialization.',
          )
        globalThis.crypto.getRandomValues(
          new Uint8Array(exports.memory.buffer, pointer, length),
        )
        return 0
      },
    },
  })
  exports = instance.exports as Secp256k1Exports
  exports._initialize()
  const io = new Uint8Array(exports.memory.buffer, exports.buffer(), 161)
  const seed = new Uint8Array(32)
  try {
    globalThis.crypto.getRandomValues(seed)
    io.set(seed, 129)
    if (exports.initialize() !== 1)
      throw new CetaneError('Unable to initialize WASM secp256k1 context.')
  } finally {
    seed.fill(0)
    exports.wipe()
  }
  const state = { exports, io }
  selfTest(state)
  return state
}

/** Each leaf owns a lazy context and retries independently after failed setup. */
export function createSecp256k1Loader(loadBinary: BinaryLoader) {
  let setup: Promise<Secp256k1State> | undefined
  return function loadSecp256k1(): Promise<Secp256k1State> {
    return (setup ??= initialize(loadBinary).catch((error: unknown) => {
      setup = undefined
      throw error
    }))
  }
}
