import { createSecp256k1Loader } from '../internal/wasm/secp256k1.js'
import { createWasmSigner } from '../internal/wasm/signer.js'

/** Experimental 86 KiB-table signer; 192 KiB fixed WASM memory after setup. */
export const privateKeyToSigner = createWasmSigner(
  createSecp256k1Loader(
    () => import('../internal/wasm/secp256k1-large.wasm.js'),
  ),
)

/** A key supplies signing capability, not a smart account identity. */
export const privateKeyToAccount = privateKeyToSigner
