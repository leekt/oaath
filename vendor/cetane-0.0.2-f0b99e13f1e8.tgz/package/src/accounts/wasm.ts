import { createSecp256k1Loader } from './internal/wasm/secp256k1.js'
import { createWasmSigner } from './internal/wasm/signer.js'

/** Optional 22 KiB-table WASM signer; synchronous signing after lazy setup. */
export const privateKeyToSigner = createWasmSigner(
  createSecp256k1Loader(() => import('./internal/wasm/secp256k1.wasm.js')),
)

/** A key supplies signing capability, not a smart account identity. */
export const privateKeyToAccount = privateKeyToSigner
