import { createHash } from 'node:crypto'
import { appendFile } from 'node:fs/promises'
import type { TraceSpan } from '../trace/types.js'
import type {
  ResourceSample,
  TraceBatch,
  TraceExporter,
  TraceExporterConfig,
} from './productionTypes.js'

export type { TraceExporterConfig as TraceExporterOptions } from './productionTypes.js'

type Attribute = {
  key: string
  value:
    | { stringValue: string }
    | { boolValue: boolean }
    | { intValue: string }
    | { doubleValue: number }
}

function attribute(key: string, value: string | number | boolean): Attribute {
  return {
    key,
    value:
      typeof value === 'string'
        ? { stringValue: value }
        : typeof value === 'boolean'
          ? { boolValue: value }
          : Number.isSafeInteger(value)
            ? { intValue: String(value) }
            : { doubleValue: value },
  }
}

// Keep the epoch's integer milliseconds separate: multiplying a current epoch
// timestamp as a Number would lose the sub-microsecond portion of span timings.
function unixNanos(originMs: number, relativeMs: number): string {
  const wholeMs = Math.trunc(originMs)
  return (
    BigInt(wholeMs) * 1_000_000n +
    BigInt(Math.round((originMs - wholeMs + relativeMs) * 1_000_000))
  ).toString()
}

function id(value: number): string {
  // Internal IDs are safe integers; adding one also gives numeric ID zero a
  // valid, nonzero OTLP span ID without changing parent/child relationships.
  return (BigInt(value) + 1n).toString(16).padStart(16, '0')
}

function resource(batch: TraceBatch) {
  return {
    attributes: [
      attribute('service.name', batch.serviceName),
      attribute('service.instance.id', batch.sessionId),
      attribute('process.pid', batch.pid),
    ],
  }
}

function tracePayload(batch: TraceBatch) {
  const prefix = createHash('sha256')
    .update(batch.sessionId)
    .digest('hex')
    .slice(0, 16)
  return {
    resourceSpans: [
      {
        resource: resource(batch),
        scopeSpans: [
          {
            scope: { name: 'cetane' },
            spans: batch.spans.map((span: TraceSpan) => ({
              traceId: prefix + id(span.operationId),
              spanId: id(span.id),
              ...(span.parentId === undefined
                ? {}
                : { parentSpanId: id(span.parentId) }),
              name: span.name,
              kind: 1,
              startTimeUnixNano: unixNanos(batch.timeOriginMs, span.startMs),
              endTimeUnixNano: unixNanos(
                batch.timeOriginMs,
                span.startMs + span.durationMs,
              ),
              attributes: Object.entries(span.attributes ?? {}).map(
                ([key, value]) => attribute(key, value),
              ),
              status: { code: span.status === 'error' ? 2 : 1 },
            })),
          },
        ],
      },
    ],
  }
}

function metricsPayload(batch: TraceBatch) {
  const point = (sample: Pick<ResourceSample, 'timeMs'>, value: number) => ({
    timeUnixNano: unixNanos(batch.timeOriginMs, sample.timeMs),
    asDouble: value,
  })
  const gauge = (
    name: string,
    unit: string,
    read: (sample: ResourceSample) => number,
  ) => ({
    name,
    unit,
    gauge: {
      dataPoints: batch.resources.map((sample) => point(sample, read(sample))),
    },
  })
  const metrics = batch.resources.length
    ? [
        {
          name: 'process.cpu.time',
          unit: 's',
          sum: {
            aggregationTemporality: 2,
            isMonotonic: true,
            dataPoints: batch.resources.flatMap((sample) => [
              {
                ...point(sample, sample.cpuUserMicros / 1_000_000),
                startTimeUnixNano: unixNanos(batch.timeOriginMs, 0),
                attributes: [attribute('cpu.mode', 'user')],
              },
              {
                ...point(sample, sample.cpuSystemMicros / 1_000_000),
                startTimeUnixNano: unixNanos(batch.timeOriginMs, 0),
                attributes: [attribute('cpu.mode', 'system')],
              },
            ]),
          },
        },
        gauge('cetane.process.cpu.percent', '%', (sample) => sample.cpuPercent),
        gauge('process.memory.usage', 'By', (sample) => sample.rssBytes),
        gauge(
          'cetane.process.memory.heap.used',
          'By',
          (sample) => sample.heapUsedBytes,
        ),
        gauge(
          'cetane.process.memory.heap.total',
          'By',
          (sample) => sample.heapTotalBytes,
        ),
        gauge(
          'cetane.process.memory.external',
          'By',
          (sample) => sample.externalBytes,
        ),
        gauge(
          'cetane.process.memory.array_buffers',
          'By',
          (sample) => sample.arrayBuffersBytes,
        ),
      ]
    : []
  // Loss remains observable when CPU/RAM sampling is disabled or its queue is full.
  const latest = batch.resources.at(-1) ?? { timeMs: performance.now() }
  for (const [name, value] of [
    ['cetane.trace.dropped_spans', batch.droppedSpans],
    ['cetane.trace.dropped_resources', batch.droppedResources],
  ] as const)
    metrics.push({
      name,
      unit: '{item}',
      gauge: { dataPoints: [point(latest, value)] },
    })
  return {
    resourceMetrics: [
      {
        resource: resource(batch),
        scopeMetrics: [{ scope: { name: 'cetane' }, metrics }],
      },
    ],
  }
}

function writeStdio(
  stream: typeof process.stdout | typeof process.stderr,
  line: string,
): Promise<void> {
  return new Promise((resolve, reject) => {
    let settled = false
    const finish = (error?: Error | null) => {
      if (settled) return
      settled = true
      // Writable streams emit 'error' after their write callback. Keep the
      // listener through that event so telemetry cannot crash the application.
      if (error) {
        setImmediate(() => stream.removeListener('error', onError))
        reject(new Error('Cetane trace output failed.'))
      } else {
        stream.removeListener('error', onError)
        resolve()
      }
    }
    const onError = (error: Error) => finish(error)
    stream.on('error', onError)
    try {
      // The callback waits for this write even when write() signals backpressure.
      stream.write(line, finish)
    } catch {
      finish(new Error())
    }
  })
}

/** Internal warning output, with the same error isolation as JSONL export. */
export function writeTraceDiagnostic(message: string): Promise<void> {
  return writeStdio(process.stderr, message)
}

async function responseJson(response: Response): Promise<unknown> {
  const reader = response.body?.getReader()
  if (!reader) return {}
  const decoder = new TextDecoder()
  let bytes = 0
  let text = ''
  try {
    for (;;) {
      const chunk = await reader.read()
      if (chunk.done) break
      bytes += chunk.value.byteLength
      if (bytes > 4 * 1024 * 1024) throw new Error('Response exceeded limit.')
      text += decoder.decode(chunk.value, { stream: true })
    }
    text += decoder.decode()
    return text.trim() ? JSON.parse(text) : {}
  } finally {
    void reader.cancel().catch(() => {})
    reader.releaseLock()
  }
}

function createOtlpExporter(
  config: Extract<TraceExporterConfig, { type: 'otlp' }>,
): TraceExporter {
  let base: URL
  let headers: Headers
  try {
    base = new URL(config.endpoint)
    if (
      !['http:', 'https:'].includes(base.protocol) ||
      base.username ||
      base.password ||
      base.hash
    )
      throw new Error()
    headers = new Headers(config.headers)
    headers.set('content-type', 'application/json')
    headers.set('accept', 'application/json')
  } catch {
    throw new TypeError('Invalid Cetane OTLP exporter configuration.')
  }
  const timeoutMs = config.timeoutMs ?? 10_000
  if (
    !Number.isSafeInteger(timeoutMs) ||
    timeoutMs < 1 ||
    timeoutMs > 2_147_483_647
  )
    throw new RangeError(
      'Cetane OTLP timeout must be a positive timer-safe integer.',
    )
  const endpoint = (signal: 'traces' | 'metrics') => {
    const url = new URL(base)
    url.pathname = `${url.pathname.replace(/\/$/, '')}/v1/${signal}`
    return url.toString()
  }
  const traces = endpoint('traces')
  const metrics = endpoint('metrics')
  let closed = false
  const cancellations = new Set<() => void>()
  async function post(url: string, payload: unknown): Promise<void> {
    if (closed) throw new Error('Cetane OTLP exporter is closed.')
    const controller = new AbortController()
    let timer: ReturnType<typeof setTimeout> | undefined
    let cancel!: () => void
    const interrupted = new Promise<never>((_, reject) => {
      cancel = () => {
        controller.abort()
        reject(new Error())
      }
      cancellations.add(cancel)
      timer = setTimeout(cancel, timeoutMs)
    })
    try {
      await Promise.race([
        (async () => {
          const response = await fetch(url, {
            method: 'POST',
            headers,
            body: JSON.stringify(payload),
            redirect: 'error',
            signal: controller.signal,
          })
          if (response.status !== 200) {
            void response.body?.cancel().catch(() => {})
            throw new Error()
          }
          const body = await responseJson(response)
          if (!body || typeof body !== 'object' || Array.isArray(body))
            throw new Error()
          if ('partialSuccess' in body && body.partialSuccess !== undefined) {
            const partial = body.partialSuccess
            if (!partial || typeof partial !== 'object') throw new Error()
            for (const key of [
              'rejectedSpans',
              'rejectedDataPoints',
            ] as const) {
              if (
                key in partial &&
                BigInt(String((partial as Record<string, unknown>)[key])) !== 0n
              )
                throw new Error()
            }
          }
        })(),
        interrupted,
      ])
    } catch {
      throw new Error('Cetane OTLP export failed.')
    } finally {
      clearTimeout(timer)
      cancellations.delete(cancel)
      controller.abort()
    }
  }
  return {
    async export(batch) {
      if (closed) throw new Error('Cetane OTLP exporter is closed.')
      const requests: Promise<void>[] = []
      if (batch.spans.length) requests.push(post(traces, tracePayload(batch)))
      if (
        batch.resources.length ||
        batch.droppedSpans ||
        batch.droppedResources
      )
        requests.push(post(metrics, metricsPayload(batch)))
      // Settle both signals before releasing the controller's bounded batch slot.
      const results = await Promise.allSettled(requests)
      if (results.some((result) => result.status === 'rejected'))
        throw new Error('Cetane OTLP export failed.')
    },
    async close() {
      closed = true
      for (const cancel of cancellations) cancel()
      cancellations.clear()
    },
  }
}

/** Node/Bun exporters. Output is asynchronous, and failures never include remote diagnostics or secrets. */
export function createTraceExporter(
  config: TraceExporterConfig,
): TraceExporter {
  if (config.type === 'otlp') return createOtlpExporter(config)
  if (config.type === 'file') {
    const path = config.path
    if (!path || path.includes('\0'))
      throw new TypeError('Invalid Cetane trace file path.')
    return {
      async export(batch) {
        try {
          await appendFile(path, `${JSON.stringify(batch)}\n`, {
            flag: 'a',
            mode: 0o600,
          })
        } catch {
          throw new Error('Cetane trace file export failed.')
        }
      },
    }
  }
  const stream = config.type === 'stdout' ? process.stdout : process.stderr
  return {
    async export(batch) {
      try {
        await writeStdio(stream, `${JSON.stringify(batch)}\n`)
      } catch {
        throw new Error('Cetane trace output failed.')
      }
    },
  }
}
