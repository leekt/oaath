import type { TraceSpan } from '../trace/types.js'

/** Process-wide measurements. CPU totals are cumulative; 100% means one busy core. */
export type ResourceSample = Readonly<{
  /** Monotonic milliseconds, using the same clock as spans. */
  timeMs: number
  cpuUserMicros: number
  cpuSystemMicros: number
  cpuPercent: number
  rssBytes: number
  heapUsedBytes: number
  heapTotalBytes: number
  externalBytes: number
  arrayBuffersBytes: number
}>

export type TraceBatch = Readonly<{
  schemaVersion: 1
  sessionId: string
  serviceName: string
  pid: number
  /** Unix epoch milliseconds corresponding to monotonic time zero. */
  timeOriginMs: number
  spans: readonly TraceSpan[]
  resources: readonly ResourceSample[]
  /** Cumulative totals, including exports that failed or could not be confirmed. */
  droppedSpans: number
  droppedResources: number
}>

/** Exporters must settle their promises. The controller serializes calls and bounds its queue. */
export type TraceExporter = {
  export(batch: TraceBatch): Promise<void>
  close?(): Promise<void>
}

export type TraceExporterConfig =
  | { type: 'stderr' | 'stdout' }
  | { type: 'file'; path: string }
  | {
      type: 'otlp'
      /** OTLP/HTTP base URL; /v1/traces and /v1/metrics are appended. */
      endpoint: string
      headers?: Readonly<Record<string, string>>
      timeoutMs?: number
    }
