import { CetaneError } from '../errors.js'
import type { Chain, Context, FeeParameters, Fees, Request } from '../types.js'
import { fromQuantity } from '../utils/hex.js'
import { requestIdentity } from '../internal/identity.js'
import { traceAsync, traceRequestFunction } from '../internal/trace.js'

export type RelayPolicy = {
  readonly fees?: NonNullable<Chain['fees']>['estimate']
  readonly receiptWait?: number
}
const pending = new WeakMap<Request, Promise<Fees>>()
type GasPriceQuote = {
  standard: { maxFeePerGas: string; maxPriorityFeePerGas: string }
}
function readQuote(context: Context): Promise<Fees> {
  const identity = requestIdentity(context.relay)
  const existing = pending.get(identity)
  if (existing)
    return context.trace
      ? traceAsync(context.trace, 'fees.quote', () => existing, {
          source: 'shared',
        })
      : existing
  const result = (
    context.trace
      ? traceAsync(
          context.trace,
          'fees.quote',
          (span) =>
            traceRequestFunction(
              context.relay,
              span,
              'relay',
            )<GasPriceQuote>({ method: 'pimlico_getUserOperationGasPrice' }),
          { source: 'rpc' },
        )
      : context.relay<GasPriceQuote>({
          method: 'pimlico_getUserOperationGasPrice',
        })
  )
    .then((result) => {
      const quote = result?.standard
      if (!quote) throw new CetaneError('Relay omitted its standard fee quote.')
      const maxFeePerGas = fromQuantity(quote.maxFeePerGas)
      const maxPriorityFeePerGas = fromQuantity(quote.maxPriorityFeePerGas)
      if (maxFeePerGas < maxPriorityFeePerGas)
        throw new CetaneError(
          'Relay fee quote does not cover its priority fee.',
        )
      return { maxFeePerGas, maxPriorityFeePerGas }
    })
    .finally(() => {
      pending.delete(identity)
    })
  pending.set(identity, result)
  return result
}
async function estimate(
  context: Context,
  parameters: FeeParameters,
): Promise<Fees> {
  const quote = await readQuote(context)
  const floor = context.chain.fees?.minPriorityFeePerGas ?? 0n
  const maxPriorityFeePerGas =
    parameters.maxPriorityFeePerGas ??
    (quote.maxPriorityFeePerGas < floor ? floor : quote.maxPriorityFeePerGas)
  return {
    maxPriorityFeePerGas,
    // Preserve the relay's base-fee headroom when the caller changes the bid.
    maxFeePerGas:
      parameters.maxFeePerGas ??
      quote.maxFeePerGas - quote.maxPriorityFeePerGas + maxPriorityFeePerGas,
  }
}

/** Explicit bundle_rs capabilities; no network probing, background timers, or settled-price cache. */
export function bundleRelay(
  parameters: { receiptWait?: number } = {},
): RelayPolicy {
  const receiptWait = parameters.receiptWait ?? 2_000
  if (
    !Number.isSafeInteger(receiptWait) ||
    receiptWait < 1 ||
    receiptWait > 60_000
  )
    throw new CetaneError('Receipt hold time must be between 1 and 60000 ms.')
  return Object.freeze({ fees: estimate, receiptWait })
}
