import { defineChain } from '../client.js'
import { account } from '../accounts/native.js'
import { createExecution } from '../execution/tempo.js'
import { CetaneError } from '../errors.js'
import type { Chain } from '../types.js'
import { fromQuantity } from '../utils/hex.js'
import { readFeeData } from '../actions/feeReads.js'

export const tempo = defineChain({
  id: 4217,
  name: 'Tempo',
  nativeAA: 'tempo',
  blockTime: 500,
  pollingInterval: 500,
  execution: createExecution(),
  account,
  // TIP-1010 transaction cap; total block capacity is a separate limit.
  limits: { maxGas: 30_000_000n },
  fees: {
    async estimate(context, parameters) {
      return {
        maxFeePerGas:
          parameters.maxFeePerGas ??
          fromQuantity(await readFeeData(context, 'eth_gasPrice')),
        maxPriorityFeePerGas: parameters.maxPriorityFeePerGas ?? 0n,
      }
    },
  },
  validateCalls(calls) {
    if (calls.some((call) => (call.value ?? 0n) !== 0n))
      throw new CetaneError(
        'Tempo does not support native value transfers. Use a token call.',
      )
  },
} satisfies Chain)
