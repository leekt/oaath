import { defineChain } from '../client.js'
import { defineAccount } from '../accounts/kernel.js'
import { createExecution } from '../execution/erc4337.js'

export const mainnet = defineChain({
  id: 1,
  name: 'Ethereum',
  nativeAA: false,
  nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  blockTime: 12_000,
  pollingInterval: 1_000,
  execution: createExecution(),
  account: defineAccount(),
  limits: { maxGas: 16_777_216n },
})
