import { defineChain } from '../client.js'
import { defineAccount } from '../accounts/keystore.js'
import { createExecution } from '../execution/eip8130.js'
import type { Chain } from '../types.js'

/** Infrastructure configuration for the pinned native-AA draft. */
export function withKeystore(
  chain: Chain,
  options: Parameters<typeof defineAccount>[0] &
    NonNullable<Parameters<typeof createExecution>[0]>,
) {
  return defineChain({
    ...chain,
    nativeAA: '8130',
    account: defineAccount(options),
    execution: createExecution(options),
    status: 'DRAFT' as const,
  })
}
