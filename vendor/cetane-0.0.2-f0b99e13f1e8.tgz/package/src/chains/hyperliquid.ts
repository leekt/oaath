import { defineChain } from '../client.js'
import { mainnet } from './mainnet.js'
import type { Chain, Context, FeeParameters, Fees } from '../types.js'
import { CetaneError } from '../errors.js'
import { fromQuantity } from '../utils/hex.js'
import { readFeeData } from '../actions/feeReads.js'

async function estimate(
  context: Context,
  parameters: FeeParameters,
): Promise<Fees> {
  const maxPriorityFeePerGas = parameters.maxPriorityFeePerGas ?? 0n
  if (maxPriorityFeePerGas !== 0n)
    throw new CetaneError(
      'The HyperEVM preset disables priority fees because they are burned.',
    )
  const price =
    parameters.maxFeePerGas ??
    fromQuantity(
      await readFeeData(
        context,
        context.chain.blockMode === 'big'
          ? 'eth_bigBlockGasPrice'
          : 'eth_gasPrice',
      ),
    ) * 2n
  return { maxFeePerGas: price, maxPriorityFeePerGas }
}
export const hyperliquid = defineChain({
  ...mainnet,
  id: 999,
  name: 'HyperEVM',
  nativeCurrency: { name: 'HYPE', symbol: 'HYPE', decimals: 18 },
  blockMode: 'small',
  blockTime: 1_000,
  pollingInterval: 500,
  limits: { maxGas: 3_000_000n },
  fees: { estimate, maxPriorityFeePerGas: 0n },
} satisfies Chain)
/** The outer transaction sender / relay must already use big blocks on HyperCore. */
export const hyperliquidBig = defineChain({
  ...hyperliquid,
  blockMode: 'big',
  blockTime: 60_000,
  pollingInterval: 2_000,
  limits: { maxGas: 30_000_000n },
})
