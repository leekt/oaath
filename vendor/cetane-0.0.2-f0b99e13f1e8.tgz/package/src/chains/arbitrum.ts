import { defineChain } from '../client.js'
import { mainnet } from './mainnet.js'
import type { Chain, Context, FeeParameters, Fees } from '../types.js'
import { CetaneError } from '../errors.js'
import { fromQuantity } from '../utils/hex.js'
import { readFeeData } from '../actions/feeReads.js'

/** Standard EIP-1559 bidding; no bid is silently replaced by a zero tip. */
async function estimate(
  context: Context,
  parameters: FeeParameters,
): Promise<Fees> {
  const maxPriorityFeePerGas =
    parameters.maxPriorityFeePerGas ??
    context.chain.fees?.minPriorityFeePerGas ??
    0n
  if (parameters.maxFeePerGas !== undefined)
    return { maxFeePerGas: parameters.maxFeePerGas, maxPriorityFeePerGas }
  const block = await readFeeData<{ baseFeePerGas: string }>(
    context,
    'eth_getBlockByNumber',
  )
  const multiplier = context.chain.fees?.baseFeeMultiplier ?? 20_000
  if (!Number.isSafeInteger(multiplier) || multiplier < 10_000)
    throw new CetaneError('Invalid base fee multiplier.')
  return {
    maxFeePerGas:
      (fromQuantity(block.baseFeePerGas) * BigInt(multiplier) + 9_999n) /
        10_000n +
      maxPriorityFeePerGas,
    maxPriorityFeePerGas,
  }
}
export const arbitrum = defineChain({
  ...mainnet,
  id: 42161,
  name: 'Arbitrum One',
  blockTime: 250,
  pollingInterval: 250,
  limits: { maxGas: 32_000_000n, maxTransactionSize: 117_964 },
  fees: { estimate },
} satisfies Chain)
