export class CetaneError extends Error {
  override name = 'CetaneError'
}

export class RpcError extends CetaneError {
  override name = 'RpcError'
  readonly code: number
  readonly data: unknown
  readonly method: string
  constructor(
    method: string,
    error: { code: number; message: string; data?: unknown },
  ) {
    super(`${method}: ${error.message}`)
    this.code = error.code
    this.data = error.data
    this.method = method
  }
}

export class TransportError extends CetaneError {
  override name = 'TransportError'
  readonly status: number | undefined
  constructor(message: string, options?: { cause?: unknown; status?: number }) {
    super(message, options)
    this.status = options?.status
  }
}

export class TimeoutError extends CetaneError {
  override name = 'TimeoutError'
}
