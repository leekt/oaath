import type { Abi } from 'abitype'
import { traceOperation, traceSync } from '../internal/trace.js'
import type {
  Address,
  BlockTag,
  Client,
  Hash,
  Hex,
  SendTransactionParameters,
  TransactionParameters,
} from '../types.js'
import { prepareFunction } from '../utils/abi.js'
import type {
  FunctionName,
  FunctionParameters,
  FunctionResult,
} from '../utils/abi.js'
import { call } from './read.js'
import { sendTransaction } from './send.js'

export function readContract<
  const A extends Abi,
  N extends FunctionName<A, 'view' | 'pure'>,
>(
  client: Client,
  parameters: FunctionParameters<A, N> & {
    address: Address
    account?: Address
    blockTag?: BlockTag
    blockNumber?: bigint
  },
): Promise<FunctionResult<A, N>> {
  const run = async (client: Client): Promise<FunctionResult<A, N>> => {
    const input = parameters as {
      abi: Abi
      functionName: string
      args?: readonly unknown[]
    }
    const prepared = client.trace
      ? traceSync(client.trace, 'abi.encode', () => prepareFunction(input))
      : prepareFunction(input)
    const { data } = await call(client, {
      to: parameters.address,
      data: prepared.data,
      ...(parameters.account ? { account: parameters.account } : {}),
      ...(parameters.blockTag ? { blockTag: parameters.blockTag } : {}),
      ...(parameters.blockNumber !== undefined
        ? { blockNumber: parameters.blockNumber }
        : {}),
    })
    return (
      client.trace
        ? traceSync(client.trace, 'abi.decode', () => prepared.decode(data))
        : prepared.decode(data)
    ) as FunctionResult<A, N>
  }
  return client.trace
    ? traceOperation(client, 'readContract', run)
    : run(client)
}
export function writeContract<
  const A extends Abi,
  N extends FunctionName<A, 'nonpayable' | 'payable'>,
>(
  client: Client,
  parameters: FunctionParameters<A, N> &
    TransactionParameters & { address: Address; value?: bigint },
): Promise<Hash> {
  const run = (client: Client): Promise<Hash> => {
    const { abi, functionName, args, address, ...rest } = parameters
    const input = {
      abi,
      functionName,
      ...(args ? { args: args as readonly unknown[] } : {}),
    }
    const { data } = client.trace
      ? traceSync(client.trace, 'abi.encode', () => prepareFunction(input))
      : prepareFunction(input)
    return sendTransaction(client, {
      ...rest,
      to: address,
      data: data as Hex,
    } as SendTransactionParameters)
  }
  return client.trace
    ? traceOperation(client, 'writeContract', run)
    : run(client)
}
