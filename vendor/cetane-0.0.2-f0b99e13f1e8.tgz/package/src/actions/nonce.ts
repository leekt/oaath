import { identity } from '../client.js'
import { CetaneError } from '../errors.js'
import type { Account, Client, Authorization } from '../types.js'
import { beginSpan, traceAsync, traceOperation } from '../internal/trace.js'
import type { ParallelNonceState } from './parallelNonce.js'

export function getNonceKey(
  account: Account,
  parameters: { nonceKey?: bigint; authorization?: Authorization },
): bigint {
  const key = parameters.nonceKey ?? 0n
  return account.getNonceKey?.(key, parameters.authorization) ?? key
}

export type NonceState = {
  next?: bigint
  uncertain?: boolean
  tail: Promise<unknown>
  /** Settled-to-void observers prevent failed ACKs from creating unhandled rejections. */
  pending?: Set<Promise<void>>
  /** Only the ordered preparation task can wait for ACK capacity at a time. */
  wakeWindow?: (() => void) | undefined
  outstanding?: number
  parallel?: ParallelNonceState
}
const clients = new WeakMap<object, Map<string, NonceState>>()

export function cachedNonce(
  client: Client,
  account: Account,
  key: bigint,
): bigint | undefined {
  const state = clients
    .get(identity(client))
    ?.get(`${account.address.toLowerCase()}:${key}`)
  if (!state) return undefined
  assertNonceKnown(state)
  return state.next
}

/** Per-client, per-account, per-key queues. Independent keys never block each other. */
export function withNonce<T>(
  client: Client,
  account: Account,
  key: bigint,
  action: (state: NonceState) => Promise<T>,
  control = false,
): Promise<T> {
  const state = nonceState(client, account, key)
  const queued = beginSpan(client.trace, 'queue.wait')
  const limited = client.chain.submission !== undefined && !control
  if (limited && !admit(client, state)) {
    queued?.end('error')
    return Promise.reject(new CetaneError('Submission queue is full.'))
  }
  const result = enqueue(state, () => {
    queued?.end()
    if (state.parallel)
      return state.parallel.drain(client).then(async () => {
        try {
          return await action(state)
        } finally {
          state.parallel!.synchronize()
        }
      })
    // Explicit nonces, prepared sends and reset are barriers behind every ACK.
    if (state.pending?.size)
      return (
        client.trace
          ? traceAsync(client.trace, 'queue.barrier', () =>
              Promise.all(state.pending!),
            )
          : Promise.all(state.pending)
      ).then(() => action(state))
    return action(state)
  })
  return limited ? releaseAdmission(state, result) : result
}

/** Release the ordered preparation queue after invocation, while retaining the ACK window. */
export function withNoncePipeline<T>(
  client: Client,
  account: Account,
  key: bigint,
  action: (state: NonceState) => Promise<{ pending: Promise<T> }>,
): Promise<T> {
  const state = nonceState(client, account, key)
  const queued = beginSpan(client.trace, 'queue.wait')
  if (!admit(client, state)) {
    queued?.end('error')
    return Promise.reject(new CetaneError('Submission queue is full.'))
  }
  const maximum = client.chain.submission!.maxInFlight
  const start = () => {
    assertNonceKnown(state)
    return action(state)
  }
  const staged = enqueue(state, () => {
    queued?.end()
    if ((state.pending?.size ?? 0) >= maximum)
      return waitForWindow(client, state, maximum).then(start)
    return start()
  })
  return releaseAdmission(
    state,
    staged.then(({ pending }) => pending),
  )
}

async function waitForWindow(
  client: Client,
  state: NonceState,
  maximum: number,
): Promise<void> {
  const window = beginSpan(client.trace, 'queue.window')
  while ((state.pending?.size ?? 0) >= maximum)
    await new Promise<void>((resolve) => {
      state.wakeWindow = resolve
    })
  window?.end()
}

/** Register ACK settlement before the preparation queue releases its next task. */
export function trackSubmission<T>(
  state: NonceState,
  result: Promise<T>,
): void {
  const pending = (state.pending ??= new Set())
  const complete = () => {
    pending.delete(settled)
    const wake = state.wakeWindow
    if (wake) {
      state.wakeWindow = undefined
      wake()
    }
  }
  // A single observer per ACK avoids installing another Promise.race listener
  // on every pending request each time capacity opens. A slow ACK must not
  // retain listeners for all the faster submissions that pass it.
  const settled = result.then(complete, () => {
    // A failed ACK may already have reached a node. Quarantine before waking
    // the next preparation, even when a later ACK has already succeeded.
    state.uncertain = true
    complete()
  })
  pending.add(settled)
}

function releaseAdmission<T>(
  state: NonceState,
  result: Promise<T>,
): Promise<T> {
  return result.then(
    (value) => {
      state.outstanding!--
      return value
    },
    (error: unknown) => {
      state.outstanding!--
      throw error
    },
  )
}

export function admit(client: Client, state: NonceState): boolean {
  const policy = client.chain.submission!
  if (
    (state.outstanding ?? 0) >=
    policy.maxInFlight + (policy.maxQueued ?? 1024)
  )
    return false
  state.outstanding = (state.outstanding ?? 0) + 1
  return true
}

export function enqueue<T>(
  state: NonceState,
  action: () => Promise<T>,
): Promise<T> {
  const result = state.tail.then(action)
  state.tail = result.then(
    () => {},
    () => {},
  )
  return result
}

export function nonceState(
  client: Client,
  account: Account,
  key: bigint,
): NonceState {
  const id = identity(client)
  let accounts = clients.get(id)
  if (!accounts) {
    accounts = new Map()
    clients.set(id, accounts)
  }
  const scope = `${account.address.toLowerCase()}:${key}`
  let state = accounts.get(scope)
  if (!state) {
    state = { tail: Promise.resolve() }
    accounts.set(scope, state)
  }
  return state
}

export function assertNonceKnown(state: NonceState): void {
  if (state.uncertain)
    throw new CetaneError(
      'The previous submission outcome is unknown. Resolve it before calling resetNonce or supplying an explicit nonce.',
    )
}

/** Call only after resolving pending/failed submissions, or supply a known next nonce. */
export function resetNonce(
  client: Client,
  parameters: {
    account?: Account
    nonceKey?: bigint
    nonce?: bigint
    authorization?: Authorization
  } = {},
): Promise<void> {
  return client.trace
    ? traceOperation(client, 'resetNonce', (scoped) =>
        resetNonceInner(scoped, parameters),
      )
    : resetNonceInner(client, parameters)
}

function resetNonceInner(
  client: Client,
  parameters: {
    account?: Account
    nonceKey?: bigint
    nonce?: bigint
    authorization?: Authorization
  } = {},
): Promise<void> {
  const account = parameters.account ?? client.account
  if (!account) throw new CetaneError('An account is required.')
  if ((parameters.nonce ?? 0n) < 0n || (parameters.nonceKey ?? 0n) < 0n)
    throw new CetaneError('Nonce cannot be negative.')
  return withNonce(
    client,
    account,
    getNonceKey(account, parameters),
    async (state) => {
      delete state.next
      if (parameters.nonce !== undefined) state.next = parameters.nonce
      delete state.uncertain
    },
    true,
  )
}
