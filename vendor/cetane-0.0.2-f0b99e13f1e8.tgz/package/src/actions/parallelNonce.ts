import { CetaneError } from '../errors.js'
import { beginSpan } from '../internal/trace.js'
import type { Account, Client, Hash } from '../types.js'
import {
  admit,
  assertNonceKnown,
  enqueue,
  nonceState,
  trackSubmission,
} from './nonce.js'
import type { NonceState } from './nonce.js'

type Plan = {
  nonce: bigint
  sign(): Promise<void> | undefined
  submit(): Promise<Hash>
}
type Prepare = (nonce: bigint | undefined) => Promise<Plan>
type Ticket = {
  plan: Plan
  resolve: (hash: Hash) => void
  reject: (error: unknown) => void
  authorization?: { ok: true } | { ok: false; error: unknown }
  canceled: boolean
  settled: boolean
  retired: boolean
}

export type ParallelNonceState = {
  stage(
    client: Client,
    prepare: Prepare,
    resolve: (hash: Hash) => void,
    reject: (error: unknown) => void,
  ): Promise<void>
  drain(client: Client): Promise<void>
  synchronize(): void
}

/** Experimental path only: the existing maxInFlight scheduler is unchanged. */
export function withParallelNonce(
  client: Client,
  account: Account,
  key: bigint,
  prepare: Prepare,
): Promise<Hash> {
  const state = nonceState(client, account, key)
  const queued = beginSpan(client.trace, 'queue.wait')
  if (!admit(client, state)) {
    queued?.end('error')
    return Promise.reject(new CetaneError('Submission queue is full.'))
  }
  return new Promise<Hash>((resolve, reject) => {
    // Observe staging failures immediately; a caller need not attach to an internal promise.
    void enqueue(state, () => {
      queued?.end()
      // An earlier explicit/prepared send may still be advancing state.next.
      // Initialize only after that ordered action has completed.
      const parallel = (state.parallel ??= createParallelState(state, client))
      return parallel.stage(client, prepare, resolve, reject)
    }).catch((error: unknown) => {
      state.outstanding!--
      reject(error)
    })
  })
}

function createParallelState(
  state: NonceState,
  client: Client,
): ParallelNonceState {
  const maximum = client.chain.submission!.maxInFlight
  const maxSigning = client.chain.submission!.maxSigning!
  let reservedNext = state.next
  let base = state.next
  let active = 0 // Preparation, signing, ready-to-dispatch and unacknowledged writes.
  let signing = 0
  let stopped = false
  let cancellation: CetaneError | undefined
  let tickets: Ticket[] = []
  let head = 0
  let pumping = false

  function wake() {
    const waiting = state.wakeWindow
    if (waiting) {
      state.wakeWindow = undefined
      waiting()
    }
  }

  function idle() {
    if (active === 0 && stopped && !state.uncertain) {
      // No earlier ACK or canceled signing job can still affect this generation.
      if (state.next === undefined && base !== undefined) state.next = base
      reservedNext = state.next
      stopped = false
      cancellation = undefined
    }
    wake()
  }

  function fail(ticket: Ticket, error: unknown) {
    if (ticket.settled) return
    ticket.settled = true
    ticket.reject(error)
  }

  function retire(ticket: Ticket) {
    if (ticket.retired) return
    ticket.retired = true
    active--
    state.outstanding!--
    idle()
  }

  function stop(error: CetaneError) {
    stopped = true
    cancellation = error
    const canceled = tickets
    const first = head
    tickets = []
    head = 0
    for (let index = first; index < canceled.length; index++) {
      const ticket = canceled[index]!
      ticket.canceled = true
      fail(ticket, error)
      // A rejected caller does not free capacity while its signer still runs.
      if (ticket.authorization) retire(ticket)
    }
    idle()
  }

  function ambiguous(error: unknown) {
    state.uncertain = true
    stop(
      new CetaneError(
        'Speculative signing canceled: a previous submission outcome is unknown.',
        { cause: error },
      ),
    )
  }

  function pump() {
    if (pumping) return
    pumping = true
    try {
      while (!stopped && head < tickets.length) {
        if (state.uncertain) {
          ambiguous(new CetaneError('Previous submission outcome is unknown.'))
          break
        }
        const ticket = tickets[head]!
        const authorization = ticket.authorization
        if (!authorization) break
        if (!authorization.ok) {
          fail(ticket, authorization.error)
          stop(
            new CetaneError(
              'Speculative signing canceled after an earlier local authorization failure.',
              { cause: authorization.error },
            ),
          )
          break
        }
        head++
        const next = ticket.plan.nonce + 1n
        if (state.next === undefined || next > state.next) state.next = next
        let pending: Promise<Hash>
        try {
          // No await between the uncertainty check, nonce commit and write invocation.
          pending = Promise.resolve(ticket.plan.submit())
        } catch (error) {
          fail(ticket, error)
          ambiguous(error)
          retire(ticket)
          break
        }
        trackSubmission(state, pending)
        void pending.then(
          (hash) => {
            ticket.settled = true
            ticket.resolve(hash)
            retire(ticket)
          },
          (error: unknown) => {
            fail(ticket, error)
            ambiguous(error)
            retire(ticket)
          },
        )
      }
    } finally {
      pumping = false
      if (head === tickets.length) {
        tickets = []
        head = 0
      } else if (head >= maximum) {
        tickets = tickets.slice(head)
        head = 0
      }
    }
  }

  function authorized(
    ticket: Ticket,
    authorization: NonNullable<Ticket['authorization']>,
  ) {
    signing--
    ticket.authorization = authorization
    if (ticket.canceled) retire(ticket)
    else pump()
    wake()
  }

  async function wait(client: Client, blocked: () => boolean, known: boolean) {
    const span = beginSpan(
      client.trace,
      known ? 'queue.window' : 'queue.barrier',
    )
    try {
      while (blocked()) {
        if (known) assertNonceKnown(state)
        await new Promise<void>((resolve) => {
          state.wakeWindow = resolve
        })
      }
      if (known) assertNonceKnown(state)
      span?.end()
    } catch (error) {
      span?.end('error')
      throw error
    }
  }

  return {
    async stage(client, prepare, resolve, reject) {
      await wait(
        client,
        () => active >= maximum || signing >= maxSigning || stopped,
        true,
      )
      active++
      let plan: Plan
      try {
        const nonce = reservedNext ?? state.next
        plan = await prepare(nonce)
        assertNonceKnown(state)
        if (stopped) throw cancellation
        if (
          typeof plan.nonce !== 'bigint' ||
          plan.nonce < 0n ||
          (nonce !== undefined && plan.nonce !== nonce)
        )
          throw new CetaneError('Execution changed a reserved nonce.')
      } catch (error) {
        active--
        idle()
        throw error
      }
      base ??= plan.nonce
      reservedNext = plan.nonce + 1n
      const ticket: Ticket = {
        plan,
        resolve,
        reject,
        canceled: false,
        settled: false,
        retired: false,
      }
      tickets.push(ticket)
      signing++
      try {
        // Install both outcomes immediately, even if an earlier ticket blocks dispatch.
        void Promise.resolve(plan.sign()).then(
          () => authorized(ticket, { ok: true }),
          (error: unknown) => authorized(ticket, { ok: false, error }),
        )
      } catch (error) {
        authorized(ticket, { ok: false, error })
      }
    },
    async drain(client) {
      await wait(client, () => active !== 0, false)
    },
    synchronize() {
      reservedNext = state.next
      base = state.next
      stopped = state.uncertain === true
      cancellation = undefined
      wake()
    },
  }
}
