import { CetaneError } from '../errors.js'
import { traceOperation, traceSync } from '../internal/trace.js'
import type { Client, ModuleChange, TransactionParameters } from '../types.js'
import { assertPipelineAccount, prepareCalls, sendCalls } from './send.js'

export type UpdateModulesParameters = TransactionParameters & {
  changes: readonly ModuleChange[]
}
function moduleRequest(client: Client, parameters: UpdateModulesParameters) {
  const account = parameters.account ?? client.account
  if (!account?.encodeModuleChanges)
    throw new CetaneError('This account does not support module changes.')
  assertPipelineAccount(client, account)
  if (!parameters.changes.length)
    throw new CetaneError('At least one module change is required.')
  const encoded = client.trace
    ? traceSync(
        client.trace,
        'modules.encode',
        () => account.encodeModuleChanges!(parameters.changes),
        { count: parameters.changes.length },
      )
    : account.encodeModuleChanges(parameters.changes)
  return { ...encoded, ...parameters, account, calls: encoded.calls }
}
export function prepareModuleUpdate(
  client: Client,
  parameters: UpdateModulesParameters,
) {
  return client.trace
    ? traceOperation(client, 'prepareModuleUpdate', (scoped) =>
        prepareCalls(scoped, moduleRequest(scoped, parameters)),
      )
    : prepareCalls(client, moduleRequest(client, parameters))
}
export function updateModules(
  client: Client,
  parameters: UpdateModulesParameters,
) {
  const send = async (scoped: Client) =>
    (await sendCalls(scoped, moduleRequest(scoped, parameters))).id
  return client.trace
    ? traceOperation(client, 'updateModules', send)
    : send(client)
}
