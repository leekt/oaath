import type { Context, Request } from '../types.js'
import { requestIdentity } from '../internal/identity.js'
import { traceAsync, traceRequestFunction } from '../internal/trace.js'

type Method =
  | 'eth_getBlockByNumber'
  | 'eth_maxPriorityFeePerGas'
  | 'eth_gasPrice'
  | 'eth_bigBlockGasPrice'
const pending = new WeakMap<Request, Map<Method, Promise<unknown>>>()

/** Share identical in-flight fee reads. Settled prices, including errors, are never cached. */
export function readFeeData<T>(context: Context, method: Method): Promise<T> {
  const identity = requestIdentity(context.request)
  let reads = pending.get(identity)
  if (!reads) {
    reads = new Map()
    pending.set(identity, reads)
  }
  const existing = reads.get(method)
  if (existing)
    return context.trace
      ? traceAsync(context.trace, 'fees.read', () => existing as Promise<T>, {
          method,
          source: 'shared',
        })
      : (existing as Promise<T>)
  const current = reads
  const result = (
    context.trace
      ? traceAsync(
          context.trace,
          'fees.read',
          (span) =>
            traceRequestFunction(
              context.request,
              span,
              'rpc',
            )<T>({
              method,
              ...(method === 'eth_getBlockByNumber'
                ? { params: ['latest', false] }
                : {}),
            }),
          { method, source: 'rpc' },
        )
      : context.request<T>({
          method,
          ...(method === 'eth_getBlockByNumber'
            ? { params: ['latest', false] }
            : {}),
        })
  ).then(
    (value) => {
      current.delete(method)
      return value
    },
    (error) => {
      current.delete(method)
      throw error
    },
  )
  current.set(method, result)
  return result
}
