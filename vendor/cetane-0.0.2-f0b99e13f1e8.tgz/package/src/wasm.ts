import { abytes } from '@noble/hashes/utils.js'
import { CetaneError } from './errors.js'
import { bytesToHex, hexToBytes, withHexBytes } from './utils/bytes.js'
import { createHashingEnabler } from './internal/hashing.js'
import type { KeccakBackend } from './internal/hashing.js'
import type { Hash, Hex } from './types.js'

async function initialize(): Promise<KeccakBackend> {
  const { createKeccak256 } = await import('./wasm/keccak.js')
  const hasher = await createKeccak256()
  // Only private decoded bytes and normalized public views may reach this helper.
  const hashTrusted = (head: Uint8Array, tail?: Uint8Array): Hash => {
    const digest = hasher(head, tail)
    abytes(digest, 32)
    return bytesToHex(digest)
  }
  const hashBytes = (first: Uint8Array, second?: Uint8Array): Hash => {
    // Preserve the JS hash's byte-input validation. The reusable instance never
    // escapes this complete synchronous operation, including both message parts.
    abytes(first)
    if (second !== undefined) abytes(second)
    // Read caller-controlled view properties before entering the shared hasher.
    // An exotic view's getter may itself hash; plain local views cannot reenter.
    const head = new Uint8Array(
      first.buffer,
      first.byteOffset,
      first.byteLength,
    )
    const tail =
      second === undefined
        ? undefined
        : new Uint8Array(second.buffer, second.byteOffset, second.byteLength)
    return hashTrusted(head, tail)
  }
  const hash = (value: Hex | Uint8Array, second?: Uint8Array): Hash =>
    typeof value === 'string' && second === undefined
      ? withHexBytes(value, hashTrusted, hashBytes)
      : hashBytes(typeof value === 'string' ? hexToBytes(value) : value, second)
  const empty = new Uint8Array()
  const message = Uint8Array.from({ length: 273 }, (_, i) => (i * 17 + 3) & 255)
  const emptyDigest =
    '0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
  const messageDigest =
    '0x21cdfe1022deefc98568fe3b6fa178e231ea59b445b5118d162f018dac5610be'
  if (
    hash(empty) !== emptyDigest ||
    hash('0x') !== emptyDigest ||
    hash(message) !== messageDigest ||
    hash(bytesToHex(message)) !== messageDigest ||
    hash(message.subarray(0, 135), message.subarray(135)) !== messageDigest ||
    hash(empty) !== emptyDigest
  )
    throw new CetaneError('WASM Keccak self-test failed.')
  // Publish only after all known-answer and segmented/reset checks succeed.
  return hash
}

/**
 * Enable optional WASM Keccak hashing for this module instance.
 * Repeated successful calls reselect the verified WASM backend and return the
 * original setup promise. Concurrent cold backends install in completion order.
 */
export const enableWasmHashing = createHashingEnabler(initialize)
