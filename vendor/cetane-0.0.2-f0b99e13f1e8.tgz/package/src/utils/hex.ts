import { CetaneError } from '../errors.js'
import type { Address, Hex } from '../types.js'
import { isHexData } from './bytes.js'

export function toQuantity(value: bigint | number): Hex {
  if (typeof value === 'number' && !Number.isSafeInteger(value))
    throw new CetaneError('Expected a safe integer.')
  if (value < 0) throw new CetaneError('Expected an unsigned quantity.')
  return `0x${value.toString(16)}`
}

export function fromQuantity(value: unknown): bigint {
  if (typeof value !== 'string' || !/^0x(?:0|[1-9a-f][0-9a-f]*)$/i.test(value))
    throw new CetaneError('Invalid RPC quantity.')
  return BigInt(value)
}

export function assertHex(value: string, bytes?: number): asserts value is Hex {
  if (
    typeof value !== 'string' ||
    value.length % 2 !== 0 ||
    (bytes !== undefined && value.length !== 2 + bytes * 2) ||
    !isHexData(value)
  )
    throw new CetaneError(
      `Expected ${bytes === undefined ? 'byte-aligned' : `${bytes}-byte`} hex data.`,
    )
}

export function assertAddress(value: string): asserts value is Address {
  assertHex(value, 20)
}

const uint256Bound = 1n << 256n
const uint128Bound = 1n << 128n

export function word(value: bigint, bytes = 32): string {
  if (
    value < 0n ||
    value >=
      (bytes === 32
        ? uint256Bound
        : bytes === 16
          ? uint128Bound
          : 1n << BigInt(bytes * 8))
  )
    throw new CetaneError(`Integer exceeds uint${bytes * 8}.`)
  return value.toString(16).padStart(bytes * 2, '0')
}

export function addressWord(address: Address): string {
  assertAddress(address)
  return address.slice(2).toLowerCase().padStart(64, '0')
}
