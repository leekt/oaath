import type {
  Abi,
  AbiFunction,
  AbiParameter,
  AbiParametersToPrimitiveTypes,
  ExtractAbiFunction,
  ExtractAbiFunctionNames,
} from 'abitype'
import { CetaneError } from '../errors.js'
import type { Hex } from '../types.js'
import { bytesToHex, hexToBytes } from './bytes.js'
import { keccak256 } from './hash.js'
import { addressWord, assertHex, word } from './hex.js'

type Node = {
  parameter: AbiParameter
  type: string
  dynamic: boolean
  size: number
  child?: Node
  length?: number
  children?: readonly Node[]
  bits?: number
  bound?: bigint
}
type Tuple = { nodes: readonly Node[]; headSize: number }
const tuples = new WeakMap<readonly AbiParameter[], Tuple>()
const functions = new WeakMap<
  AbiFunction,
  { inputs: Tuple; outputs: Tuple; selector: string }
>()

function compile(parameter: AbiParameter, depth = 0): Node {
  if (depth > 64) throw new CetaneError('ABI nesting exceeds 64 levels.')
  const { type } = parameter
  const array = /^(.*)\[([0-9]*)\]$/.exec(type)
  if (array) {
    const child = compile(
      { ...parameter, type: array[1]! } as AbiParameter,
      depth + 1,
    )
    const length = array[2] === '' ? undefined : Number(array[2])
    if (
      length !== undefined &&
      (!Number.isSafeInteger(length) || length <= 0 || length > 1_000_000)
    )
      throw new CetaneError('Invalid ABI array length.')
    const dynamic = length === undefined || child.dynamic
    return {
      parameter,
      type: 'array',
      child,
      ...(length !== undefined ? { length } : {}),
      dynamic,
      size: dynamic ? 32 : child.size * length!,
    }
  }
  if (type === 'tuple') {
    if (!('components' in parameter))
      throw new CetaneError('Tuple components are required.')
    const children = parameter.components.map((p) => compile(p, depth + 1))
    const dynamic = children.some((c) => c.dynamic)
    return {
      parameter,
      type,
      children,
      dynamic,
      size: dynamic ? 32 : children.reduce((n, c) => n + c.size, 0),
    }
  }
  if (type === 'bytes' || type === 'string')
    return { parameter, type, dynamic: true, size: 32 }
  if (type === 'address' || type === 'bool')
    return { parameter, type, dynamic: false, size: 32 }
  const integer = /^(u?int)(\d*)$/.exec(type)
  if (integer) {
    const bits = Number(integer[2] || 256)
    if (bits < 8 || bits > 256 || bits % 8)
      throw new CetaneError(`Invalid ABI type ${type}.`)
    return {
      parameter,
      type: integer[1]!,
      bits,
      bound: 1n << BigInt(bits - (integer[1] === 'int' ? 1 : 0)),
      dynamic: false,
      size: 32,
    }
  }
  const bytes = /^bytes(\d+)$/.exec(type)
  if (bytes && Number(bytes[1]) >= 1 && Number(bytes[1]) <= 32)
    return {
      parameter,
      type: 'fixedBytes',
      bits: Number(bytes[1]) * 8,
      dynamic: false,
      size: 32,
    }
  throw new CetaneError(`Unsupported ABI type ${type}.`)
}

function tuple(parameters: readonly AbiParameter[]): Tuple {
  let cached = tuples.get(parameters)
  if (!cached) {
    const nodes = parameters.map((p) => compile(p))
    cached = { nodes, headSize: nodes.reduce((n, c) => n + c.size, 0) }
    tuples.set(parameters, cached)
  }
  return cached
}

function tupleValues(
  nodes: readonly Node[],
  value: unknown,
): readonly unknown[] {
  if (Array.isArray(value)) return value
  if (
    value &&
    typeof value === 'object' &&
    nodes.every((n) => n.parameter.name)
  )
    return nodes.map(
      (n) => (value as Record<string, unknown>)[n.parameter.name!],
    )
  throw new CetaneError('Expected tuple arguments.')
}

function encodeTuple(
  nodes: readonly Node[],
  values: readonly unknown[],
  headSize: number,
): string {
  if (values.length !== nodes.length)
    throw new CetaneError('ABI argument count mismatch.')
  const head: string[] = []
  const tail: string[] = []
  let offset = headSize
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i]!
    const encoded = encodeNode(node, values[i])
    if (node.dynamic) {
      head.push(word(BigInt(offset)))
      tail.push(encoded)
      offset += encoded.length / 2
    } else head.push(encoded)
  }
  return head.join('') + tail.join('')
}

function encodeNode(node: Node, value: unknown): string {
  switch (node.type) {
    case 'address': {
      if (typeof value !== 'string')
        throw new CetaneError('Expected an address.')
      return addressWord(value as Hex)
    }
    case 'bool':
      if (typeof value !== 'boolean')
        throw new CetaneError('Expected a boolean.')
      return word(value ? 1n : 0n)
    case 'uint':
    case 'int': {
      if (
        typeof value !== 'bigint' &&
        (typeof value !== 'number' || !Number.isSafeInteger(value))
      )
        throw new CetaneError('Expected an integer.')
      const n = BigInt(value as bigint | number)
      const signed = node.type === 'int'
      const bound = node.bound!
      if (n < (signed ? -bound : 0n) || n >= bound)
        throw new CetaneError(`Value exceeds ${node.parameter.type}.`)
      // The compiled integer bound already proves the value fits its ABI word.
      return (n < 0n ? (1n << 256n) + n : n).toString(16).padStart(64, '0')
    }
    case 'fixedBytes':
      if (typeof value !== 'string')
        throw new CetaneError('Expected hex bytes.')
      assertHex(value, node.bits! / 8)
      return value.slice(2).padEnd(64, '0')
    case 'bytes':
    case 'string': {
      if (typeof value !== 'string')
        throw new CetaneError(`Expected ${node.type}.`)
      const data =
        node.type === 'string'
          ? bytesToHex(new TextEncoder().encode(value))
          : value
      assertHex(data)
      const size = (data.length - 2) / 2
      return (
        word(BigInt(size)) +
        data.slice(2).padEnd(Math.ceil(size / 32) * 64, '0')
      )
    }
    case 'tuple': {
      const children = node.children!
      return encodeTuple(
        children,
        tupleValues(children, value),
        children.reduce((n, c) => n + c.size, 0),
      )
    }
    case 'array': {
      if (
        !Array.isArray(value) ||
        (node.length !== undefined && value.length !== node.length)
      )
        throw new CetaneError('ABI array length mismatch.')
      const child = node.child!
      const nodes = Array<Node>(value.length).fill(child)
      const encoded = encodeTuple(nodes, value, child.size * value.length)
      return (
        (node.length === undefined ? word(BigInt(value.length)) : '') + encoded
      )
    }
    default:
      throw new CetaneError('Unsupported ABI node.')
  }
}

function readWord(data: string, offset: number): bigint {
  if (
    !Number.isSafeInteger(offset) ||
    offset < 0 ||
    offset + 32 > data.length / 2
  )
    throw new CetaneError('ABI data is out of bounds.')
  return BigInt(`0x${data.slice(offset * 2, offset * 2 + 64)}`)
}
function safeNumber(value: bigint): number {
  if (value > BigInt(Number.MAX_SAFE_INTEGER))
    throw new CetaneError('ABI offset is too large.')
  return Number(value)
}
function decodeTuple(
  nodes: readonly Node[],
  data: string,
  base: number,
): unknown[] {
  const headSize = nodes.reduce((n, node) => n + node.size, 0)
  if (base + headSize > data.length / 2)
    throw new CetaneError('ABI head is out of bounds.')
  let cursor = base
  return nodes.map((node) => {
    let offset = cursor
    if (node.dynamic) {
      const relative = safeNumber(readWord(data, cursor))
      if (relative < headSize || relative % 32 !== 0)
        throw new CetaneError('Invalid ABI offset.')
      offset = base + relative
    }
    cursor += node.size
    return decodeNode(node, data, offset)
  })
}
function decodeNode(node: Node, data: string, offset: number): unknown {
  if (node.type === 'tuple') {
    const values = decodeTuple(node.children!, data, offset)
    if (node.children!.length && node.children!.every((n) => n.parameter.name))
      return Object.fromEntries(
        node.children!.map((n, i) => [n.parameter.name!, values[i]]),
      )
    return values
  }
  if (node.type === 'array') {
    const length = node.length ?? safeNumber(readWord(data, offset))
    const base = offset + (node.length === undefined ? 32 : 0)
    if (
      length > 1_000_000 ||
      length * node.child!.size > data.length / 2 - base
    )
      throw new CetaneError('ABI array exceeds available data.')
    return decodeTuple(Array<Node>(length).fill(node.child!), data, base)
  }
  const n = readWord(data, offset)
  switch (node.type) {
    case 'address':
      if (n >= 1n << 160n) throw new CetaneError('Noncanonical ABI address.')
      return `0x${data.slice(offset * 2 + 24, offset * 2 + 64)}`
    case 'bool':
      if (n > 1n) throw new CetaneError('Noncanonical ABI boolean.')
      return n === 1n
    case 'uint':
    case 'int': {
      const signed = node.type === 'int'
      const v = signed && n >= 1n << 255n ? n - (1n << 256n) : n
      const bound = node.bound!
      if (v < (signed ? -bound : 0n) || v >= bound)
        throw new CetaneError('Noncanonical ABI integer.')
      return node.bits! <= 48 ? Number(v) : v
    }
    case 'fixedBytes': {
      const start = offset * 2
      const end = start + node.bits! / 4
      if (!/^0*$/.test(data.slice(end, start + 64)))
        throw new CetaneError('Noncanonical ABI bytes padding.')
      return `0x${data.slice(start, end)}`
    }
    case 'bytes':
    case 'string': {
      const size = safeNumber(n)
      const start = (offset + 32) * 2
      if (start + Math.ceil(size / 32) * 64 > data.length)
        throw new CetaneError('ABI bytes are out of bounds.')
      const hex: Hex = `0x${data.slice(start, start + size * 2)}`
      return node.type === 'bytes'
        ? hex
        : new TextDecoder('utf-8', { fatal: true }).decode(hexToBytes(hex))
    }
    default:
      throw new CetaneError('Unsupported ABI node.')
  }
}

export function encodeAbiParameters<const P extends readonly AbiParameter[]>(
  parameters: P,
  values: AbiParametersToPrimitiveTypes<P>,
): Hex {
  const compiled = tuple(parameters)
  return `0x${encodeTuple(compiled.nodes, values as readonly unknown[], compiled.headSize)}`
}
export function decodeAbiParameters<const P extends readonly AbiParameter[]>(
  parameters: P,
  data: Hex,
): AbiParametersToPrimitiveTypes<P> {
  assertHex(data)
  return decodeTuple(
    tuple(parameters).nodes,
    data.slice(2),
    0,
  ) as AbiParametersToPrimitiveTypes<P>
}
function canonicalType(parameter: AbiParameter): string {
  if (parameter.type.startsWith('tuple') && 'components' in parameter)
    return `(${parameter.components.map(canonicalType).join(',')})${parameter.type.slice(5)}`
  return parameter.type
    .replace(/^uint(?=\[|$)/, 'uint256')
    .replace(/^int(?=\[|$)/, 'int256')
}
function compileFunction(fn: AbiFunction) {
  let cached = functions.get(fn)
  if (!cached) {
    const signature = `${fn.name}(${fn.inputs.map(canonicalType).join(',')})`
    cached = {
      inputs: tuple(fn.inputs),
      outputs: tuple(fn.outputs),
      selector: keccak256(new TextEncoder().encode(signature)).slice(2, 10),
    }
    functions.set(fn, cached)
  }
  return cached
}

export type FunctionName<
  A extends Abi,
  M extends 'pure' | 'view' | 'nonpayable' | 'payable' =
    | 'pure'
    | 'view'
    | 'nonpayable'
    | 'payable',
> = Abi extends A ? string : ExtractAbiFunctionNames<A, M>
export type FunctionArgs<
  A extends Abi,
  N extends FunctionName<A>,
> = Abi extends A
  ? readonly unknown[]
  : AbiParametersToPrimitiveTypes<ExtractAbiFunction<A, N>['inputs']>
export type FunctionResult<
  A extends Abi,
  N extends FunctionName<A>,
> = Abi extends A
  ? unknown
  : AbiParametersToPrimitiveTypes<
        ExtractAbiFunction<A, N>['outputs']
      > extends infer R extends readonly unknown[]
    ? R extends readonly []
      ? undefined
      : R extends readonly [infer V]
        ? V
        : R
    : never
export type FunctionParameters<A extends Abi, N extends FunctionName<A>> = {
  abi: A
  functionName: N
} & (FunctionArgs<A, N> extends readonly []
  ? { args?: readonly [] }
  : { args: FunctionArgs<A, N> })

/** Compiles once per ABI function object. ABI objects should be immutable. */
export function prepareFunction(parameters: {
  abi: Abi
  functionName: string
  args?: readonly unknown[]
}): { data: Hex; decode(data: Hex): unknown } {
  let found: { data: Hex; decode(data: Hex): unknown } | undefined
  let failure: unknown
  for (const item of parameters.abi) {
    if (item.type !== 'function' || item.name !== parameters.functionName)
      continue
    const compiled = compileFunction(item)
    let encoded: string
    try {
      encoded = encodeTuple(
        compiled.inputs.nodes,
        parameters.args ?? [],
        compiled.inputs.headSize,
      )
    } catch (error) {
      failure = error
      continue
    }
    if (found)
      throw new CetaneError(
        'Ambiguous ABI overload. Supply an ABI containing only the intended function.',
      )
    found = {
      data: `0x${compiled.selector}${encoded}`,
      decode(data) {
        assertHex(data)
        const values = decodeTuple(compiled.outputs.nodes, data.slice(2), 0)
        return values.length === 0
          ? undefined
          : values.length === 1
            ? values[0]
            : values
      },
    }
  }
  if (!found)
    throw new CetaneError(
      `No matching ABI function: ${parameters.functionName}.`,
      { cause: failure },
    )
  return found
}
export function encodeFunctionData<
  const A extends Abi,
  N extends FunctionName<A>,
>(parameters: FunctionParameters<A, N>): Hex {
  return prepareFunction(
    parameters as { abi: Abi; functionName: string; args?: readonly unknown[] },
  ).data
}
export function decodeFunctionResult<
  const A extends Abi,
  N extends FunctionName<A>,
>(parameters: {
  abi: A
  functionName: N
  data: Hex
  args?: FunctionArgs<A, N>
}): FunctionResult<A, N> {
  const candidates = parameters.abi.filter(
    (item): item is AbiFunction =>
      item.type === 'function' && item.name === parameters.functionName,
  )
  if (candidates.length === 1) {
    assertHex(parameters.data)
    const values = decodeTuple(
      compileFunction(candidates[0]!).outputs.nodes,
      parameters.data.slice(2),
      0,
    )
    return (
      values.length === 0 ? undefined : values.length === 1 ? values[0] : values
    ) as FunctionResult<A, N>
  }
  return prepareFunction(
    parameters as { abi: Abi; functionName: string; args?: readonly unknown[] },
  ).decode(parameters.data) as FunctionResult<A, N>
}

/** Resolve a function by its encodable arguments, rejecting ambiguous overloads. */
export function getAbiItem(parameters: {
  abi: Abi
  name: string
  args?: readonly unknown[]
}): AbiFunction {
  let found: AbiFunction | undefined
  for (const item of parameters.abi) {
    if (item.type !== 'function' || item.name !== parameters.name) continue
    try {
      const compiled = compileFunction(item)
      encodeTuple(
        compiled.inputs.nodes,
        parameters.args ?? [],
        compiled.inputs.headSize,
      )
    } catch {
      continue
    }
    if (found) throw new CetaneError('Ambiguous ABI overload.')
    found = item
  }
  if (!found) throw new CetaneError('No matching ABI function.')
  return found
}

export function encodeFunctionResult<
  const A extends Abi,
  N extends FunctionName<A>,
>(parameters: { abi: A; functionName: N; result: FunctionResult<A, N> }): Hex {
  const candidates = parameters.abi.filter(
    (item): item is AbiFunction =>
      item.type === 'function' && item.name === parameters.functionName,
  )
  if (candidates.length !== 1)
    throw new CetaneError('Expected one result ABI function.')
  const compiled = compileFunction(candidates[0]!)
  const values =
    compiled.outputs.nodes.length === 0
      ? []
      : compiled.outputs.nodes.length === 1
        ? [parameters.result]
        : parameters.result
  if (!Array.isArray(values)) throw new CetaneError('Expected output values.')
  return `0x${encodeTuple(compiled.outputs.nodes, values, compiled.outputs.headSize)}`
}

export function decodeFunctionData(parameters: { abi: Abi; data: Hex }): {
  functionName: string
  args: readonly unknown[]
} {
  assertHex(parameters.data)
  if (parameters.data.length < 10)
    throw new CetaneError('Missing function selector.')
  const selector = parameters.data.slice(2, 10).toLowerCase()
  const candidates = parameters.abi.filter(
    (item): item is AbiFunction =>
      item.type === 'function' && compileFunction(item).selector === selector,
  )
  if (candidates.length !== 1)
    throw new CetaneError('Unknown or ambiguous function selector.')
  const fn = candidates[0]!
  return {
    functionName: fn.name,
    args: decodeTuple(
      compileFunction(fn).inputs.nodes,
      parameters.data.slice(10),
      0,
    ),
  }
}

export function encodeDeployData(parameters: {
  abi: Abi
  bytecode: Hex
  args?: readonly unknown[]
}): Hex {
  assertHex(parameters.bytecode)
  const constructors = parameters.abi.filter(
    (item) => item.type === 'constructor',
  )
  if (constructors.length > 1)
    throw new CetaneError('Ambiguous constructor ABI.')
  const compiled = tuple(constructors[0]?.inputs ?? [])
  return `${parameters.bytecode}${encodeTuple(compiled.nodes, parameters.args ?? [], compiled.headSize)}`
}
