import { keccak_256 } from '@noble/hashes/sha3.js'
import type { Hash, Hex } from '../types.js'
import { bytesToHex, hexToBytes } from './bytes.js'

type KeccakBackend = (first: Hex | Uint8Array, second?: Uint8Array) => Hash
let backend: KeccakBackend | undefined

/** Internal installation hook; optional backends must validate before installing. */
export function installKeccakBackend(hash: KeccakBackend): void {
  backend = hash
}

export function keccak256(value: Hex | Uint8Array): Hash {
  return backend
    ? backend(value)
    : bytesToHex(
        keccak_256(typeof value === 'string' ? hexToBytes(value) : value),
      )
}

export function hashMessage(message: string | { raw: Hex | Uint8Array }): Hash {
  const bytes =
    typeof message === 'string'
      ? new TextEncoder().encode(message)
      : typeof message.raw === 'string'
        ? hexToBytes(message.raw)
        : message.raw
  const prefix = new TextEncoder().encode(
    `\x19Ethereum Signed Message:\n${bytes.length}`,
  )
  return backend
    ? backend(prefix, bytes)
    : bytesToHex(keccak_256.create().update(prefix).update(bytes).digest())
}
