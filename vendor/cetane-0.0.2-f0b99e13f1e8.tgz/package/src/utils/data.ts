import { CetaneError } from '../errors.js'
import type { Hex } from '../types.js'
import { bytesToHex } from './bytes.js'
import { assertHex } from './hex.js'

export function concatHex(values: readonly Hex[]): Hex {
  for (const value of values) assertHex(value)
  return `0x${values.map((value) => value.slice(2)).join('')}`
}

export function padHex(
  value: Hex,
  { size = 32, dir = 'left' }: { size?: number; dir?: 'left' | 'right' } = {},
): Hex {
  if (typeof value !== 'string' || !/^0x[0-9a-fA-F]*$/.test(value))
    throw new CetaneError('Expected hexadecimal data.')
  if (!Number.isSafeInteger(size) || size < 0 || value.length > 2 + size * 2)
    throw new CetaneError('Hex data exceeds the requested size.')
  if (dir !== 'left' && dir !== 'right')
    throw new CetaneError('Invalid padding direction.')
  return `0x${dir === 'left' ? value.slice(2).padStart(size * 2, '0') : value.slice(2).padEnd(size * 2, '0')}`
}

export function stringToHex(value: string, options?: { size?: number }): Hex {
  const encoded = bytesToHex(new TextEncoder().encode(value))
  return options?.size === undefined
    ? encoded
    : padHex(encoded, { size: options.size, dir: 'right' })
}

/** Integers use minimal quantities unless an explicit byte size is supplied. */
export function toHex(
  value: bigint | number | string | Uint8Array,
  options?: { size?: number },
): Hex {
  if (typeof value === 'string') return stringToHex(value, options)
  if (value instanceof Uint8Array) {
    const encoded = bytesToHex(value)
    return options?.size === undefined
      ? encoded
      : padHex(encoded, { size: options.size, dir: 'right' })
  }
  if (
    (typeof value !== 'bigint' &&
      (typeof value !== 'number' || !Number.isSafeInteger(value))) ||
    value < 0
  )
    throw new CetaneError('Expected an unsigned integer.')
  const hex = value.toString(16)
  const encoded: Hex = `0x${hex.length % 2 ? '0' : ''}${hex}`
  return options?.size === undefined ? `0x${hex}` : padHex(encoded, options)
}
