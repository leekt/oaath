import { CetaneError } from '../errors.js'
import type { Hex } from '../types.js'
import { assertHex } from './hex.js'

export type RlpValue = Hex | readonly RlpValue[]
/** Internal prefix shared by generic RLP and prepared transaction serialization. */
export function rlpPrefix(size: number, offset: number): string {
  if (size < 56) return (offset + size).toString(16)
  let hex = size.toString(16)
  if (hex.length % 2) hex = `0${hex}`
  return (offset + 55 + hex.length / 2).toString(16) + hex
}
/** Internal RLP item encoding without a hex prefix. */
export function encodeRlp(value: RlpValue): string {
  if (typeof value === 'string') {
    assertHex(value)
    const hex = value.slice(2)
    if (hex.length === 2 && Number.parseInt(hex, 16) < 128) return hex
    return rlpPrefix(hex.length / 2, 128) + hex
  }
  const encoded = value.map(encodeRlp).join('')
  return rlpPrefix(encoded.length / 2, 192) + encoded
}
export function toRlp(value: RlpValue): Hex {
  return `0x${encodeRlp(value)}`
}
export function toRlpInteger(value: bigint | number): Hex {
  if (typeof value === 'number' && !Number.isSafeInteger(value))
    throw new CetaneError('RLP integer must be safe.')
  if (value < 0) throw new CetaneError('RLP integer cannot be negative.')
  if (value === 0 || value === 0n) return '0x'
  const hex = value.toString(16)
  return `0x${hex.length % 2 ? '0' : ''}${hex}`
}
