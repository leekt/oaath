import { CetaneError } from '../errors.js'
import type { Address, Hex } from '../types.js'
import { concatHex } from './data.js'
import { keccak256 } from './hash.js'
import { assertAddress, assertHex } from './hex.js'
import { toRlp, toRlpInteger } from './rlp.js'

/** EIP-55 checksum. Chain-specific checksum extensions are intentionally unsupported. */
export function getAddress(address: string): Address {
  assertAddress(address)
  const lower = address.slice(2).toLowerCase()
  const hash = keccak256(new TextEncoder().encode(lower)).slice(2)
  return `0x${Array.from(lower, (char, index) => (Number.parseInt(hash[index]!, 16) >= 8 ? char.toUpperCase() : char)).join('')}`
}

export function isAddress(
  value: unknown,
  options: { strict?: boolean } = {},
): value is Address {
  if (typeof value !== 'string' || !/^0x[0-9a-fA-F]{40}$/.test(value))
    return false
  return (
    options.strict === false ||
    value === value.toLowerCase() ||
    value === getAddress(value)
  )
}

export function isAddressEqual(left: Address, right: Address): boolean {
  assertAddress(left)
  assertAddress(right)
  return left.toLowerCase() === right.toLowerCase()
}

export function getCreate2Address(input: {
  from: Address
  salt: Hex
  bytecodeHash: Hex
}): Address {
  assertAddress(input.from)
  assertHex(input.salt, 32)
  assertHex(input.bytecodeHash, 32)
  return getAddress(
    `0x${keccak256(concatHex(['0xff', input.from, input.salt, input.bytecodeHash])).slice(-40)}`,
  )
}

export function getContractAddress(
  input:
    | { opcode?: 'CREATE'; from: Address; nonce: bigint }
    | { opcode: 'CREATE2'; from: Address; salt: Hex; bytecodeHash: Hex },
): Address {
  if (input.opcode === 'CREATE2') return getCreate2Address(input)
  if (input.opcode !== undefined && input.opcode !== 'CREATE')
    throw new CetaneError('Invalid creation opcode.')
  assertAddress(input.from)
  return getAddress(
    `0x${keccak256(toRlp([input.from, toRlpInteger(input.nonce)])).slice(-40)}`,
  )
}
