import { secp256k1 } from '@noble/curves/secp256k1.js'
import type { Address, Hash, Hex } from '../types.js'
import { CetaneError } from '../errors.js'
import { getAddress } from './address.js'
import { hexToBytes } from './bytes.js'
import { keccak256 } from './hash.js'
import { assertHex } from './hex.js'

/** Recover a checksummed EOA from an exact digest and canonical ECDSA scalars. */
export function recoverAddress(input: {
  hash: Hash
  signature: { r: Hex; s: Hex; yParity: number }
}): Address {
  try {
    assertHex(input.hash, 32)
    assertHex(input.signature.r, 32)
    assertHex(input.signature.s, 32)
    if (input.signature.yParity !== 0 && input.signature.yParity !== 1)
      throw new Error()
    const signature = new Uint8Array(65)
    signature[0] = input.signature.yParity
    signature.set(hexToBytes(input.signature.r), 1)
    signature.set(hexToBytes(input.signature.s), 33)
    const recovered = secp256k1.recoverPublicKey(
      signature,
      hexToBytes(input.hash),
      { prehash: false },
    )
    const publicKey = secp256k1.Point.fromBytes(recovered).toBytes(false)
    return getAddress(`0x${keccak256(publicKey.subarray(1)).slice(-40)}`)
  } catch {
    throw new CetaneError('Invalid recovery input.')
  }
}
