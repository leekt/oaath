import type { Hex } from '../types.js'
import { CetaneError } from '../errors.js'

// Native byte codecs avoid JavaScript loops on current runtimes. Keep the
// fallback for the package's older Node and browser targets.
function callable<T>(method: T): T | undefined {
  return typeof method === 'function' ? method : undefined
}
const fromHex = callable(
  (Uint8Array as typeof Uint8Array & { fromHex?: (hex: string) => Uint8Array })
    .fromHex,
)
const setFromHex =
  fromHex &&
  callable(
    (
      Uint8Array.prototype as Uint8Array & {
        setFromHex?: (hex: string) => { read: number; written: number }
      }
    ).setFromHex,
  )
// Some native decoders truncate UTF-16 code units on their long-input path.
// Probe that path once; affected implementations need an explicit wide-digit
// guard. An unexpected probe failure also keeps the guard enabled.
function needsWideGuard(decode?: (hex: string) => unknown): boolean {
  try {
    decode?.('ｆｆ' + 'ab'.repeat(32))
    return decode !== undefined
  } catch (error) {
    return !(error instanceof SyntaxError)
  }
}
const checkWideHex =
  needsWideGuard(fromHex) ||
  needsWideGuard(setFromHex?.bind(new Uint8Array(33)))
// Validation does not expose the decoded bytes, so its buffer can be reused.
// Allocate a fixed 64 KiB lazily; larger inputs keep the temporary native path.
let validationBytes: Uint8Array | undefined
const toHex = callable(
  (Uint8Array.prototype as Uint8Array & { toHex?: () => string }).toHex,
)
const table = toHex
  ? undefined
  : Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, '0'))
const nibbles = fromHex ? undefined : new Uint8Array(128).fill(255)
if (nibbles) {
  const digits = '0123456789abcdefABCDEF'
  for (let i = 0; i < digits.length; i++)
    nibbles[digits.charCodeAt(i)] = i < 16 ? i : i - 6
}

function decodeNative(
  hex: string,
  target?: Uint8Array,
): Uint8Array | undefined {
  if (checkWideHex && /[\u0100-\uffff]/.test(hex)) return undefined
  try {
    if (target) {
      const result = setFromHex!.call(target, hex)
      // Reject truncated prefixes: setFromHex stops when its destination fills.
      return result.read === hex.length && result.written * 2 === hex.length
        ? target
        : undefined
    }
    return fromHex!(hex)
  } catch (error) {
    if (error instanceof SyntaxError) return undefined
    throw error
  }
}

/** Internal validator; callers check type, byte alignment and fixed length first. */
export function isHexData(value: string): boolean {
  // Small values avoid allocating; large values use the runtime's byte decoder.
  if (!fromHex || value.length <= 258) return /^0x[0-9a-f]*$/i.test(value)
  if (!/^0x/i.test(value)) return false
  return (
    decodeNative(
      value.slice(2),
      setFromHex && value.length <= 131_074
        ? (validationBytes ??= new Uint8Array(65_536))
        : undefined,
    ) !== undefined
  )
}

let hashingBytes: Uint8Array | undefined
let hashing = false
/** Internal synchronous use only: the callback must not retain the borrowed view. */
export function withHexBytes<T>(
  hex: Hex,
  consume: (bytes: Uint8Array) => T,
  fallback = consume,
): T {
  if (!setFromHex || hashing || hex.length > 131_074)
    return fallback(hexToBytes(hex))
  if (hex.length % 2 || !hex.startsWith('0x'))
    throw new CetaneError('Expected byte-aligned hex data.')
  hashing = true
  try {
    const bytes = decodeNative(
      hex.slice(2),
      (hashingBytes ??= new Uint8Array(65_536)),
    )
    if (!bytes) throw new CetaneError('Invalid hex digit.')
    return consume(new Uint8Array(bytes.buffer, 0, (hex.length - 2) / 2))
  } finally {
    hashing = false
  }
}
export function bytesToHex(bytes: Uint8Array): Hex {
  if (toHex) return `0x${toHex.call(bytes)}`
  let out = '0x'
  for (let i = 0; i < bytes.length; i++) out += table![bytes[i]!]!
  return out as Hex
}
export function hexToBytes(hex: Hex): Uint8Array {
  if (hex.length % 2 || !hex.startsWith('0x'))
    throw new CetaneError('Expected byte-aligned hex data.')
  if (fromHex) {
    const bytes = decodeNative(hex.slice(2))
    if (!bytes) throw new CetaneError('Invalid hex digit.')
    return bytes
  }
  const bytes = new Uint8Array((hex.length - 2) / 2)
  for (let i = 0; i < bytes.length; i++) {
    const high = nibbles![hex.charCodeAt(i * 2 + 2)] ?? 255
    const low = nibbles![hex.charCodeAt(i * 2 + 3)] ?? 255
    if ((high | low) > 15) throw new CetaneError('Invalid hex digit.')
    bytes[i] = high * 16 + low
  }
  return bytes
}
