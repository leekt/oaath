import { estimateFeesPerGas, validateFees } from '../actions/fees.js'
import { signTransaction } from '../accounts/sign.js'
import { CetaneError } from '../errors.js'
import { scopeContext, traceAsync, traceSync } from '../internal/trace.js'
import type { Execution, Fees, Hex } from '../types.js'
import { fromQuantity, toQuantity } from '../utils/hex.js'
import { toRlpInteger } from '../utils/rlp.js'
import type { RlpValue } from '../utils/rlp.js'
import { formatReceipt } from './receipt.js'
import type { RpcReceipt } from './receipt.js'
import { submitRaw } from './internal/submit.js'
import { prepareType2 } from './internal/type2.js'

const executions = new WeakSet<object>()

/** Attest the built-in ordinary EVM adapter without trusting caller-supplied labels. */
export function isEvmExecution(value: unknown): value is Execution {
  return typeof value === 'object' && value !== null && executions.has(value)
}

export function createExecution(): Execution {
  const execution: Execution = {
    supportsNoncePipelining: true,
    supportsParallelSigning: true,
    getNonce(context, account, key) {
      if (key !== 0n)
        throw new CetaneError(
          'This execution module only supports the default nonce key.',
        )
      return context
        .request<Hex>({
          method: 'eth_getTransactionCount',
          params: [account.address, 'pending'],
        })
        .then(fromQuantity)
    },
    async prepare(context, parameters) {
      if (
        parameters.sponsor === true ||
        (parameters.sponsor !== false && context.sponsor)
      )
        throw new CetaneError(
          'This execution module does not support sponsorship.',
        )
      if (parameters.calls.length !== 1)
        throw new CetaneError(
          'This account does not support atomic batched calls.',
        )
      if (parameters.account.encodeCalls)
        throw new CetaneError(
          'This execution module requires a native account.',
        )
      if (
        (parameters.nonceKey ?? 0n) !== 0n ||
        parameters.feeToken !== undefined ||
        parameters.validAfter !== undefined ||
        parameters.validBefore !== undefined
      )
        throw new CetaneError('Unsupported transaction capability.')
      const call = parameters.calls[0]!
      let nonce: bigint
      let fees: Fees
      let gas: bigint
      if (
        parameters.nonce !== undefined &&
        parameters.gas !== undefined &&
        parameters.maxFeePerGas !== undefined &&
        parameters.maxPriorityFeePerGas !== undefined
      ) {
        nonce = context.trace
          ? traceSync(context.trace, 'nonce.read', () => parameters.nonce!, {
              source: 'provided',
            })
          : parameters.nonce
        gas = context.trace
          ? traceSync(context.trace, 'gas.budget', () => parameters.gas!, {
              source: 'provided',
            })
          : parameters.gas
        fees = validateFees(context, {
          maxFeePerGas: parameters.maxFeePerGas,
          maxPriorityFeePerGas: parameters.maxPriorityFeePerGas,
        })
      } else {
        ;[nonce, fees, gas] = await Promise.all([
          context.trace
            ? parameters.nonce !== undefined
              ? traceSync(
                  context.trace,
                  'nonce.read',
                  () => parameters.nonce!,
                  { source: 'provided' },
                )
              : traceAsync(
                  context.trace,
                  'nonce.read',
                  (trace) =>
                    this.getNonce(
                      scopeContext(context, trace),
                      parameters.account,
                      0n,
                    ),
                  { source: 'rpc' },
                )
            : (parameters.nonce ??
              this.getNonce(context, parameters.account, 0n)),
          estimateFeesPerGas(context, parameters),
          context.trace
            ? parameters.gas !== undefined
              ? traceSync(context.trace, 'gas.budget', () => parameters.gas!, {
                  source: 'provided',
                })
              : traceAsync(context.trace, 'gas.estimate', (trace) =>
                  scopeContext(context, trace)
                    .request<Hex>({
                      method: 'eth_estimateGas',
                      params: [
                        {
                          from: parameters.account.address,
                          to: call.to,
                          data: call.data ?? '0x',
                          value: toQuantity(call.value ?? 0n),
                        },
                      ],
                    })
                    .then(fromQuantity),
                )
            : (parameters.gas ??
              context
                .request<Hex>({
                  method: 'eth_estimateGas',
                  params: [
                    {
                      from: parameters.account.address,
                      to: call.to,
                      data: call.data ?? '0x',
                      value: toQuantity(call.value ?? 0n),
                    },
                  ],
                })
                .then(fromQuantity)),
        ])
      }
      const fields: RlpValue[] = [
        toRlpInteger(context.chain.id),
        toRlpInteger(nonce),
        toRlpInteger(fees.maxPriorityFeePerGas),
        toRlpInteger(fees.maxFeePerGas),
        toRlpInteger(gas),
        call.to,
        toRlpInteger(call.value ?? 0n),
        call.data ?? '0x',
        [],
      ]
      const encoded = prepareType2(fields, context.trace)
      let raw: Hex | undefined
      return {
        transaction: {
          chainId: context.chain.id,
          from: parameters.account.address,
          calls: parameters.calls,
          nonce,
          executionGas: gas,
          gas,
          ...fees,
          maxFee: gas * fees.maxFeePerGas,
        },
        async sign({ signer, trace } = {}) {
          const signature = await (trace
            ? traceAsync(trace, 'sign.sender', () =>
                signTransaction(
                  parameters.account,
                  parameters,
                  encoded.hash,
                  signer,
                ),
              )
            : signTransaction(
                parameters.account,
                parameters,
                encoded.hash,
                signer,
              ))
          raw = encoded.serialize(signature, trace)
          const maxSize = context.chain.limits?.maxTransactionSize
          if (maxSize !== undefined && (raw.length - 2) / 2 > maxSize)
            throw new CetaneError('Transaction exceeds the chain size cap.')
        },
        async submit({ trace } = {}) {
          if (!raw)
            throw new CetaneError(
              'Transaction must be signed before submission.',
            )
          return submitRaw(scopeContext(context, trace).relay, raw, trace)
        },
      }
    },
    async getReceipt(context, hash) {
      const receipt = await context.request<RpcReceipt | null>({
        method: 'eth_getTransactionReceipt',
        params: [hash],
      })
      return receipt ? formatReceipt(receipt, hash) : null
    },
  }
  executions.add(execution)
  return Object.freeze(execution)
}
