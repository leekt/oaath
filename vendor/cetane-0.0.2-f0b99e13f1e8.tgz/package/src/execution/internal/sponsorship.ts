import { CetaneError } from '../../errors.js'
import type { Address, Hex, SponsorContext, Transport } from '../../types.js'
import {
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
  word,
} from '../../utils/hex.js'
import type {
  Operation,
  Sponsorship,
  SponsorStage,
  Version,
} from '../erc4337.js'

export type StubSponsorship = Sponsorship & { isFinal?: boolean }
const protectedFields = [
  'sender',
  'nonce',
  'callData',
  'initCode',
  'factory',
  'factoryData',
  'callGasLimit',
  'verificationGasLimit',
  'preVerificationGas',
  'maxFeePerGas',
  'maxPriorityFeePerGas',
  'signature',
  'authorization',
  'eip7702Auth',
]

/** Only sponsor-owned fields cross this boundary, including for custom callbacks. */
export function parseSponsorship(
  value: unknown,
  version: Version,
  stage: SponsorStage,
  rpc: boolean,
): StubSponsorship {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new CetaneError('Invalid sponsor response.')
  const result = value as Record<string, unknown>
  for (const key of protectedFields) {
    if (Object.hasOwn(result, key))
      throw new CetaneError(`Sponsor cannot change ${key}.`)
  }
  const paymaster: unknown = result.paymaster
  const paymasterData: unknown = result.paymasterData ?? '0x'
  if (result.paymasterAndData !== undefined)
    throw new CetaneError('Sponsor response must use split paymaster fields.')
  if (typeof paymaster !== 'string' || typeof paymasterData !== 'string')
    throw new CetaneError(
      'Sponsor must return a paymaster address and hex data.',
    )
  assertAddress(paymaster)
  assertHex(paymasterData)
  if (/^0x0{40}$/i.test(paymaster))
    throw new CetaneError('Sponsor returned a zero paymaster address.')
  const parsed: StubSponsorship = { paymaster, paymasterData }
  if (result.paymasterSignature !== undefined) {
    if (version !== '0.9' || typeof result.paymasterSignature !== 'string')
      throw new CetaneError(
        'Detached sponsor signatures require EntryPoint 0.9.',
      )
    assertHex(result.paymasterSignature)
    const size = (result.paymasterSignature.length - 2) / 2
    if (!size || size > 65535)
      throw new CetaneError('Invalid detached sponsor signature length.')
    parsed.paymasterSignature = result.paymasterSignature
  }
  for (const field of [
    'paymasterVerificationGasLimit',
    'paymasterPostOpGasLimit',
  ] as const) {
    if (result[field] === undefined) continue
    const gas = rpc ? fromQuantity(result[field]) : result[field]
    if (typeof gas !== 'bigint')
      throw new CetaneError(`Invalid sponsor ${field}.`)
    word(gas, 16)
    parsed[field] = gas
  }
  if (stage === 'stub' && parsed.paymasterPostOpGasLimit === undefined)
    throw new CetaneError('Sponsor must provide its post-operation gas limit.')
  if (stage === 'stub' && result.isFinal !== undefined) {
    if (typeof result.isFinal !== 'boolean')
      throw new CetaneError('Invalid sponsor isFinal flag.')
    parsed.isFinal = result.isFinal
  }
  return parsed
}

export function applySponsorship(
  operation: Operation,
  sponsorship: Sponsorship,
): void {
  operation.paymaster = sponsorship.paymaster
  operation.paymasterData = sponsorship.paymasterData ?? '0x'
  if (sponsorship.paymasterSignature !== undefined)
    operation.paymasterSignature = sponsorship.paymasterSignature
  if (sponsorship.paymasterVerificationGasLimit !== undefined)
    operation.paymasterVerificationGasLimit =
      sponsorship.paymasterVerificationGasLimit
  if (sponsorship.paymasterPostOpGasLimit !== undefined)
    operation.paymasterPostOpGasLimit = sponsorship.paymasterPostOpGasLimit
}

export function assertFinalSponsorship(
  operation: Operation,
  final: Sponsorship,
): void {
  if (final.paymaster.toLowerCase() !== operation.paymaster!.toLowerCase())
    throw new CetaneError('Sponsor changed the paymaster after gas estimation.')
  for (const field of [
    'paymasterVerificationGasLimit',
    'paymasterPostOpGasLimit',
  ] as const) {
    if (final[field] !== undefined && final[field] !== operation[field])
      throw new CetaneError('Sponsor changed gas limits after gas estimation.')
  }
  assertStubCoverage(
    operation.paymasterData ?? '0x',
    final.paymasterData ?? '0x',
    'Sponsor',
  )
  if (
    operation.paymasterSignature !== undefined ||
    final.paymasterSignature !== undefined
  )
    assertStubCoverage(
      operation.paymasterSignature ?? '0x',
      final.paymasterSignature ?? '0x',
      'Sponsor signature',
    )
}

/** ERC-7677 requires equal length and no more nonzero bytes in the final witness. */
export function assertStubCoverage(
  stub: Hex,
  final: Hex,
  label: string,
  exactLength = true,
): void {
  if (exactLength ? stub.length !== final.length : final.length > stub.length)
    throw new CetaneError(`${label} data changed length after gas estimation.`)
  let balance = 0
  for (let i = 2; i < stub.length; i += 2) {
    if (stub[i] !== '0' || stub[i + 1] !== '0') balance++
    if (i < final.length && (final[i] !== '0' || final[i + 1] !== '0'))
      balance--
  }
  if (balance < 0)
    throw new CetaneError(
      `${label} final data exceeds its estimation stub's calldata cost.`,
    )
}

export async function requestSponsorship(
  service: Transport,
  stage: SponsorStage,
  operation: Record<string, Hex>,
  entryPoint: Address,
  chainId: number,
  version: Version,
  context: SponsorContext,
): Promise<StubSponsorship> {
  const { signature: _signature, ...unsigned } = operation
  return parseSponsorship(
    await service.request({
      method:
        stage === 'stub' ? 'pm_getPaymasterStubData' : 'pm_getPaymasterData',
      params: [unsigned, entryPoint, toQuantity(chainId), context],
    }),
    version,
    stage,
    true,
  )
}
