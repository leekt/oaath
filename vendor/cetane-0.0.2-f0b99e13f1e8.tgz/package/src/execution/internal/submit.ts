import { CetaneError } from '../../errors.js'
import { traceSync } from '../../internal/trace.js'
import type { TraceContext } from '../../trace/types.js'
import type { Hash, Hex, Request } from '../../types.js'
import { keccak256 } from '../../utils/hash.js'
import { assertHex } from '../../utils/hex.js'

/** Start the network round trip before hashing the already-validated bytes. */
export async function submitRaw(
  request: Request,
  raw: Hex,
  trace?: TraceContext,
): Promise<Hash> {
  const pending = request<Hex>({
    method: 'eth_sendRawTransaction',
    params: [raw],
  })
  let expected: Hash
  try {
    expected = trace
      ? traceSync(trace, 'hash.ack', () => keccak256(raw))
      : keccak256(raw)
  } catch (error) {
    // The write has already started. If hashing fails, still handle a later
    // transport rejection; callers must treat this submission as uncertain.
    void pending.catch(() => {})
    throw error
  }
  const result = await pending
  if (trace) traceSync(trace, 'ack.validate', () => validate(result, expected))
  else validate(result, expected)
  return result
}

function validate(result: Hex, expected: Hash): void {
  assertHex(result, 32)
  if (result.toLowerCase() !== expected)
    throw new CetaneError(
      'Submission endpoint returned an unexpected transaction identifier.',
    )
}
