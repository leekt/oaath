import { CetaneError } from '../../errors.js'
import { traceSync } from '../../internal/trace.js'
import type { TraceContext } from '../../trace/types.js'
import type { Hex } from '../../types.js'
import { assertHex } from '../../utils/hex.js'
import { keccak256 } from '../../utils/hash.js'
import { encodeRlp, rlpPrefix } from '../../utils/rlp.js'
import type { RlpValue } from '../../utils/rlp.js'

/** Signature scalars have at most 32 bytes; strip zero bytes without a bigint round trip. */
function signatureScalar(signature: Hex, start: number): string {
  const end = start + 64
  while (start < end && signature.startsWith('00', start)) start += 2
  const bytes = (end - start) / 2
  if (bytes === 0) return '80'
  const value = signature.slice(start, end).toLowerCase()
  if (bytes === 1 && Number.parseInt(value, 16) < 128) return value
  return (0x80 + bytes).toString(16) + value
}

/** Encode and validate immutable fields once; only the signature changes the outer list. */
export function prepareType2(
  fields: readonly RlpValue[],
  trace?: TraceContext,
) {
  const body = trace
    ? traceSync(trace, 'encoding', () => fields.map(encodeRlp).join(''))
    : fields.map(encodeRlp).join('')
  const unsigned = rlpPrefix(body.length / 2, 192) + body
  return {
    hash: trace
      ? traceSync(trace, 'hash.signing', () => keccak256(`0x02${unsigned}`))
      : keccak256(`0x02${unsigned}`),
    // Signing a prepared plan can belong to a later operation.
    serialize: function serialize(
      signature: Hex,
      phaseTrace?: TraceContext,
    ): Hex {
      if (phaseTrace)
        return traceSync(phaseTrace, 'serialization', () =>
          serialize(signature),
        )
      assertHex(signature, 65)
      const v = Number.parseInt(signature.slice(-2), 16)
      const parity = v >= 27 ? v - 27 : v
      if (parity !== 0 && parity !== 1)
        throw new CetaneError('Invalid recovery parity.')
      const suffix =
        (parity === 0 ? '80' : '01') +
        signatureScalar(signature, 2) +
        signatureScalar(signature, 66)
      return `0x02${rlpPrefix((body.length + suffix.length) / 2, 192)}${body}${suffix}`
    },
  }
}
