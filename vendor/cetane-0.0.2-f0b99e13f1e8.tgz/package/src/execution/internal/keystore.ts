import { CetaneError } from '../../errors.js'
import type { Address, Hex } from '../../types.js'
import { addressWord, assertAddress, assertHex, word } from '../../utils/hex.js'
import { keccak256 } from '../../utils/hash.js'
import { toRlpInteger } from '../../utils/rlp.js'
import type { RlpValue } from '../../utils/rlp.js'

export const k1: Address = '0x0000000000000000000000000000000000000001'
export const stubSignature: Hex = `0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798${'7f'.repeat(32)}1b`
export type InitialActor = Readonly<{
  actorId: Hex
  authenticator: Address
  scope: number
  policyData: Hex
}>
export type ConfigChange = Readonly<{ type: 0 | 1 | 2 | 3 | 4; payload: Hex }>
export type AccountChange =
  | Readonly<{
      type: 'create'
      salt: Hex
      bytecode: Hex
      actors: readonly InitialActor[]
    }>
  | Readonly<{
      type: 'config'
      channel: 0 | 1
      sequence: bigint
      changes: readonly ConfigChange[]
      auth: Hex
    }>
  | Readonly<{ type: 'delegate'; target: Address }>

export function validateActor(actor: InitialActor): void {
  assertHex(actor.actorId, 32)
  assertAddress(actor.authenticator)
  if (BigInt(actor.actorId) === 0n || BigInt(actor.authenticator) === 0n)
    throw new CetaneError('Actor and authenticator must be nonzero.')
  if (!Number.isInteger(actor.scope))
    throw new CetaneError('Invalid actor scope.')
  word(BigInt(actor.scope), 2)
  assertHex(actor.policyData)
  if (actor.policyData.length !== 2 && actor.policyData.length !== 106)
    throw new CetaneError('Policy data must be empty or 52 bytes.')
}

export function validateCreation(
  change: Extract<AccountChange, { type: 'create' }>,
): void {
  assertHex(change.salt, 32)
  assertHex(change.bytecode)
  const size = (change.bytecode.length - 2) / 2
  if (size === 0 || size > 24_576)
    throw new CetaneError('Account bytecode must fit the EIP-170 code limit.')
  if (!change.actors.length)
    throw new CetaneError('At least one initial actor is required.')
  let previous = 0n
  for (const actor of change.actors) {
    validateActor(actor)
    const id = BigInt(actor.actorId)
    if (id <= previous)
      throw new CetaneError(
        'Initial actors must be strictly sorted and unique.',
      )
    previous = id
  }
}

export function creationAddress(
  keystore: Address,
  change: Extract<AccountChange, { type: 'create' }>,
): Address {
  assertAddress(keystore)
  validateCreation(change)
  const leaves = change.actors
    .map((actor) =>
      keccak256(
        `${actor.actorId}${actor.authenticator.slice(2)}${word(BigInt(actor.scope), 2)}${actor.policyData.slice(2)}` as Hex,
      ).slice(2),
    )
    .join('')
  const salt = keccak256(`${change.salt}${keccak256(`0x${leaves}`).slice(2)}`)
  const size = word(BigInt((change.bytecode.length - 2) / 2), 2)
  const codeHash = keccak256(
    `0x61${size}600e60003961${size}6000f3${change.bytecode.slice(2)}`,
  )
  return `0x${keccak256(`0xff${keystore.slice(2)}${salt.slice(2)}${codeHash.slice(2)}`).slice(-40)}`
}

export type WireFormat = 'draft' | 'base-zenith'
export function changeTag(
  type: AccountChange['type'],
  format: WireFormat,
): 0 | 1 | 2 | 3 {
  if (format !== 'draft' && format !== 'base-zenith')
    throw new CetaneError('Unsupported account-change wire format.')
  return format === 'draft'
    ? type === 'create'
      ? 0
      : type === 'config'
        ? 1
        : 2
    : type === 'create'
      ? 2
      : type === 'config'
        ? 3
        : 1
}
export function changeFields(
  changes: readonly AccountChange[],
  format: WireFormat = 'draft',
): RlpValue[] {
  let creations = 0,
    delegations = 0
  return changes.map((change, index) => {
    if (change.type === 'create') {
      if (index !== 0 || ++creations > 1)
        throw new CetaneError('A single create entry must come first.')
      validateCreation(change)
      return [
        toRlpInteger(changeTag(change.type, format)),
        change.salt,
        change.bytecode,
        change.actors.map((actor) => [
          actor.actorId,
          actor.authenticator,
          toRlpInteger(actor.scope),
          actor.policyData,
        ]),
      ]
    }
    if (change.type === 'delegate') {
      if (++delegations > 1 || creations)
        throw new CetaneError(
          'Creation and delegation cannot be combined; only one delegation is allowed.',
        )
      assertAddress(change.target)
      return [toRlpInteger(changeTag(change.type, format)), change.target]
    }
    if (
      change.type !== 'config' ||
      (change.channel !== 0 && change.channel !== 1)
    )
      throw new CetaneError('Invalid account change.')
    word(change.sequence, 8)
    assertHex(change.auth)
    if (!change.changes.length)
      throw new CetaneError('Account changes cannot be empty.')
    return [
      toRlpInteger(changeTag(change.type, format)),
      toRlpInteger(change.channel),
      toRlpInteger(change.sequence),
      change.changes.map((item) => {
        if (!Number.isInteger(item.type) || item.type < 0 || item.type > 4)
          throw new CetaneError('Invalid configuration operation.')
        assertHex(item.payload)
        return [toRlpInteger(item.type), item.payload]
      }),
      change.auth,
    ]
  })
}

/** Normalize canonical k1 authorization without recovering or retaining an address. */
export function formatAuthorization(
  authenticator: Address,
  signature: Hex,
): Hex {
  assertAddress(authenticator)
  assertHex(signature)
  if (authenticator.toLowerCase() === k1) {
    assertHex(signature, 65)
    const v = Number.parseInt(signature.slice(-2), 16)
    const parity = v >= 27 ? v - 27 : v
    const r = BigInt(`0x${signature.slice(2, 66)}`)
    const s = BigInt(`0x${signature.slice(66, 130)}`)
    if (
      (parity !== 0 && parity !== 1) ||
      r === 0n ||
      r >=
        0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n ||
      s === 0n ||
      s > 0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0n
    )
      throw new CetaneError('Invalid canonical k1 signature.')
    signature = `${signature.slice(0, -2)}${(parity + 27).toString(16)}` as Hex
  }
  return `${authenticator}${signature.slice(2)}`
}

let batchType: Hex | undefined, changeType: Hex | undefined
export function changesHash(
  account: Address,
  chainId: number,
  sequence: bigint,
  changes: readonly ConfigChange[],
): Hex {
  assertAddress(account)
  word(sequence, 8)
  batchType ??= keccak256(
    new TextEncoder().encode(
      'SignedAccountChangeBatch(address account,uint256 chainId,uint64 sequence,AccountChange[] changes)AccountChange(uint8 changeType,bytes payload)',
    ),
  )
  const type = (changeType ??= keccak256(
    new TextEncoder().encode('AccountChange(uint8 changeType,bytes payload)'),
  ))
  const leaves = changes
    .map((change) =>
      keccak256(
        `${type}${word(BigInt(change.type))}${keccak256(change.payload).slice(2)}`,
      ).slice(2),
    )
    .join('')
  return keccak256(
    `${batchType}${addressWord(account)}${word(BigInt(chainId))}${word(sequence)}${keccak256(`0x${leaves}`).slice(2)}`,
  )
}
