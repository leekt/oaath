import { estimateFeesPerGas } from '../actions/fees.js'
import { signTransaction } from '../accounts/sign.js'
import { CetaneError } from '../errors.js'
import { scopeContext, traceAsync, traceSync } from '../internal/trace.js'
import type { Address, Call, Execution, Fees, Hex, Signer } from '../types.js'
import {
  addressWord,
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
  word,
} from '../utils/hex.js'
import { keccak256 } from '../utils/hash.js'
import { toRlp, toRlpInteger } from '../utils/rlp.js'
import type { RlpValue } from '../utils/rlp.js'
import { formatReceipt } from './receipt.js'
import type { RpcReceipt } from './receipt.js'
import { submitRaw } from './internal/submit.js'

export type Envelope = Fees & {
  chainId: number
  calls: readonly Call[]
  nonce: bigint
  nonceKey: bigint
  gas: bigint
  feeToken?: Address
  validAfter?: number
  validBefore?: number
}
// Normalize synchronous signer throws before joining independent authorizations.
async function signHash(signer: Signer, hash: Hex): Promise<Hex> {
  return signer.sign({ hash })
}
function fields(envelope: Envelope, payer: RlpValue = '0x'): RlpValue[] {
  return [
    toRlpInteger(envelope.chainId),
    toRlpInteger(envelope.maxPriorityFeePerGas),
    toRlpInteger(envelope.maxFeePerGas),
    toRlpInteger(envelope.gas),
    envelope.calls.map((call) => [
      call.to,
      toRlpInteger(call.value ?? 0n),
      call.data ?? '0x',
    ]),
    [],
    toRlpInteger(envelope.nonceKey),
    toRlpInteger(envelope.nonce),
    envelope.validBefore === undefined
      ? '0x'
      : toRlpInteger(envelope.validBefore),
    envelope.validAfter === undefined
      ? '0x'
      : toRlpInteger(envelope.validAfter),
    payer === '0x00' ? '0x' : (envelope.feeToken ?? '0x'),
    payer,
    [],
  ]
}
function signatureParts(signature: Hex): { parity: number; r: Hex; s: Hex } {
  assertHex(signature, 65)
  const v = Number.parseInt(signature.slice(-2), 16)
  const parity = v >= 27 ? v - 27 : v
  if (parity !== 0 && parity !== 1)
    throw new CetaneError('Invalid recovery parity.')
  return {
    parity,
    r: `0x${signature.slice(2, 66)}`,
    s: `0x${signature.slice(66, 130)}`,
  }
}
/** Infrastructure-level codec; callers normally use prepareTransactionRequest. */
export function serialize(
  envelope: Envelope,
  options: {
    signature?: Hex
    payerSignature?: Hex
    sponsored?: boolean
    payerSender?: Address
  } = {},
): Hex {
  let payer: RlpValue = options.sponsored ? '0x00' : '0x'
  if (options.payerSignature) {
    const { parity, r, s } = signatureParts(options.payerSignature)
    payer = [
      toRlpInteger(parity),
      toRlpInteger(BigInt(r)),
      toRlpInteger(BigInt(s)),
    ]
  }
  const values = fields(envelope, options.payerSender ?? payer)
  if (options.signature) {
    const { parity, r, s } = signatureParts(options.signature)
    values.push(`${r}${s.slice(2)}${(parity + 27).toString(16)}`)
  }
  return `0x${options.payerSender ? '78' : '76'}${toRlp(values).slice(2)}`
}

export function createExecution(
  options: { feeToken?: Address; feePayer?: Signer } = {},
): Execution {
  if (options.feeToken) assertAddress(options.feeToken)
  return {
    nativeAA: 'tempo',
    async getNonce(context, account, key) {
      word(key)
      if (key === 0n)
        return fromQuantity(
          await context.request({
            method: 'eth_getTransactionCount',
            params: [account.address, 'pending'],
          }),
        )
      if (key === (1n << 256n) - 1n)
        throw new CetaneError(
          'Expiring nonces require a dedicated nonce policy.',
        )
      const result = await context.request<Hex>({
        method: 'eth_call',
        params: [
          {
            to: '0x4e4f4e4345000000000000000000000000000000',
            data: `0x89535803${addressWord(account.address)}${word(key)}`,
          },
          'pending',
        ],
      })
      assertHex(result, 32)
      return BigInt(result)
    },
    async prepare(context, parameters) {
      const sponsor =
        parameters.sponsor === false
          ? undefined
          : (context.sponsor ?? options.feePayer)
      if (parameters.sponsor === true && !sponsor)
        throw new CetaneError(
          'Sponsorship was requested, but no sponsor is configured.',
        )
      if (sponsor && ('request' in sponsor || 'account' in sponsor))
        throw new CetaneError(
          'This execution module requires a local fee payer.',
        )
      if (sponsor && !sponsor.address)
        throw new CetaneError('A fee payer address is required.')
      if (parameters.account.encodeCalls)
        throw new CetaneError(
          'This execution module requires a native account.',
        )
      for (const call of parameters.calls)
        if ((call.value ?? 0n) !== 0n)
          throw new CetaneError(
            'Tempo does not support native value transfers. Use a token call.',
          )
      const nonceKey = parameters.nonceKey ?? 0n
      word(nonceKey)
      if (nonceKey === (1n << 256n) - 1n)
        throw new CetaneError(
          'Expiring nonces require a dedicated nonce policy.',
        )
      for (const timestamp of [parameters.validAfter, parameters.validBefore])
        if (
          timestamp !== undefined &&
          (!Number.isSafeInteger(timestamp) || timestamp < 0)
        )
          throw new CetaneError('Invalid validity timestamp.')
      if (
        parameters.validBefore !== undefined &&
        parameters.validBefore <= (parameters.validAfter ?? 0)
      )
        throw new CetaneError('validBefore must be after validAfter.')
      const feeToken = parameters.feeToken ?? options.feeToken
      if (feeToken) assertAddress(feeToken)
      const [nonce, fees] = await Promise.all([
        context.trace
          ? parameters.nonce !== undefined
            ? traceSync(context.trace, 'nonce.read', () => parameters.nonce!, {
                source: 'provided',
              })
            : traceAsync(
                context.trace,
                'nonce.read',
                (trace) =>
                  this.getNonce(
                    scopeContext(context, trace),
                    parameters.account,
                    nonceKey,
                  ),
                { source: 'rpc' },
              )
          : (parameters.nonce ??
            this.getNonce(context, parameters.account, nonceKey)),
        estimateFeesPerGas(context, parameters),
      ])
      word(nonce, 8)
      const rpc = {
        type: '0x76',
        from: parameters.account.address,
        nonce: toQuantity(nonce),
        nonceKey: toQuantity(nonceKey),
        calls: parameters.calls.map((call) => ({
          to: call.to,
          data: call.data ?? '0x',
          value: toQuantity(call.value ?? 0n),
        })),
        maxFeePerGas: toQuantity(fees.maxFeePerGas),
        maxPriorityFeePerGas: toQuantity(fees.maxPriorityFeePerGas),
        ...(feeToken ? { feeToken } : {}),
        ...(sponsor ? { feePayer: sponsor.address } : {}),
        ...(parameters.validAfter !== undefined
          ? { validAfter: toQuantity(parameters.validAfter) }
          : {}),
        ...(parameters.validBefore !== undefined
          ? { validBefore: toQuantity(parameters.validBefore) }
          : {}),
      }
      const gas = context.trace
        ? parameters.gas !== undefined
          ? traceSync(context.trace, 'gas.budget', () => parameters.gas!, {
              source: 'provided',
            })
          : fromQuantity(
              await traceAsync(context.trace, 'gas.estimate', (trace) =>
                scopeContext(context, trace).request<Hex>({
                  method: 'eth_estimateGas',
                  params: [rpc],
                }),
              ),
            )
        : (parameters.gas ??
          fromQuantity(
            await context.request({ method: 'eth_estimateGas', params: [rpc] }),
          ))
      const envelope: Envelope = {
        ...fees,
        chainId: context.chain.id,
        calls: parameters.calls,
        nonce,
        nonceKey,
        gas,
        ...(feeToken ? { feeToken } : {}),
        ...(parameters.validAfter !== undefined
          ? { validAfter: parameters.validAfter }
          : {}),
        ...(parameters.validBefore !== undefined
          ? { validBefore: parameters.validBefore }
          : {}),
      }
      const unsigned = context.trace
        ? traceSync(context.trace, 'encoding', () =>
            serialize(envelope, { sponsored: !!sponsor }),
          )
        : serialize(envelope, { sponsored: !!sponsor })
      const hash = context.trace
        ? traceSync(context.trace, 'hash.signing', () => keccak256(unsigned), {
            source: 'sender',
          })
        : keccak256(unsigned)
      let raw: Hex | undefined
      return {
        transaction: {
          ...fees,
          chainId: context.chain.id,
          from: parameters.account.address,
          calls: parameters.calls,
          nonce,
          executionGas: gas,
          gas,
          maxFee: gas * fees.maxFeePerGas,
          ...(feeToken ? { feeToken } : {}),
        },
        async sign({ signer, trace } = {}) {
          const [signature, payerSignature] = await Promise.all([
            trace
              ? traceAsync(trace, 'sign.sender', () =>
                  signTransaction(parameters.account, parameters, hash, signer),
                )
              : signTransaction(parameters.account, parameters, hash, signer),
            sponsor
              ? trace
                ? traceAsync(trace, 'sign.payer', (payerTrace) => {
                    const payerEncoded = traceSync(payerTrace, 'encoding', () =>
                      serialize(envelope, {
                        payerSender: parameters.account.address,
                      }),
                    )
                    const payerHash = traceSync(
                      payerTrace,
                      'hash.signing',
                      () => keccak256(payerEncoded),
                      { source: 'payer' },
                    )
                    return signHash(sponsor, payerHash)
                  })
                : signHash(
                    sponsor,
                    keccak256(
                      serialize(envelope, {
                        payerSender: parameters.account.address,
                      }),
                    ),
                  )
              : undefined,
          ])
          raw = trace
            ? traceSync(trace, 'serialization', () =>
                serialize(envelope, {
                  signature,
                  ...(payerSignature ? { payerSignature } : {}),
                }),
              )
            : serialize(envelope, {
                signature,
                ...(payerSignature ? { payerSignature } : {}),
              })
          if (
            context.chain.limits?.maxTransactionSize !== undefined &&
            (raw.length - 2) / 2 > context.chain.limits.maxTransactionSize
          )
            throw new CetaneError('Transaction exceeds the chain size cap.')
        },
        async submit({ trace } = {}) {
          if (!raw)
            throw new CetaneError(
              'Transaction must be signed before submission.',
            )
          return submitRaw(scopeContext(context, trace).relay, raw, trace)
        },
      }
    },
    async getReceipt(context, hash) {
      const receipt = await context.request<RpcReceipt | null>({
        method: 'eth_getTransactionReceipt',
        params: [hash],
      })
      return receipt ? formatReceipt(receipt, hash) : null
    },
  }
}
