import { createClient } from './client.js'
import type { ClientParameters } from './client.js'
import type {
  Client,
  SendTransactionParameters,
  SendCallsParameters,
  PreparedTransaction,
  Signer,
} from './types.js'
import {
  sendTransaction,
  sendCalls,
  prepareTransactionRequest,
  prepareCalls,
  sendPreparedTransaction,
  estimateGas,
} from './actions/send.js'
import {
  getBalance,
  getBlockNumber,
  getBlock,
  getChainId,
  getCode,
  call,
} from './actions/read.js'
import { estimateFeesPerGas } from './actions/fees.js'
import {
  getTransactionReceipt,
  waitForTransactionReceipt,
} from './actions/receipt.js'
import { readContract, writeContract } from './actions/contract.js'
import { resetNonce } from './actions/nonce.js'
import {
  prepareAuthorization,
  updateAuthorization,
} from './actions/authorization.js'
import { prepareModuleUpdate, updateModules } from './actions/modules.js'

type Bound<F> = F extends (client: Client, parameters: infer P) => infer R
  ? (parameters: P) => R
  : never
export function publicActions(client: Client) {
  return {
    getBalance: ((p) => getBalance(client, p)) as Bound<typeof getBalance>,
    getBlockNumber: () => getBlockNumber(client),
    getBlock: (p: Parameters<typeof getBlock>[1] = {}) => getBlock(client, p),
    getChainId: (p: Parameters<typeof getChainId>[1] = {}) =>
      getChainId(client, p),
    getCode: ((p) => getCode(client, p)) as Bound<typeof getCode>,
    call: ((p) => call(client, p)) as Bound<typeof call>,
    estimateFeesPerGas: (p: Parameters<typeof estimateFeesPerGas>[1] = {}) =>
      estimateFeesPerGas(client, p),
    getTransactionReceipt: ((p) => getTransactionReceipt(client, p)) as Bound<
      typeof getTransactionReceipt
    >,
    waitForTransactionReceipt: ((p) =>
      waitForTransactionReceipt(client, p)) as Bound<
      typeof waitForTransactionReceipt
    >,
    readContract: <
      const A extends import('abitype').Abi,
      N extends import('./utils/abi.js').FunctionName<A, 'view' | 'pure'>,
    >(
      p: Parameters<typeof readContract<A, N>>[1],
    ) => readContract<A, N>(client, p),
  }
}
export function walletActions(client: Client) {
  return {
    prepareAuthorization: (p: Parameters<typeof prepareAuthorization>[1]) =>
      prepareAuthorization(client, p),
    updateAuthorization: (p: Parameters<typeof updateAuthorization>[1]) =>
      updateAuthorization(client, p),
    prepareModuleUpdate: (p: Parameters<typeof prepareModuleUpdate>[1]) =>
      prepareModuleUpdate(client, p),
    updateModules: (p: Parameters<typeof updateModules>[1]) =>
      updateModules(client, p),
    sendTransaction: (p: SendTransactionParameters) =>
      sendTransaction(client, p),
    sendCalls: (p: SendCallsParameters) => sendCalls(client, p),
    prepareTransactionRequest: (p: SendTransactionParameters) =>
      prepareTransactionRequest(client, p),
    prepareCalls: (p: SendCallsParameters) => prepareCalls(client, p),
    sendPreparedTransaction: (
      p: PreparedTransaction,
      options: { signer?: Signer } = {},
    ) => sendPreparedTransaction(client, p, options),
    estimateGas: (p: SendTransactionParameters) => estimateGas(client, p),
    resetNonce: (p: Parameters<typeof resetNonce>[1] = {}) =>
      resetNonce(client, p),
    writeContract: <
      const A extends import('abitype').Abi,
      N extends import('./utils/abi.js').FunctionName<
        A,
        'nonpayable' | 'payable'
      >,
    >(
      p: Parameters<typeof writeContract<A, N>>[1],
    ) => writeContract<A, N>(client, p),
  }
}
export function createPublicClient(parameters: ClientParameters) {
  return createClient(parameters).extend(publicActions)
}
export function createWalletClient(parameters: ClientParameters) {
  return createClient(parameters).extend(walletActions)
}
