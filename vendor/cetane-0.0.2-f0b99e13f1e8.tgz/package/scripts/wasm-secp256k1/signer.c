#include <stddef.h>
#include <stdint.h>
#include "secp256k1-0.7.1/include/secp256k1.h"
#include "secp256k1-0.7.1/include/secp256k1_preallocated.h"
#include "secp256k1-0.7.1/include/secp256k1_recovery.h"

#define EXPORT(name) __attribute__((export_name(name)))
static _Alignas(16) unsigned char context_memory[4096];
static _Alignas(16) unsigned char io[161];
static secp256k1_context *context;

static void wipe_bytes(void *pointer, size_t length) {
    volatile unsigned char *bytes = pointer;
    while (length--) *bytes++ = 0;
}

void secp256k1_default_illegal_callback_fn(const char *message, void *data) {
    (void)message; (void)data; __builtin_trap();
}
void secp256k1_default_error_callback_fn(const char *message, void *data) {
    (void)message; (void)data; __builtin_trap();
}

EXPORT("buffer") uintptr_t get_buffer(void) { return (uintptr_t)io; }
EXPORT("wipe") void wipe(void) { wipe_bytes(io, sizeof(io)); }

EXPORT("initialize") int initialize(void) {
    size_t required = secp256k1_context_preallocated_size(SECP256K1_CONTEXT_NONE);
    if (required > sizeof(context_memory)) return 0;
    context = secp256k1_context_preallocated_create(context_memory, SECP256K1_CONTEXT_NONE);
    if (!context) return 0;
    int result = secp256k1_context_randomize(context, io + 129);
    wipe_bytes(io + 129, 32);
    return result;
}

EXPORT("public_key") int public_key(void) {
    if (!context) return 0;
    secp256k1_pubkey public_key;
    size_t length = 65;
    int result = secp256k1_ec_pubkey_create(context, &public_key, io);
    if (result) result = secp256k1_ec_pubkey_serialize(context, io + 64, &length, &public_key, SECP256K1_EC_UNCOMPRESSED);
    wipe_bytes(&public_key, sizeof(public_key));
    wipe_bytes(io, 64);
    return result && length == 65;
}

EXPORT("sign") int sign_digest(void) {
    if (!context) return 0;
    secp256k1_ecdsa_recoverable_signature signature;
    int recovery = 0;
    int result = secp256k1_ecdsa_sign_recoverable(context, &signature, io + 32, io, NULL, NULL);
    if (result) result = secp256k1_ecdsa_recoverable_signature_serialize_compact(context, io + 64, &recovery, &signature);
    io[128] = (unsigned char)(27 + recovery);
    wipe_bytes(&signature, sizeof(signature));
    wipe_bytes(io, 64);
    return result;
}
