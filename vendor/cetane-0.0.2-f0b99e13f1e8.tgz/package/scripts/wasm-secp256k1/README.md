The optional `cetane/accounts/wasm` signer independently builds the unmodified
[Bitcoin Core libsecp256k1 v0.7.1 release](https://github.com/bitcoin-core/secp256k1/releases/tag/v0.7.1).
It uses upstream public context, public-key and recoverable-ECDSA APIs. No Ox,
Libauth, tiny-secp256k1, custom scalar arithmetic, or custom nonce implementation
is used at build time or runtime.

Build with Zig 0.16.0 and Node 22 or newer:

```sh
ZIG=/path/to/zig node scripts/wasm-secp256k1/build.mjs --check
ZIG=/path/to/zig node scripts/wasm-secp256k1/build.mjs --table 86 --check
```

The script downloads and checks the pinned upstream archive. To build without
network access, supply `--archive /path/to/secp256k1-v0.7.1.tar.gz`. Omit `--check`
to rewrite the generated TypeScript binary. A cached Zig toolchain directory may
be supplied as `ZIG_GLOBAL_CACHE_DIR`; this changes no compiler options.
`--table 22` is the default and preserves the original binary. `--table 86`
selects the separate `cetane/accounts/wasm/large` entry's generated module.
Each configuration checks its pinned binary checksum and length before writing
or comparing generated source. Only the selected output is touched.

- Source: `https://codeload.github.com/bitcoin-core/secp256k1/tar.gz/refs/tags/v0.7.1`
- Source archive SHA-256: `958f204dbafc117e73a2604285dc2eb2a5128344d3499c114dcba5de54cb7a9e`
- Binary SHA-256: `961bff263fd3aba5c2e4e0f6790b67a67923dc745f04838a0fa301774e9f5571`
- Target: `wasm32-wasi` reactor, `-O3 -flto`, recovery module only.
- Arithmetic: upstream `USE_FORCE_WIDEMUL_INT64`, avoiding emulated 128-bit multiplication.
- Generator table: upstream supported 22 KiB choice, `COMB_BLOCKS=11`, `COMB_TEETH=6`.
- Fixed linear memory: 128 KiB including a 64 KiB stack; binary: 67,957 bytes.

The experimental larger entry uses the same source, toolchain, wrapper, recovery
module and arithmetic, with these explicit differences:

- Binary SHA-256: `18e41597c54c332f8f440fdb9d6caeb8c808e3ffbc810ae9ebe157f870e39d29`.
- Generator table: upstream supported 86 KiB choice, `COMB_BLOCKS=43`, `COMB_TEETH=6`.
- Fixed linear memory: 192 KiB including a 64 KiB stack; binary: 132,105 bytes.
- Generated module: `src/accounts/internal/wasm/secp256k1-large.wasm.ts`.

The raw binary adds 64,148 bytes and fixed WASM memory adds 65,536 bytes. Each
entry's import graph includes only its own binary. The secure loader and signer
factory are shared source; each entry retains an independent lazy initialization
Promise, retry state and context. Neither initialization nor failure in one entry
selects or falls back to the other. Signing stays synchronous after setup.

The only host import is WASI `random_get`, supplied from secure
`crypto.getRandomValues` for libc's stack canary. Reactor initialization runs
before context initialization. A separate secure 32-byte seed randomizes the
preallocated upstream curve context. The seed and per-operation scratch are
explicitly cleared. Each successful factory retains its decoded private key in
a JavaScript closure, as the default signer does. This is not a general memory
erasure guarantee for the VM or caller-provided key string.

Runtime known-answer checks cover public-key derivation, recoverable low-S
signatures, RFC 6979 reduction for a digest equal to the curve order, and invalid
keys before the shared context becomes available. The browser-isolated tests in
`test/wasm-signing.test.ts` additionally compare 424 independent reference vectors
per entry (848 per suite run), exercise concurrent factories, and verify error
handling, cross-entry retry/key isolation and scratch cleanup.

The [integrated comparison](../../bench/runs/20261003-large-signer-integrated/report.md)
measured 0.4–0.6 microsecond improvements for empty and 24 KiB public EOA sends in
all three Node 25.2.1 rounds on an Apple M4 Pro. Node 4 KiB results were mixed,
and Bun 1.4.2 gains varied by round. The packed browser fixtures measured 52,195
gzip bytes for the default entry and 117,650 for the larger entry; startup was
not measured. The report includes exact submissions, CPU/RAM observations and
the two independent offline larger-binary reproductions. The earlier
[isolated experiment](../../bench/runs/20261003-signer86/report.md) remains
separate. Applications can opt into the experimental larger entry and measure
their own workload.

The upstream and linked toolchain license notices are distributed alongside the
binary module under `src/accounts/internal/wasm/LICENSE.*`. They cover
libsecp256k1, Zig compiler runtime, and the linked WASI libc/musl support. Cetane's
small C wrapper is distributed under the repository MIT license.
