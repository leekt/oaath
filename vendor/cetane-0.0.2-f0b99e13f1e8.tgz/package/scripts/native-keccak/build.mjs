import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { copyFile, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

// Explicit offline experimental build. No SDK code is imported or run here.
const root = dirname(fileURLToPath(import.meta.url))
const pins = JSON.parse(await readFile(join(root, 'pins.json'), 'utf8'))
const sha = (value) => createHash('sha256').update(value).digest('hex')
const options = {
  output: resolve(root, '../../native/darwin-arm64'),
  check: false,
}
for (let i = 2; i < process.argv.length; i++) {
  const option = process.argv[i]
  if (option === '--check') options.check = true
  else {
    const value = process.argv[++i]
    assert(
      ['--headers', '--compiler', '--sdk', '--output'].includes(option) &&
        value,
      'Usage: node build.mjs --headers NODE_INCLUDE_DIR [--compiler CLANG] [--sdk SDK_DIR] [--output DIR] [--check]',
    )
    options[option.slice(2)] = resolve(value)
  }
}
assert(
  options.headers,
  'Supply --headers pointing to the pinned local Node22 headers',
)
assert.equal(process.platform, 'darwin')
assert.equal(process.arch, 'arm64')
const compiler =
  options.compiler ??
  execFileSync('/usr/bin/xcrun', ['--find', 'clang'], {
    encoding: 'utf8',
  }).trim()
const sdk =
  options.sdk ??
  execFileSync('/usr/bin/xcrun', ['--show-sdk-path'], {
    encoding: 'utf8',
  }).trim()
assert.equal(sha(await readFile(compiler)), pins.compiler.sha256)
assert.equal(
  execFileSync(compiler, ['--version'], { encoding: 'utf8' }),
  pins.compiler.version,
)
assert.equal(
  sha(await readFile(join(sdk, 'SDKSettings.json'))),
  pins.sdk.settingsSha256,
)
for (const [name, expected] of Object.entries(pins.headers.files))
  assert.equal(sha(await readFile(join(options.headers, name))), expected, name)
for (const [name, expected] of Object.entries(pins.source.files))
  assert.equal(
    sha(await readFile(join(root, 'upstream', name))),
    expected,
    name,
  )
const names = [
  'addon.c',
  'keccak.c',
  'build.mjs',
  'pins.json',
  'exports.txt',
  'LICENSE.sha3',
]
const inputs = Object.fromEntries(
  await Promise.all(
    names.map(async (name) => [name, sha(await readFile(join(root, name)))]),
  ),
)
const work = await mkdtemp(join(tmpdir(), 'cetane-native-keccak-build-'))
const target = [
  compiler,
  '-target',
  pins.target.triple,
  `-mcpu=${pins.target.cpu}`,
  '-isysroot',
  sdk,
]
const mapping = [`-ffile-prefix-map=${work}=.`, `-fmacro-prefix-map=${work}=.`]
const commands = [
  [
    ...target,
    '-std=c11',
    '-O3',
    '-fvisibility=hidden',
    '-fstack-protector-strong',
    '-ffunction-sections',
    '-fdata-sections',
    ...mapping,
    '-DNAPI_VERSION=8',
    '-DBUILDING_NODE_EXTENSION',
    '-I',
    'include/node',
    '-c',
    'addon.c',
    '-o',
    'addon.o',
  ],
  [
    ...target,
    ...mapping,
    '-x',
    'assembler-with-cpp',
    '-c',
    'upstream/xkcp/KeccakP-1600-x1-v84a-asm.s',
    '-o',
    'permutation.o',
  ],
  [
    ...target,
    '-bundle',
    '-undefined',
    'dynamic_lookup',
    '-Wl,-dead_strip',
    '-Wl,-exported_symbols_list,exports.txt',
    'addon.o',
    'permutation.o',
    '-o',
    'keccak.node',
  ],
]
const manifest = {
  status: 'running',
  outputContract: 'canonical-lowercase-0x-64-hex-string',
  startedAt: new Date().toISOString(),
  work,
  compiler,
  sdk,
  headers: options.headers,
  inputs,
  pins,
  commands,
}
const save = () =>
  writeFile(
    join(work, 'manifest.json'),
    JSON.stringify(manifest, null, 2) + '\n',
  )
await save()
try {
  await mkdir(join(work, 'include/node'), { recursive: true })
  for (const name of Object.keys(pins.headers.files))
    await copyFile(
      join(options.headers, name),
      join(work, 'include/node', name),
    )
  for (const name of ['addon.c', 'keccak.c', 'exports.txt'])
    await copyFile(join(root, name), join(work, name))
  for (const name of Object.keys(pins.source.files)) {
    const destination = join(work, 'upstream', name)
    await mkdir(dirname(destination), { recursive: true })
    await copyFile(join(root, 'upstream', name), destination)
  }
  for (const command of commands)
    execFileSync(command[0], command.slice(1), { cwd: work, stdio: 'inherit' })
  const binary = await readFile(join(work, 'keccak.node'))
  const symbols = execFileSync(
    '/usr/bin/nm',
    ['-gU', join(work, 'keccak.node')],
    { encoding: 'utf8' },
  )
    .trim()
    .split('\n')
    .map((line) => line.trim().split(/\s+/).at(-1))
    .sort()
  assert.deepEqual(symbols, [
    '_napi_register_module_v1',
    '_node_api_module_get_api_version_v1',
  ])
  for (const [name, expected] of Object.entries(inputs))
    assert.equal(
      sha(await readFile(join(root, name))),
      expected,
      `Input changed: ${name}`,
    )
  for (const [name, expected] of Object.entries(pins.source.files)) {
    assert.equal(
      sha(await readFile(join(root, 'upstream', name))),
      expected,
      name,
    )
    assert.equal(
      sha(await readFile(join(work, 'upstream', name))),
      expected,
      name,
    )
  }
  manifest.binary = { bytes: binary.length, sha256: sha(binary) }
  manifest.exports = symbols
  manifest.linkedLibraries = execFileSync(
    '/usr/bin/otool',
    ['-L', join(work, 'keccak.node')],
    { encoding: 'utf8' },
  )
  const disassembly = execFileSync(
    '/usr/bin/otool',
    ['-tvV', join(work, 'keccak.node')],
    { encoding: 'utf8' },
  )
  await writeFile(join(work, 'disassembly.txt'), disassembly)
  manifest.sha3Instructions = Object.fromEntries(
    ['eor3', 'rax1', 'xar', 'bcax'].map((name) => [
      name,
      [...disassembly.matchAll(new RegExp(`\\b${name}\\b`, 'g'))].length,
    ]),
  )
  for (const [name, count] of Object.entries(manifest.sha3Instructions))
    assert(count > 0, `Missing expected SHA3 instruction: ${name}`)
  const provenance = {
    schemaVersion: 1,
    outputContract: manifest.outputContract,
    source: pins.source,
    permutation: pins.permutation,
    compiler: pins.compiler,
    headers: pins.headers,
    sdk: pins.sdk,
    target: pins.target,
    inputs,
    commands: commands.map((command) =>
      command.map((argument) =>
        argument
          .replaceAll(work, '<WORK>')
          .replaceAll(sdk, '<SDK>')
          .replaceAll(compiler, '<CLANG>'),
      ),
    ),
    binary: manifest.binary,
    exports: symbols,
    sha3Instructions: manifest.sha3Instructions,
  }
  const encoded = JSON.stringify(provenance, null, 2) + '\n'
  if (options.check) {
    assert.deepEqual(
      binary,
      await readFile(join(options.output, 'keccak.node')),
      'Rebuilt native Keccak binary matches',
    )
    assert.equal(
      encoded,
      await readFile(join(options.output, 'keccak-provenance.json'), 'utf8'),
      'Native Keccak provenance matches',
    )
  } else {
    await mkdir(options.output, { recursive: true })
    await writeFile(join(options.output, 'keccak.node'), binary)
    await writeFile(join(options.output, 'keccak-provenance.json'), encoded)
    for (const [source, destination] of [
      ['upstream/xkcp/LICENSE', 'LICENSE.keccak-xkcp'],
      ['upstream/LICENSE', 'LICENSE.keccak-hash-wasm'],
      ['LICENSE.sha3', 'LICENSE.keccak-sha3'],
    ])
      await copyFile(join(root, source), join(options.output, destination))
  }
  manifest.status = 'complete'
  manifest.output = options.output
} catch (error) {
  manifest.status = 'failed'
  manifest.error = String(error)
  throw error
} finally {
  manifest.finishedAt = new Date().toISOString()
  await save()
  console.log(
    JSON.stringify({
      status: manifest.status,
      manifest: join(work, 'manifest.json'),
      binary: manifest.binary,
    }),
  )
}
