#define NAPI_VERSION 8
#include <node_api.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "secp256k1.h"
#include "secp256k1_preallocated.h"
#include "secp256k1_recovery.h"

/* Immutable module constants are shared; keys, contexts and scratch never are. */
static const napi_type_tag signer_tag = {
    UINT64_C(0x03ac5e8bd341e29f), UINT64_C(0x45c7a192d8f0603b)
};
static const unsigned char half_order[32] = {
    0x7f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
    0x5d,0x57,0x6e,0x73,0x57,0xa4,0x50,0x1d,0xdf,0xe9,0x2f,0x46,0x68,0x1b,0x20,0xa0
};
typedef struct {
    unsigned char key[32];
    void *storage;
    size_t storage_size;
    secp256k1_context *context;
} signer_state;

static void wipe(void *pointer, size_t size) {
    volatile unsigned char *bytes = (volatile unsigned char *)pointer;
    while (size--) *bytes++ = 0;
}

static void dispose_state(signer_state *state) {
    if (!state) return;
    if (state->context) {
        secp256k1_context_preallocated_destroy(state->context);
        state->context = NULL;
    }
    if (state->storage) {
        wipe(state->storage, state->storage_size);
        free(state->storage);
        state->storage = NULL;
        state->storage_size = 0;
    }
    wipe(state->key, sizeof(state->key));
}

static void finalize(napi_env env, void *data, void *hint) {
    (void)env; (void)hint;
    signer_state *state = (signer_state *)data;
    dispose_state(state);
    wipe(state, sizeof(*state));
    free(state);
}

static bool api_ok(napi_env env, napi_status status) {
    if (status == napi_ok) return true;
    bool pending = false;
    napi_is_exception_pending(env, &pending);
    if (!pending) napi_throw_error(env, NULL, "Native signer API operation failed.");
    return false;
}

static bool type_error(napi_env env, const char *message) {
    napi_throw_type_error(env, NULL, message);
    return false;
}

/* No property lookup or user callback. SAB inputs are rejected, not borrowed. */
static bool copy32(napi_env env, napi_value value, unsigned char output[32]) {
    bool typed = false, ordinary = false, detached = true;
    napi_typedarray_type type;
    size_t length = 0, offset = 0;
    void *data = NULL;
    napi_value backing;
    if (!api_ok(env, napi_is_typedarray(env, value, &typed))) return false;
    if (!typed) return type_error(env, "Expected a 32-byte Uint8Array.");
    if (!api_ok(env, napi_get_typedarray_info(env, value, &type, &length,
                                             &data, &backing, &offset))) return false;
    if (type != napi_uint8_array || length != 32 || !data)
        return type_error(env, "Expected a 32-byte Uint8Array.");
    if (!api_ok(env, napi_is_arraybuffer(env, backing, &ordinary))) return false;
    if (!ordinary) return type_error(env, "Shared backing memory is unsupported.");
    if (!api_ok(env, napi_is_detached_arraybuffer(env, backing, &detached))) return false;
    if (detached) return type_error(env, "Detached backing memory is unsupported.");
    memcpy(output, data, 32);
    return true;
}

static signer_state *receiver(napi_env env, napi_value self, bool allow_closed) {
    bool tagged = false;
    void *pointer = NULL;
    if (!api_ok(env, napi_check_object_type_tag(env, self, &signer_tag, &tagged))) return NULL;
    if (!tagged) { type_error(env, "Invalid native signer receiver."); return NULL; }
    if (!api_ok(env, napi_unwrap(env, self, &pointer))) return NULL;
    signer_state *state = (signer_state *)pointer;
    if (!state || (!allow_closed && !state->context)) {
        napi_throw_error(env, NULL, "Native signer is closed.");
        return NULL;
    }
    return state;
}

static napi_value sign_hash(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value argv[2], self, result = NULL;
    unsigned char message[32] = {0}, output[65] = {0};
    secp256k1_ecdsa_recoverable_signature signature;
    memset(&signature, 0, sizeof(signature));
    int recovery = -1;
    if (!api_ok(env, napi_get_cb_info(env, info, &argc, argv, &self, NULL))) goto done;
    if (argc != 1) { type_error(env, "sign requires exactly one digest."); goto done; }
    signer_state *state = receiver(env, self, false);
    if (!state || !copy32(env, argv[0], message)) goto done;
    /* Input is now an owned stack copy. No N-API calls occur during crypto. */
    if (!secp256k1_ecdsa_sign_recoverable(state->context, &signature, message,
                                         state->key, NULL, NULL) ||
        !secp256k1_ecdsa_recoverable_signature_serialize_compact(
            state->context, output, &recovery, &signature) ||
        (recovery != 0 && recovery != 1) ||
        memcmp(output + 32, half_order, 32) > 0) {
        napi_throw_error(env, NULL, "Native secp256k1 signing failed.");
        goto done;
    }
    output[64] = (unsigned char)(27 + recovery);
    if (!api_ok(env, napi_create_buffer_copy(env, sizeof(output), output, NULL, &result)))
        result = NULL;
done:
    wipe(message, sizeof(message));
    wipe(output, sizeof(output));
    wipe(&signature, sizeof(signature));
    return result;
}

static napi_value public_key(napi_env env, napi_callback_info info) {
    size_t argc = 1, length = 65;
    napi_value argv[1], self, result = NULL;
    unsigned char output[65] = {0};
    secp256k1_pubkey key;
    memset(&key, 0, sizeof(key));
    if (!api_ok(env, napi_get_cb_info(env, info, &argc, argv, &self, NULL))) goto done;
    if (argc != 0) { type_error(env, "publicKey takes no arguments."); goto done; }
    signer_state *state = receiver(env, self, false);
    if (!state) goto done;
    if (!secp256k1_ec_pubkey_create(state->context, &key, state->key) ||
        !secp256k1_ec_pubkey_serialize(state->context, output, &length, &key,
                                     SECP256K1_EC_UNCOMPRESSED) ||
        length != 65 || output[0] != 4) {
        napi_throw_error(env, NULL, "Native public-key derivation failed.");
        goto done;
    }
    if (!api_ok(env, napi_create_buffer_copy(env, sizeof(output), output, NULL, &result)))
        result = NULL;
done:
    wipe(output, sizeof(output));
    wipe(&key, sizeof(key));
    return result;
}

static napi_value dispose(napi_env env, napi_callback_info info) {
    size_t argc = 1;
    napi_value argv[1], self, result;
    if (!api_ok(env, napi_get_cb_info(env, info, &argc, argv, &self, NULL))) return NULL;
    if (argc != 0) { type_error(env, "dispose takes no arguments."); return NULL; }
    signer_state *state = receiver(env, self, true);
    if (!state) return NULL;
    dispose_state(state);
    if (!api_ok(env, napi_get_undefined(env, &result))) return NULL;
    return result;
}

static napi_value create_signer(napi_env env, napi_callback_info info) {
    size_t argc = 3;
    napi_value argv[3], result = NULL;
    unsigned char key[32] = {0}, seed[32] = {0};
    signer_state *state = NULL;
    bool wrapped = false;
    if (!api_ok(env, napi_get_cb_info(env, info, &argc, argv, NULL, NULL))) goto done;
    if (argc != 2) { type_error(env, "createSigner requires key and randomization seed."); goto done; }
    if (!copy32(env, argv[0], key) || !copy32(env, argv[1], seed)) goto done;
    state = (signer_state *)calloc(1, sizeof(*state));
    if (!state) { napi_throw_error(env, NULL, "Native signer allocation failed."); goto done; }
    state->storage_size = secp256k1_context_preallocated_size(SECP256K1_CONTEXT_NONE);
    state->storage = malloc(state->storage_size);
    if (!state->storage) { napi_throw_error(env, NULL, "Native context allocation failed."); goto done; }
    state->context = secp256k1_context_preallocated_create(state->storage, SECP256K1_CONTEXT_NONE);
    if (!state->context || !secp256k1_ec_seckey_verify(state->context, key)) {
        napi_throw_error(env, NULL, "Invalid private key."); goto done;
    }
    if (!secp256k1_context_randomize(state->context, seed)) {
        napi_throw_error(env, NULL, "Native context randomization failed."); goto done;
    }
    memcpy(state->key, key, 32);
    if (!api_ok(env, napi_create_object(env, &result))) goto done;
    if (!api_ok(env, napi_type_tag_object(env, result, &signer_tag))) goto done;
    const napi_property_descriptor properties[] = {
        {"sign", NULL, sign_hash, NULL, NULL, NULL, napi_default, NULL},
        {"publicKey", NULL, public_key, NULL, NULL, NULL, napi_default, NULL},
        {"dispose", NULL, dispose, NULL, NULL, NULL, napi_default, NULL},
    };
    if (!api_ok(env, napi_define_properties(env, result, 3, properties))) goto done;
    /* Wrap last: after ownership transfers there are no fallible API operations. */
    if (!api_ok(env, napi_wrap(env, result, state, finalize, NULL, NULL))) goto done;
    wrapped = true;
done:
    wipe(key, sizeof(key));
    wipe(seed, sizeof(seed));
    if (!wrapped) {
        if (state) finalize(env, state, NULL);
        return NULL;
    }
    return result;
}

NAPI_MODULE_INIT() {
    const napi_property_descriptor properties[] = {
        {"createSigner", NULL, create_signer, NULL, NULL, NULL, napi_default, NULL},
    };
    if (!api_ok(env, napi_define_properties(env, exports, 1, properties))) return NULL;
    return exports;
}
