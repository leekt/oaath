import { CetaneError, RpcError, TransportError } from '../errors.js'
import { createReadBudget, ReadBudgetExceeded } from '../internal/readBudget.js'
import type { ReadBudget } from '../internal/readBudget.js'
import { traceOperation } from '../internal/trace.js'
import type { Address, Client, Hex, Log } from '../types.js'
import {
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
} from '../utils/hex.js'

export type GetLogsParameters = {
  address?: Address | readonly Address[]
  topics?: readonly (Hex | readonly Hex[] | null)[]
  fromBlock?: bigint
  toBlock?: bigint
  budget?: ReadBudget
}
export type LogScan = {
  logs: readonly Log[]
  fromBlock: bigint
  toBlock: bigint
  /** First unscanned block. Everything before this in the requested range is covered. */
  nextBlock: bigint
  complete: boolean
  requests: number
  reason?: 'budget' | 'range-limit' | 'result-limit'
}
export function isLogRangeError(error: unknown): boolean {
  return (
    (error instanceof TransportError && error.status === 413) ||
    (error instanceof RpcError &&
      (error.code === -32005 ||
        /(?:block|query|log|result|response).*(?:range|limit|too (?:large|many|wide)|exceed)|(?:range|limit).*(?:block|log|result)/i.test(
          error.message,
        )))
  )
}
function limit(
  value: bigint | number | undefined,
  label: string,
): bigint | undefined {
  if (value === undefined) return undefined
  if (
    (typeof value !== 'bigint' &&
      (typeof value !== 'number' || !Number.isSafeInteger(value))) ||
    value <= 0
  )
    throw new CetaneError(`Invalid ${label}.`)
  return BigInt(value)
}

/** Scan ascending contiguous ranges; refusal/result caps split reads, never submissions. */
export function getLogs(
  client: Client,
  parameters: GetLogsParameters = {},
): Promise<LogScan> {
  return client.trace
    ? traceOperation(client, 'getLogs', (scoped) =>
        getLogsInner(scoped, parameters),
      )
    : getLogsInner(client, parameters)
}

async function getLogsInner(
  client: Client,
  parameters: GetLogsParameters,
): Promise<LogScan> {
  const fromBlock = parameters.fromBlock ?? 0n
  toQuantity(fromBlock)
  if (parameters.toBlock !== undefined) toQuantity(parameters.toBlock)
  const addresses =
    parameters.address === undefined
      ? undefined
      : typeof parameters.address === 'string'
        ? [parameters.address]
        : [...parameters.address]
  addresses?.forEach(assertAddress)
  if (addresses?.length === 0)
    throw new CetaneError('Expected at least one log address.')
  const topics = parameters.topics?.map((topic) => {
    if (topic === null) return null
    if (typeof topic === 'string') {
      assertHex(topic, 32)
      return topic
    }
    if (!topic.length) throw new CetaneError('Empty topic alternatives.')
    topic.forEach((value) => assertHex(value, 32))
    return [...topic]
  })
  if (topics && topics.length > 4)
    throw new CetaneError('At most four log topics are supported.')
  const maxRange = limit(
    client.chain.limits?.maxLogBlockRange,
    'log block range',
  )
  const maxResults = limit(
    client.chain.limits?.maxLogResults,
    'log result count',
  )
  const budget = createReadBudget(client.request, parameters.budget)
  const toBlock =
    parameters.toBlock ??
    fromQuantity(await budget.request({ method: 'eth_blockNumber' }))
  if (fromBlock > toBlock) throw new CetaneError('Log range is reversed.')
  const logs: Log[] = []
  const seen = new Set<string>()
  let nextBlock = fromBlock
  let reason: LogScan['reason']
  async function scan(start: bigint, end: bigint): Promise<boolean> {
    let values: unknown
    let refusal: LogScan['reason']
    try {
      values = await budget.request({
        method: 'eth_getLogs',
        params: [
          {
            ...(parameters.address === undefined
              ? {}
              : {
                  address: addresses!.length === 1 ? addresses![0] : addresses,
                }),
            ...(topics === undefined ? {} : { topics }),
            fromBlock: toQuantity(start),
            toBlock: toQuantity(end),
          },
        ],
      })
      if (!Array.isArray(values)) throw new CetaneError('Invalid RPC log list.')
      if (maxResults !== undefined && BigInt(values.length) >= maxResults)
        refusal = 'result-limit'
    } catch (error) {
      if (error instanceof ReadBudgetExceeded) {
        reason = 'budget'
        return false
      }
      if (!isLogRangeError(error)) throw error
      refusal = 'range-limit'
    }
    if (refusal) {
      if (start === end) {
        reason = refusal
        return false
      }
      const middle = (start + end) / 2n
      return (await scan(start, middle)) && (await scan(middle + 1n, end))
    }
    const page: Log[] = (values as Record<string, unknown>[]).map((value) => {
      if (!value || typeof value !== 'object' || value.removed === true)
        throw new CetaneError('Invalid or removed RPC log.')
      assertAddress(value.address as Address)
      assertHex(value.data as Hex)
      assertHex(value.transactionHash as Hex, 32)
      if (
        !Array.isArray(value.topics) ||
        value.topics.length > 4 ||
        value.topics.length < (topics?.length ?? 0)
      )
        throw new CetaneError('Invalid log topics.')
      value.topics.forEach((topic) => assertHex(topic, 32))
      const blockNumber = fromQuantity(value.blockNumber)
      const logIndex = Number(fromQuantity(value.logIndex))
      if (
        blockNumber < start ||
        blockNumber > end ||
        !Number.isSafeInteger(logIndex)
      )
        throw new CetaneError('Log is outside the requested range.')
      if (
        addresses &&
        !addresses.some(
          (address) =>
            address.toLowerCase() === (value.address as string).toLowerCase(),
        )
      )
        throw new CetaneError('Log address does not match the filter.')
      if (
        topics?.some(
          (filter, i) =>
            filter !== null &&
            !(typeof filter === 'string' ? [filter] : filter).some(
              (topic) =>
                topic.toLowerCase() ===
                (value.topics as string[])[i]?.toLowerCase(),
            ),
        )
      )
        throw new CetaneError('Log topics do not match the filter.')
      return {
        address: value.address as Address,
        data: value.data as Hex,
        topics: value.topics as Hex[],
        blockNumber,
        transactionHash: value.transactionHash as Hex,
        logIndex,
      }
    })
    page.sort((a, b) =>
      a.blockNumber! < b.blockNumber!
        ? -1
        : a.blockNumber! > b.blockNumber!
          ? 1
          : a.logIndex! - b.logIndex!,
    )
    for (const log of page) {
      const key = `${log.transactionHash!.toLowerCase()}:${log.logIndex}`
      if (!seen.has(key)) {
        seen.add(key)
        logs.push(log)
      }
    }
    nextBlock = end + 1n
    return true
  }
  while (nextBlock <= toBlock) {
    const end =
      maxRange && nextBlock + maxRange - 1n < toBlock
        ? nextBlock + maxRange - 1n
        : toBlock
    if (!(await scan(nextBlock, end))) break
  }
  return {
    logs,
    fromBlock,
    toBlock,
    nextBlock,
    complete: nextBlock > toBlock,
    requests: budget.requests,
    ...(reason ? { reason } : {}),
  }
}
