import { CetaneError } from '../errors.js'
import type { Address, Hex, Module } from '../types.js'
import { encodeAbiParameters } from '../utils/abi.js'
import { assertHex } from '../utils/hex.js'
import { defineModule } from './erc7579.js'
import type { Version } from './kernel.js'

const bytes = { type: 'bytes' } as const
const noHook = '0x0000000000000000000000000000000000000000'

/**
 * Wrap a validator's public callback data for Kernel 3.3 or Kernel 4.
 * Grants one optional Kernel selector; this descriptor installs no hook.
 */
export function defineValidatorModule(parameters: {
  version: Version
  address: Address
  /** Payload forwarded to the validator's onInstall callback. */
  initData: Hex
  /** Kernel function this validator may authorize, such as execute(bytes32,bytes). */
  selector?: Hex
  /** Payload forwarded to the validator's onUninstall callback. */
  deInitData?: Hex
  /** Account-side installation/removal budgets, excluding shared batch overhead. */
  gas?: Module['gas']
}): Module {
  const { version, initData, deInitData = '0x', selector = '0x' } = parameters
  if (version !== '3.3' && version !== '4')
    throw new CetaneError('Unsupported Kernel version.')
  assertHex(initData)
  assertHex(deInitData)
  if (parameters.selector !== undefined) assertHex(selector, 4)
  return defineModule({
    type: 1n,
    address: parameters.address,
    initData:
      version === '3.3'
        ? `${noHook}${encodeAbiParameters([bytes, bytes, bytes], [initData, '0x', selector]).slice(2)}`
        : encodeAbiParameters([bytes, bytes], [initData, selector]),
    deInitData:
      version === '3.3'
        ? deInitData
        : encodeAbiParameters([bytes, bytes], [deInitData, '0x']),
    ...(parameters.gas ? { gas: parameters.gas } : {}),
  })
}
