import { secp256k1 } from '@noble/curves/secp256k1.js'
import { CetaneError } from '../errors.js'
import type { Address, Hex } from '../types.js'
import { getAddress } from '../utils/address.js'
import { bytesToHex, hexToBytes } from '../utils/bytes.js'
import { keccak256 } from '../utils/hash.js'
import { assertHex } from '../utils/hex.js'

/** Noble draws 48 Web Crypto bytes and reduces them to a valid scalar with negligible bias. */
export function generatePrivateKey(): Hex {
  const key = secp256k1.utils.randomSecretKey()
  try {
    return bytesToHex(key)
  } finally {
    key.fill(0)
  }
}

/** Validate a compressed (33-byte) or uncompressed (65-byte) SEC1 key and return EIP-55. */
export function publicKeyToAddress(publicKey: Hex | Uint8Array): Address {
  let uncompressed: Uint8Array
  try {
    if (typeof publicKey === 'string') assertHex(publicKey)
    uncompressed = secp256k1.Point.fromBytes(
      typeof publicKey === 'string' ? hexToBytes(publicKey) : publicKey,
    ).toBytes(false)
  } catch {
    throw new CetaneError(
      'Invalid secp256k1 public key. Expected compressed or uncompressed SEC1 data.',
    )
  }
  return getAddress(`0x${keccak256(uncompressed.subarray(1)).slice(-40)}`)
}
