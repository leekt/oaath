import { parseAbi } from 'abitype'
import { CetaneError, RpcError } from '../errors.js'
import { getLogs } from '../actions/logs.js'
import type { LogScan } from '../actions/logs.js'
import { createReadBudget, ReadBudgetExceeded } from '../internal/readBudget.js'
import type { ReadBudget } from '../internal/readBudget.js'
import type { Address, Client, Hex } from '../types.js'
import {
  decodeEventLog,
  decodeFunctionResult,
  encodeFunctionData,
} from '../utils/abi.js'
import {
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
} from '../utils/hex.js'
import { keccak256 } from '../utils/hash.js'
import { collectKernelHistory } from './kernelHistory.js'

const abi = /* @__PURE__ */ parseAbi([
  'function root() view returns (bytes21)',
  'function validationInfo(bytes21 vId) view returns ((uint32 nonce,bool installed,address scopedExecutionHook,address signer,address[] policies))',
  'function isModuleInstalled(uint256 moduleType,address module,bytes context) view returns (bool)',
  'function executorConfig(address executor) view returns ((bool installed,address scopedExecutionHook))',
  'function selectorConfig(bytes4 selector) view returns ((address target,bytes1 callType,address scopedExecutionHook))',
  'event ModuleInstalled(uint256 moduleType,address module)',
  'event ModuleUninstalled(uint256 moduleType,address module)',
])
const topics = /* @__PURE__ */ [
  'ModuleInstalled(uint256,address)',
  'ModuleUninstalled(uint256,address)',
].map((s) => keccak256(new TextEncoder().encode(s)))
const zero = '0x0000000000000000000000000000000000000000'
export type ReadModulesOptions = {
  blockNumber?: bigint
  fromBlock?: bigint
  /** Supplement events when an outer contract/opaque signature hides installation context. */
  permissionIds?: readonly Hex[]
  selectors?: readonly Hex[]
  budget?: ReadBudget
}
export type ObservedModule = {
  address: Address
  type: bigint
  status: 'state-confirmed' | 'history-derived'
  selector?: Hex
  context?: Hex
}
export type KernelModuleSnapshot = {
  version: '4'
  blockNumber: bigint
  root: { id: Hex; status: 'state-confirmed' } | null
  validators: ObservedModule[]
  executors: ObservedModule[]
  fallbacks: ObservedModule[]
  hooks: ObservedModule[]
  permissions: {
    id: Hex
    validationId: Hex
    signer: Address
    policies: readonly Address[]
    status: 'state-confirmed'
  }[]
  /** Contextless signer/policy events cannot prove which permission is currently installed. */
  unresolved: ObservedModule[]
  history: LogScan
  complete: boolean
  reason?: 'budget' | 'partial-history' | 'unknown-context'
  requests: number
}

/** Released Kernel 0.4.0 layout. State reads share one exact block and one total budget. */
export async function readKernelModules(
  client: Client,
  parameters: ReadModulesOptions & { address: Address; version: '4' },
): Promise<KernelModuleSnapshot> {
  if (parameters.version !== '4')
    throw new CetaneError('Module discovery currently supports Kernel 4 only.')
  assertAddress(parameters.address)
  parameters.permissionIds?.forEach((id) => assertHex(id, 4))
  parameters.selectors?.forEach((selector) => assertHex(selector, 4))
  if (parameters.blockNumber !== undefined) toQuantity(parameters.blockNumber)
  if (parameters.fromBlock !== undefined) toQuantity(parameters.fromBlock)
  const budget = createReadBudget(client.request, parameters.budget)
  const blockNumber =
    parameters.blockNumber ??
    fromQuantity(await budget.request({ method: 'eth_blockNumber' }))
  const block = toQuantity(blockNumber)
  const scoped = { ...client, request: budget.request }
  const read = async (functionName: string, args: readonly unknown[] = []) => {
    const data = await budget.request<Hex>({
      method: 'eth_call',
      params: [
        {
          to: parameters.address,
          data: encodeFunctionData({
            abi: abi as import('abitype').Abi,
            functionName,
            args,
          }),
        },
        block,
      ],
    })
    return decodeFunctionResult({
      abi: abi as import('abitype').Abi,
      functionName,
      data,
    })
  }
  let history: LogScan = {
    logs: [],
    fromBlock: parameters.fromBlock ?? 0n,
    toBlock: blockNumber,
    nextBlock: parameters.fromBlock ?? 0n,
    complete: false,
    requests: 0,
  }
  const snapshot: KernelModuleSnapshot = {
    version: '4',
    blockNumber,
    root: null,
    validators: [],
    executors: [],
    fallbacks: [],
    hooks: [],
    permissions: [],
    unresolved: [],
    history,
    complete: false,
    requests: 0,
  }
  const hints = {
    permissionIds: new Set<Hex>(
      parameters.permissionIds?.map((id) => id.toLowerCase() as Hex),
    ),
    selectors: new Set<Hex>(
      parameters.selectors?.map((id) => id.toLowerCase() as Hex),
    ),
  }
  const candidates = new Map<string, ObservedModule & { count: number }>()
  const addHook = (address: Address, context: Hex) => {
    if (address.toLowerCase() !== zero)
      snapshot.hooks.push({
        address,
        type: 11n,
        status: 'state-confirmed',
        context,
      })
  }
  try {
    const root = (await read('root')) as Hex
    snapshot.root = { id: root, status: 'state-confirmed' }
    if (root.startsWith('0x02'))
      hints.permissionIds.add(`0x${root.slice(4, 12)}`)
    if (root.startsWith('0x01')) {
      const address: Address = `0x${root.slice(4)}`
      candidates.set(`1:${address.toLowerCase()}`, {
        address,
        type: 1n,
        status: 'history-derived',
        count: 1,
      })
    }
    // Try one complete address-filtered read before spending calls locating deployment.
    history = await getLogs(scoped, {
      address: parameters.address,
      topics: [topics],
      fromBlock: history.fromBlock,
      toBlock: blockNumber,
      budget: { maxRequests: 1, timeout: parameters.budget?.timeout ?? 10_000 },
    })
    if (!history.complete) {
      let fromBlock = history.nextBlock
      if (parameters.fromBlock === undefined && history.nextBlock === 0n) {
        const codeAt = async (number: bigint) => {
          const code = await budget.request<Hex>({
            method: 'eth_getCode',
            params: [parameters.address, toQuantity(number)],
          })
          assertHex(code)
          return code !== '0x'
        }
        // Earliest code is only a scan optimization for a continuously deployed Kernel account.
        try {
          if (await codeAt(blockNumber)) {
            let low = 0n,
              high = blockNumber
            while (low < high) {
              const middle = (low + high) / 2n
              if (await codeAt(middle)) high = middle
              else low = middle + 1n
            }
            fromBlock = low
          }
        } catch (error) {
          // Pruned state cannot prevent ordinary bounded log splitting.
          if (!(error instanceof RpcError)) throw error
        }
      }
      const rest = await getLogs(scoped, {
        address: parameters.address,
        topics: [topics],
        fromBlock,
        toBlock: blockNumber,
        budget: {
          maxRequests: parameters.budget?.maxRequests ?? 256,
          timeout: parameters.budget?.timeout ?? 10_000,
        },
      })
      history = {
        ...rest,
        requests: history.requests + rest.requests,
        logs: [...history.logs, ...rest.logs],
        fromBlock:
          history.nextBlock > history.fromBlock
            ? history.fromBlock
            : rest.fromBlock,
      }
    }
    snapshot.history = history
    for (const log of history.logs) {
      const event = decodeEventLog({ abi, data: log.data, topics: log.topics })
      const { module, moduleType } = event.args
      const key = `${moduleType}:${module.toLowerCase()}`
      const old = candidates.get(key)
      candidates.set(key, {
        address: module,
        type: moduleType,
        status: 'history-derived',
        count:
          (old?.count ?? 0) + (event.eventName === 'ModuleInstalled' ? 1 : -1),
      })
    }
    // Only contexts missing from the events require transaction input reads.
    const contextual = history.logs.filter((log) => {
      const { moduleType } = decodeEventLog({
        abi,
        data: log.data,
        topics: log.topics,
      }).args
      return [3n, 5n, 6n, 11n].includes(moduleType)
    })
    for (const hash of new Set(contextual.map((log) => log.transactionHash!))) {
      const transaction = await budget.request<{
        input: Hex
        to: Address | null
      } | null>({ method: 'eth_getTransactionByHash', params: [hash] })
      if (transaction)
        collectKernelHistory(transaction.input, parameters.address, hints)
    }
    for (const candidate of candidates.values()) {
      const { count, ...entry } = candidate
      if (entry.type === 1n || entry.type === 2n) {
        const installed = (await read('isModuleInstalled', [
          entry.type,
          entry.address,
          '0x',
        ])) as boolean
        if (!installed) {
          candidate.count = 0
          continue
        }
        entry.status = 'state-confirmed'
        if (entry.type === 1n) {
          snapshot.validators.push(entry)
          const info = (await read('validationInfo', [
            `0x01${entry.address.slice(2)}`,
          ])) as { scopedExecutionHook: Address }
          addHook(info.scopedExecutionHook, `0x0101${entry.address.slice(2)}`)
        } else {
          snapshot.executors.push(entry)
          const config = (await read('executorConfig', [entry.address])) as {
            scopedExecutionHook: Address
          }
          addHook(config.scopedExecutionHook, `0x02${entry.address.slice(2)}`)
        }
      } else if (count > 0) {
        if (entry.type === 3n) snapshot.fallbacks.push(entry)
        else if (entry.type === 11n) snapshot.hooks.push(entry)
        else snapshot.unresolved.push(entry)
      }
    }
    for (const id of hints.permissionIds) {
      const validationId: Hex = `0x02${id.slice(2)}${'00'.repeat(16)}`
      const info = (await read('validationInfo', [validationId])) as {
        installed: boolean
        signer: Address
        policies: Address[]
        scopedExecutionHook: Address
      }
      if (!info.installed) continue
      snapshot.permissions.push({
        id,
        validationId,
        signer: info.signer,
        policies: info.policies,
        status: 'state-confirmed',
      })
      addHook(info.scopedExecutionHook, `0x01${validationId.slice(2)}`)
    }
    for (const selector of hints.selectors) {
      const config = (await read('selectorConfig', [selector])) as {
        target: Address
        scopedExecutionHook: Address
      }
      if (config.target.toLowerCase() === zero) continue
      snapshot.fallbacks.push({
        address: config.target,
        type: 3n,
        selector,
        status: 'state-confirmed',
      })
      addHook(config.scopedExecutionHook, `0x03${selector.slice(2)}`)
    }
    // Do not present duplicate history guesses beside a state-confirmed module.
    for (const key of ['fallbacks', 'hooks'] as const)
      snapshot[key] = snapshot[key].filter(
        (entry, _, list) =>
          entry.status === 'state-confirmed' ||
          !list.some(
            (other) =>
              other.status === 'state-confirmed' &&
              other.address.toLowerCase() === entry.address.toLowerCase(),
          ),
      )
    snapshot.unresolved = snapshot.unresolved.filter(
      (entry) =>
        !snapshot.permissions.some((permission) =>
          (entry.type === 6n ? [permission.signer] : permission.policies).some(
            (address) => address.toLowerCase() === entry.address.toLowerCase(),
          ),
        ),
    )
    // History cannot enumerate unknown contexts for a module also installed under known ones.
    snapshot.complete =
      history.complete &&
      contextual.length === 0 &&
      snapshot.unresolved.length === 0 &&
      !snapshot.fallbacks.some((entry) => entry.status === 'history-derived') &&
      !snapshot.hooks.some((entry) => entry.status === 'history-derived')
    if (!snapshot.complete)
      snapshot.reason = !history.complete
        ? history.reason === 'budget'
          ? 'budget'
          : 'partial-history'
        : 'unknown-context'
  } catch (error) {
    if (!(error instanceof ReadBudgetExceeded)) throw error
    snapshot.history = history
    snapshot.reason = 'budget'
    // Keep unconfirmed positive history visible when the state-read budget runs out.
    for (const { count, ...entry } of candidates.values()) {
      if (count <= 0) continue
      const list =
        entry.type === 1n
          ? snapshot.validators
          : entry.type === 2n
            ? snapshot.executors
            : entry.type === 3n
              ? snapshot.fallbacks
              : entry.type === 11n
                ? snapshot.hooks
                : snapshot.unresolved
      if (
        !list.some(
          (value) =>
            value.address.toLowerCase() === entry.address.toLowerCase(),
        )
      )
        list.push(entry)
    }
  }
  snapshot.requests = budget.requests
  return snapshot
}
