import { secp256k1 } from '@noble/curves/secp256k1.js'
import type { Address, Hash, Hex } from '../types.js'
import { CetaneError } from '../errors.js'
import { getAddress } from './address.js'
import { hexToBytes } from './bytes.js'
import { keccak256 } from './hash.js'
import { assertHex } from './hex.js'

/** Recover from an exact digest, without rehashing. Serialized v accepts 0/1 or 27/28. */
export function recoverAddress(input: {
  hash: Hash
  signature: Hex | { r: Hex; s: Hex; yParity: number }
}): Address {
  try {
    assertHex(input.hash, 32)
    let { signature: value } = input
    if (typeof value === 'string') {
      assertHex(value, 65)
      const v = Number.parseInt(value.slice(-2), 16)
      value = {
        r: `0x${value.slice(2, 66)}`,
        s: `0x${value.slice(66, 130)}`,
        yParity: v >= 27 ? v - 27 : v,
      }
    }
    assertHex(value.r, 32)
    assertHex(value.s, 32)
    if (value.yParity !== 0 && value.yParity !== 1) throw new Error()
    const signature = new Uint8Array(65)
    signature[0] = value.yParity
    signature.set(hexToBytes(value.r), 1)
    signature.set(hexToBytes(value.s), 33)
    const recovered = secp256k1.recoverPublicKey(
      signature,
      hexToBytes(input.hash),
      { prehash: false },
    )
    const publicKey = secp256k1.Point.fromBytes(recovered).toBytes(false)
    return getAddress(`0x${keccak256(publicKey.subarray(1)).slice(-40)}`)
  } catch {
    throw new CetaneError('Invalid recovery input.')
  }
}
