import type { AbiParameter } from 'abitype'
import { CetaneError } from '../errors.js'
import type { Hash, Hex } from '../types.js'
import { encodeAbiParameters } from './abi.js'
import { keccak256 } from './hash.js'
import { assertHex } from './hex.js'

export type TypedDataTypes = Readonly<
  Record<string, readonly { readonly name: string; readonly type: string }[]>
>
export type TypedData = {
  types: TypedDataTypes
  primaryType: string
  domain: Readonly<Record<string, unknown>>
  message: Readonly<Record<string, unknown>>
}
const identifier = /^[A-Za-z_$][A-Za-z0-9_$]*$/
const atomic =
  /^(?:address|bool|string|bytes(?:[1-9]|[12][0-9]|3[0-2])?|u?int(?:8|16|24|32|40|48|56|64|72|80|88|96|104|112|120|128|136|144|152|160|168|176|184|192|200|208|216|224|232|240|248|256))$/
const domainFields = [
  { name: 'name', type: 'string' },
  { name: 'version', type: 'string' },
  { name: 'chainId', type: 'uint256' },
  { name: 'verifyingContract', type: 'address' },
  { name: 'salt', type: 'bytes32' },
] as const
const textHash = (text: string) => keccak256(new TextEncoder().encode(text))

/** IO-free EIP-712 digest. Explicit domain schemas are preserved, including chainless domains. */
export function hashTypedData(input: TypedData): Hash {
  const types: TypedDataTypes = {
    ...input.types,
    EIP712Domain:
      input.types.EIP712Domain ??
      domainFields.filter(({ name }) => Object.hasOwn(input.domain, name)),
  }
  function baseType(type: string): string {
    if (typeof type !== 'string') throw new CetaneError('Invalid EIP-712 type.')
    let base = type
    let depth = 0
    for (;;) {
      const array = /^(.*)\[([0-9]*)\]$/.exec(base)
      if (!array) break
      if (
        ++depth > 64 ||
        (array[2] !== '' &&
          (!/^[1-9][0-9]*$/.test(array[2]!) ||
            !Number.isSafeInteger(Number(array[2]))))
      )
        throw new CetaneError('Invalid EIP-712 array type.')
      base = array[1]!
    }
    if (
      !atomic.test(base) &&
      (!identifier.test(base) || !Object.hasOwn(types, base))
    )
      throw new CetaneError(`Unknown EIP-712 type: ${type}.`)
    return base
  }
  for (const [name, fields] of Object.entries(types)) {
    if (
      !identifier.test(name) ||
      atomic.test(name) ||
      name === 'uint' ||
      name === 'int' ||
      !Array.isArray(fields)
    )
      throw new CetaneError('Invalid EIP-712 struct.')
    const names = new Set<string>()
    for (const field of fields) {
      if (
        !field ||
        typeof field.name !== 'string' ||
        !identifier.test(field.name) ||
        names.has(field.name)
      )
        throw new CetaneError('Invalid or duplicate EIP-712 field.')
      names.add(field.name)
      baseType(field.type)
    }
  }
  if (
    typeof input.primaryType !== 'string' ||
    !Object.hasOwn(types, input.primaryType)
  )
    throw new CetaneError('Unknown EIP-712 primary type.')
  const hashes = new Map<string, Hex>()
  function typeHash(name: string): Hex {
    const cached = hashes.get(name)
    if (cached) return cached
    const dependencies = new Set<string>()
    const pending = [name]
    while (pending.length) {
      const current = pending.pop()!
      if (dependencies.has(current)) continue
      dependencies.add(current)
      for (const field of types[current]!) {
        const base = baseType(field.type)
        if (!atomic.test(base)) pending.push(base)
      }
    }
    dependencies.delete(name)
    const encoded = [name, ...[...dependencies].sort()]
      .map(
        (name) =>
          `${name}(${types[name]!.map(({ name, type }) => `${type} ${name}`).join(',')})`,
      )
      .join('')
    const hash = textHash(encoded)
    hashes.set(name, hash)
    return hash
  }
  const active = new Set<object>()
  function encode(type: string, value: unknown, depth: number): Hex {
    if (depth > 64)
      throw new CetaneError('EIP-712 value nesting exceeds 64 levels.')
    const array = /^(.*)\[([0-9]*)\]$/.exec(type)
    if (array) {
      if (
        !Array.isArray(value) ||
        (array[2] !== '' && value.length !== Number(array[2]))
      )
        throw new CetaneError('EIP-712 array length mismatch.')
      return keccak256(
        `0x${Array.from(value, (v) => encode(array[1]!, v, depth + 1).slice(2)).join('')}`,
      )
    }
    if (Object.hasOwn(types, type)) {
      if (
        !value ||
        typeof value !== 'object' ||
        Array.isArray(value) ||
        active.has(value)
      )
        throw new CetaneError('Invalid or cyclic EIP-712 struct value.')
      const fields = types[type]!
      const record = value as Record<string, unknown>
      if (
        Object.keys(record).length !== fields.length ||
        fields.some(({ name }) => !Object.hasOwn(record, name))
      )
        throw new CetaneError('EIP-712 fields do not match the schema.')
      active.add(value)
      try {
        return keccak256(
          `0x${typeHash(type).slice(2)}${fields
            .map(({ name, type }) =>
              encode(
                type,
                (value as Record<string, unknown>)[name],
                depth + 1,
              ).slice(2),
            )
            .join('')}`,
        )
      } finally {
        active.delete(value)
      }
    }
    if (type === 'string') {
      if (typeof value !== 'string')
        throw new CetaneError('Expected an EIP-712 string.')
      return textHash(value)
    }
    if (type === 'bytes') {
      assertHex(value as Hex)
      return keccak256(value as Hex)
    }
    if (/^u?int/.test(type) && typeof value === 'string') {
      if (!/^(?:-?(?:0|[1-9][0-9]*)|0x[0-9a-fA-F]+)$/.test(value))
        throw new CetaneError('Invalid EIP-712 integer.')
      value = BigInt(value)
    }
    return encodeAbiParameters([{ type } as AbiParameter], [value])
  }
  const domain = encode('EIP712Domain', input.domain, 0)
  return keccak256(
    `0x1901${domain.slice(2)}${input.primaryType === 'EIP712Domain' ? '' : encode(input.primaryType, input.message, 0).slice(2)}`,
  )
}
