import { CetaneError } from '../errors.js'
import type { Address, Hash, Hex, Signer } from '../types.js'
import { assertAddress, assertHex, word } from '../utils/hex.js'
import { keccak256 } from '../utils/hash.js'
import { toRlp, toRlpInteger } from '../utils/rlp.js'
import type { RlpValue } from '../utils/rlp.js'
import { prepareType2 } from './internal/type2.js'

type Fields = {
  chainId: number
  nonce: bigint
  gas: bigint
  to?: Address
  value?: bigint
  data?: Hex
}
export type EvmTransaction = Fields &
  (
    | {
        type: 'eip1559'
        maxFeePerGas: bigint
        maxPriorityFeePerGas: bigint
        accessList?: readonly {
          address: Address
          storageKeys: readonly Hex[]
        }[]
      }
    | { type: 'legacy'; gasPrice: bigint }
  )
export type SignedEvmTransaction = Readonly<{
  serializedTransaction: Hex
  hash: Hash
}>
const order =
  0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n
function signatureParts(signature: Hex) {
  assertHex(signature, 65)
  const r = BigInt(`0x${signature.slice(2, 66)}`)
  const s = BigInt(`0x${signature.slice(66, 130)}`)
  const v = Number.parseInt(signature.slice(130), 16)
  const parity = v >= 27 ? v - 27 : v
  if (
    r <= 0n ||
    r >= order ||
    s <= 0n ||
    s > order / 2n ||
    (parity !== 0 && parity !== 1)
  )
    throw new CetaneError('Invalid Ethereum transaction signature.')
  return { r, s, parity }
}
function prepare(transaction: EvmTransaction) {
  if (!Number.isSafeInteger(transaction.chainId) || transaction.chainId <= 0)
    throw new CetaneError('Invalid chain ID.')
  function integer(value: bigint) {
    if (typeof value !== 'bigint') throw new CetaneError('Expected a bigint.')
    word(value)
    return toRlpInteger(value)
  }
  if (transaction.to !== undefined) assertAddress(transaction.to)
  const data = transaction.data ?? '0x'
  assertHex(data)
  const common: RlpValue[] = [
    integer(transaction.gas),
    transaction.to ?? '0x',
    integer(transaction.value ?? 0n),
    data,
  ]
  const nonce = integer(transaction.nonce)
  if (transaction.type === 'eip1559') {
    const priority = integer(transaction.maxPriorityFeePerGas)
    const fee = integer(transaction.maxFeePerGas)
    if (transaction.maxPriorityFeePerGas > transaction.maxFeePerGas)
      throw new CetaneError('Priority fee exceeds max fee.')
    const accessList: RlpValue[] = (transaction.accessList ?? []).map(
      ({ address, storageKeys }) => {
        assertAddress(address)
        storageKeys.forEach((key) => assertHex(key, 32))
        return [address, [...storageKeys]]
      },
    )
    return prepareType2([
      toRlpInteger(transaction.chainId),
      nonce,
      priority,
      fee,
      ...common,
      accessList,
    ])
  }
  if (transaction.type !== 'legacy')
    throw new CetaneError('Unsupported EVM transaction type.')
  const fields: RlpValue[] = [nonce, integer(transaction.gasPrice), ...common]
  const chainId = BigInt(transaction.chainId)
  const hash = keccak256(toRlp([...fields, toRlpInteger(chainId), '0x', '0x']))
  return {
    hash,
    serialize(signature: Hex) {
      const { r, s, parity } = signatureParts(signature)
      return toRlp([
        ...fields,
        toRlpInteger(chainId * 2n + 35n + BigInt(parity)),
        toRlpInteger(r),
        toRlpInteger(s),
      ])
    },
  }
}

/** Sign supplied fields locally, with no client, RPC, nonce reservation or broadcast. */
export async function signEvmTransaction(parameters: {
  transaction: EvmTransaction
  signer: Signer
}): Promise<SignedEvmTransaction> {
  // Compile before awaiting a signer so caller mutation cannot alter the signed bytes.
  const prepared = prepare(parameters.transaction)
  const signature = await parameters.signer.sign({ hash: prepared.hash })
  signatureParts(signature)
  const serializedTransaction = prepared.serialize(signature)
  return Object.freeze({
    serializedTransaction,
    hash: keccak256(serializedTransaction),
  })
}
