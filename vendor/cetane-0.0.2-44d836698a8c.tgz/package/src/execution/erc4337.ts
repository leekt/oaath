import { estimateFeesPerGas } from '../actions/fees.js'
import { signTransaction } from '../accounts/sign.js'
import { CetaneError, RpcError } from '../errors.js'
import {
  beginSpan,
  scopeContext,
  traceAsync,
  traceRequestFunction,
  traceSync,
} from '../internal/trace.js'
import type {
  Account,
  Address,
  Context,
  Execution,
  Hex,
  SponsorContext,
} from '../types.js'
import {
  addressWord,
  assertAddress,
  assertHex,
  fromQuantity,
  toQuantity,
  word,
} from '../utils/hex.js'
import { keccak256 } from '../utils/hash.js'
import { formatReceipt } from './receipt.js'
import type { RpcReceipt } from './receipt.js'
import {
  applySponsorship,
  assertFinalSponsorship,
  assertStubCoverage,
  parseSponsorship,
  requestSponsorship,
} from './internal/sponsorship.js'
import type { StubSponsorship } from './internal/sponsorship.js'

export type Version = '0.7' | '0.8' | '0.9'
export type SponsorStage = 'stub' | 'final'
const addresses = {
  '0.7': '0x0000000071727de22e5e9d8baf0edac6f37da032',
  '0.8': '0x4337084d9e255ff0702461cf8895ce9e3b5ff108',
  '0.9': '0x433709009b8330fda32311df1c2afa402ed8d009',
} as const
export type Operation = {
  sender: Address
  nonce: bigint
  callData: Hex
  callGasLimit: bigint
  verificationGasLimit: bigint
  preVerificationGas: bigint
  maxFeePerGas: bigint
  maxPriorityFeePerGas: bigint
  signature: Hex
  factory?: Address
  factoryData?: Hex
  paymaster?: Address
  paymasterData?: Hex
  paymasterSignature?: Hex
  paymasterVerificationGasLimit?: bigint
  paymasterPostOpGasLimit?: bigint
}
export type PackedUserOperation = {
  sender: Address
  nonce: bigint
  initCode: Hex
  callData: Hex
  accountGasLimits: Hex
  preVerificationGas: bigint
  gasFees: Hex
  paymasterAndData: Hex
  signature: Hex
}

function assertVersion(version: Version) {
  if (!['0.7', '0.8', '0.9'].includes(version))
    throw new CetaneError('Unsupported EntryPoint version.')
}
function uint(value: bigint, bytes = 32): string {
  if (typeof value !== 'bigint') throw new CetaneError('Expected a bigint.')
  return word(value, bytes)
}
/** Pure conversion; absent factory/paymaster payloads default to empty bytes/zero gas. */
export function toPackedUserOperation(
  op: Operation,
  version: Version,
): PackedUserOperation {
  assertVersion(version)
  assertAddress(op.sender)
  assertHex(op.callData)
  assertHex(op.signature)
  uint(op.nonce)
  uint(op.preVerificationGas)
  if (op.factory !== undefined) assertAddress(op.factory)
  else if (op.factoryData !== undefined)
    throw new CetaneError('Factory data requires a factory.')
  if (op.factoryData !== undefined) assertHex(op.factoryData)
  if (
    op.paymaster === undefined &&
    [
      op.paymasterData,
      op.paymasterSignature,
      op.paymasterVerificationGasLimit,
      op.paymasterPostOpGasLimit,
    ].some((v) => v !== undefined)
  )
    throw new CetaneError('Paymaster fields require a paymaster.')
  if (op.paymasterData !== undefined) assertHex(op.paymasterData)
  if (op.paymaster !== undefined) {
    uint(op.paymasterVerificationGasLimit ?? 0n, 16)
    uint(op.paymasterPostOpGasLimit ?? 0n, 16)
  }
  const packed = {
    sender: op.sender,
    nonce: op.nonce,
    initCode: initCode(op),
    callData: op.callData,
    accountGasLimits:
      `0x${uint(op.verificationGasLimit, 16)}${uint(op.callGasLimit, 16)}` as Hex,
    preVerificationGas: op.preVerificationGas,
    gasFees:
      `0x${uint(op.maxPriorityFeePerGas, 16)}${uint(op.maxFeePerGas, 16)}` as Hex,
    paymasterAndData: paymasterData(op, version),
    signature: op.signature,
  }
  // Validate an embedded 0.9 signature footer too; never silently reinterpret a bad length.
  toUserOperation(packed, version)
  return packed
}

/** Reverse the packed wire layout, preserving signatures and all committed bytes. */
export function toUserOperation(
  packed: PackedUserOperation,
  version: Version,
): Operation {
  assertVersion(version)
  assertAddress(packed.sender)
  uint(packed.nonce)
  uint(packed.preVerificationGas)
  assertHex(packed.initCode)
  assertHex(packed.callData)
  assertHex(packed.signature)
  assertHex(packed.accountGasLimits, 32)
  assertHex(packed.gasFees, 32)
  assertHex(packed.paymasterAndData)
  if (packed.initCode !== '0x' && packed.initCode.length < 42)
    throw new CetaneError('Truncated factory prefix.')
  if (packed.paymasterAndData !== '0x' && packed.paymasterAndData.length < 106)
    throw new CetaneError('Truncated paymaster prefix.')
  const op: Operation = {
    sender: packed.sender,
    nonce: packed.nonce,
    callData: packed.callData,
    verificationGasLimit: BigInt(packed.accountGasLimits.slice(0, 34)),
    callGasLimit: BigInt(`0x${packed.accountGasLimits.slice(34)}`),
    preVerificationGas: packed.preVerificationGas,
    maxPriorityFeePerGas: BigInt(packed.gasFees.slice(0, 34)),
    maxFeePerGas: BigInt(`0x${packed.gasFees.slice(34)}`),
    signature: packed.signature,
  }
  if (packed.initCode !== '0x') {
    op.factory = packed.initCode.slice(0, 42) as Address
    op.factoryData = `0x${packed.initCode.slice(42)}`
  }
  if (packed.paymasterAndData !== '0x') {
    const data = packed.paymasterAndData
    op.paymaster = data.slice(0, 42) as Address
    op.paymasterVerificationGasLimit = BigInt(`0x${data.slice(42, 74)}`)
    op.paymasterPostOpGasLimit = BigInt(`0x${data.slice(74, 106)}`)
    op.paymasterData = `0x${data.slice(106)}`
    if (
      version === '0.9' &&
      data.length >= 126 &&
      data.slice(-16).toLowerCase() === '22e325a297439656'
    ) {
      const length = Number.parseInt(data.slice(-20, -16), 16)
      if (length > (data.length - 126) / 2)
        throw new CetaneError('Invalid paymaster signature length.')
      // A zero-length marker stays inline: it has different signing semantics.
      if (length) {
        op.paymasterData = `0x${data.slice(106, -(length * 2 + 20))}`
        op.paymasterSignature = `0x${data.slice(-(length * 2 + 20), -20)}`
      }
    }
  }
  return op
}
export type Sponsorship = { paymaster: Address } & Pick<
  Operation,
  | 'paymasterData'
  | 'paymasterSignature'
  | 'paymasterVerificationGasLimit'
  | 'paymasterPostOpGasLimit'
>
export type Sponsor = {
  stub(
    operation: Readonly<Operation>,
    context: {
      chainId: number
      entryPoint: Address
      version: Version
      context: SponsorContext
    },
  ): Promise<StubSponsorship>
  finalize?(
    operation: Readonly<Operation>,
    context: {
      chainId: number
      entryPoint: Address
      version: Version
      context: SponsorContext
    },
  ): Promise<Sponsorship>
}

function initCode(op: Operation): Hex {
  return op.factory ? `${op.factory}${(op.factoryData ?? '0x').slice(2)}` : '0x'
}
function paymasterData(op: Operation, version: Version, signing = false): Hex {
  if (!op.paymaster) return '0x'
  assertAddress(op.paymaster)
  const data: Hex = `${op.paymaster}${word(op.paymasterVerificationGasLimit ?? 0n, 16)}${word(op.paymasterPostOpGasLimit ?? 0n, 16)}${(op.paymasterData ?? '0x').slice(2)}`
  const signature = op.paymasterSignature
  if (signature !== undefined) {
    assertHex(signature)
    const length = (signature.length - 2) / 2
    if (version !== '0.9' || !length)
      throw new CetaneError(
        'Detached paymaster signatures require EntryPoint 0.9 and nonempty data.',
      )
    const encodedLength = word(BigInt(length), 2)
    // The sender commits to the marker, excluding the detached signature and
    // its length. Still validate both before omitting them from signed bytes.
    return signing
      ? `${data}22e325a297439656`
      : `${data}${signature.slice(2)}${encodedLength}22e325a297439656`
  }
  if (
    !signing ||
    version !== '0.9' ||
    data.length < 126 ||
    data.slice(-16).toLowerCase() !== '22e325a297439656'
  )
    return data
  const length = Number.parseInt(data.slice(-20, -16), 16)
  if (length > (data.length - 126) / 2)
    throw new CetaneError('Invalid paymaster signature length.')
  return length
    ? (`${data.slice(0, -(length * 2 + 20))}22e325a297439656` as Hex)
    : data
}

function submissionSize(op: Operation, version: Version): number {
  // handleOps([operation], beneficiary), including selector, array offsets and dynamic tails.
  const fixed = 4 + 64 + 32 + 32 + 9 * 32
  return (
    fixed +
    [
      initCode(op),
      op.callData,
      paymasterData(op, version),
      op.signature,
    ].reduce(
      (size, value) => size + 32 + Math.ceil((value.length - 2) / 64) * 32,
      0,
    )
  )
}

export function toRpc(op: Operation, version: Version): Record<string, Hex> {
  const rpc: Record<string, Hex> = {
    sender: op.sender,
    nonce: toQuantity(op.nonce),
    callData: op.callData,
    callGasLimit: toQuantity(op.callGasLimit),
    verificationGasLimit: toQuantity(op.verificationGasLimit),
    preVerificationGas: toQuantity(op.preVerificationGas),
    maxFeePerGas: toQuantity(op.maxFeePerGas),
    maxPriorityFeePerGas: toQuantity(op.maxPriorityFeePerGas),
    signature: op.signature,
  }
  if (op.factory) {
    rpc.factory = op.factory
    rpc.factoryData = op.factoryData ?? '0x'
  }
  if (op.paymaster) {
    rpc.paymaster = op.paymaster
    rpc.paymasterData = op.paymasterData ?? '0x'
    rpc.paymasterVerificationGasLimit = toQuantity(
      op.paymasterVerificationGasLimit ?? 0n,
    )
    rpc.paymasterPostOpGasLimit = toQuantity(op.paymasterPostOpGasLimit ?? 0n)
    if (op.paymasterSignature !== undefined)
      rpc.paymasterSignature = op.paymasterSignature
  }
  return rpc
}

const hashText = (value: string) =>
  keccak256(new TextEncoder().encode(value)).slice(2)
let domainPrefix: string | undefined
let operationType: string | undefined
// Keep the fixed-chain fast path and a bounded cache for alternating domains.
let lastDomain: { chainId: number; entryPoint: Address; hash: Hex } | undefined
const domains: NonNullable<typeof lastDomain>[] = []
let domainCursor = 0
const emptyHash =
  'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
const hashData = (value: Hex) =>
  value === '0x' ? emptyHash : keccak256(value).slice(2)
/** Fixed-layout encoding avoids a generic ABI encoder on the signing path. */
export function getSigningHash(
  op: Operation,
  chainId: number,
  entryPoint: Address,
  version: Version,
): Hex {
  assertAddress(op.sender)
  assertAddress(entryPoint)
  const head =
    addressWord(op.sender) +
    word(op.nonce) +
    hashData(initCode(op)) +
    hashData(op.callData)
  const body =
    head +
    word(op.verificationGasLimit, 16) +
    word(op.callGasLimit, 16) +
    word(op.preVerificationGas) +
    word(op.maxPriorityFeePerGas, 16) +
    word(op.maxFeePerGas, 16) +
    hashData(paymasterData(op, version, true))
  if (version === '0.7')
    return keccak256(
      `0x${keccak256(`0x${body}`).slice(2)}${addressWord(entryPoint)}${word(BigInt(chainId))}`,
    )
  domainPrefix ??=
    hashText(
      'EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)',
    ) +
    hashText('ERC4337') +
    hashText('1')
  operationType ??= hashText(
    'PackedUserOperation(address sender,uint256 nonce,bytes initCode,bytes callData,bytes32 accountGasLimits,uint256 preVerificationGas,bytes32 gasFees,bytes paymasterAndData)',
  )
  if (lastDomain?.chainId !== chainId || lastDomain.entryPoint !== entryPoint) {
    const hit = domains.find(
      (value) => value.chainId === chainId && value.entryPoint === entryPoint,
    )
    if (hit) lastDomain = hit
    else {
      lastDomain = {
        chainId,
        entryPoint,
        hash: keccak256(
          `0x${domainPrefix}${word(BigInt(chainId))}${addressWord(entryPoint)}`,
        ),
      }
      domains[domainCursor] = lastDomain
      domainCursor = (domainCursor + 1) % 8
    }
  }
  const domain = lastDomain.hash
  return keccak256(
    `0x1901${domain.slice(2)}${keccak256(`0x${operationType}${body}`).slice(2)}`,
  )
}

export function createExecution(
  options: {
    version?: Version
    entryPoint?: Address
    sponsor?: Sponsor
    /** Opt-in relay extension: hold receipt reads for this many milliseconds (bundle_rs). */
    receiptWait?: number
    /** Complete conservative budgets allow known module operations to skip bundler simulation. */
    gas?: {
      verificationGasLimit: bigint
      preVerificationGas: bigint | ((operation: Readonly<Operation>) => bigint)
      deploymentVerificationGasLimit?: bigint
    }
  } = {},
): Execution {
  const version = options.version ?? '0.7'
  if (!['0.7', '0.8', '0.9'].includes(version))
    throw new CetaneError('Unsupported EntryPoint version.')
  const entryPoint = options.entryPoint ?? addresses[version]
  assertAddress(entryPoint)
  const receiptWait = options.receiptWait
  if (
    receiptWait !== undefined &&
    (!Number.isSafeInteger(receiptWait) ||
      receiptWait < 1 ||
      receiptWait > 60_000)
  )
    throw new CetaneError('Receipt hold time must be between 1 and 60000 ms.')
  // Every client snapshots its chain. Decorators and deadline-scoped readers retain that identity.
  const immediateOnly = new WeakSet<object>()
  async function getReceipt(context: Context, hash: Hex, wait?: number) {
    const result = await context.relay<{
      userOpHash: Hex
      success: boolean
      actualGasUsed: Hex
      actualGasCost: Hex
      receipt: RpcReceipt
    } | null>({
      method: 'eth_getUserOperationReceipt',
      params: wait === undefined ? [hash] : [hash, wait],
    })
    if (result === null) return null
    if (
      typeof result.success !== 'boolean' ||
      result.userOpHash.toLowerCase() !== hash.toLowerCase()
    )
      throw new CetaneError('Invalid operation receipt.')
    const receipt = formatReceipt(result.receipt, hash)
    const gasUsed = fromQuantity(result.actualGasUsed)
    receipt.status = result.success ? 'success' : 'reverted'
    receipt.gasUsed = gasUsed
    receipt.effectiveGasPrice =
      gasUsed === 0n ? 0n : fromQuantity(result.actualGasCost) / gasUsed
    return receipt
  }
  const waitForReceipt: Execution['waitForReceipt'] =
    receiptWait === undefined
      ? undefined
      : async (context, hash, { timeout }) => {
          if (immediateOnly.has(context.chain)) return getReceipt(context, hash)
          try {
            return await getReceipt(
              context,
              hash,
              Math.max(1, Math.min(receiptWait, Math.floor(timeout))),
            )
          } catch (error) {
            if (
              !(error instanceof RpcError) ||
              ![-32601, -32602].includes(error.code)
            )
              throw error
            // Only an unsupported read capability can fall back. Never retry writes here.
            immediateOnly.add(context.chain)
            return getReceipt(context, hash)
          }
        }
  async function getNonce(
    context: Context,
    account: Account,
    key: bigint,
  ): Promise<bigint> {
    word(key, 24)
    const data = await context.request<Hex>({
      method: 'eth_call',
      params: [
        {
          to: entryPoint,
          data: `0x35567e1a${addressWord(account.address)}${word(key)}`,
        },
        'latest',
      ],
    })
    assertHex(data, 32)
    const nonce = BigInt(data)
    if (nonce >> 64n !== key)
      throw new CetaneError('RPC nonce does not match the requested nonce key.')
    return nonce & ((1n << 64n) - 1n)
  }
  return {
    getNonce,
    async prepare(context, parameters) {
      const { account } = parameters
      const nonceKey = parameters.nonceKey ?? 0n
      word(nonceKey, 24)
      if (parameters.nonce !== undefined) word(parameters.nonce, 8)
      const configuredSponsor =
        parameters.sponsor === false
          ? undefined
          : (context.sponsor ?? options.sponsor)
      if (parameters.sponsor === true && !configuredSponsor)
        throw new CetaneError(
          'Sponsorship was requested, but no sponsor is configured.',
        )
      if (
        configuredSponsor &&
        ('sign' in configuredSponsor || 'account' in configuredSponsor)
      )
        throw new CetaneError(
          'This account requires a sponsor service, not a local fee payer.',
        )
      const sponsor = configuredSponsor
      if (!account.encodeCalls || !account.stubSignature)
        throw new CetaneError(
          'This account is missing call encoding or an estimation signature.',
        )
      if (
        parameters.feeToken !== undefined ||
        parameters.validAfter !== undefined ||
        parameters.validBefore !== undefined
      )
        throw new CetaneError(
          'Fee tokens and validity windows must be provided by the account or sponsor for this execution module.',
        )
      const callData = context.trace
        ? traceSync(context.trace, 'calls.encode', () =>
            account.encodeCalls!(parameters.calls),
          )
        : account.encodeCalls(parameters.calls)
      assertHex(callData)
      assertHex(account.stubSignature)
      const [nonce, fees, deployment] = await Promise.all([
        context.trace
          ? parameters.nonce !== undefined
            ? traceSync(context.trace, 'nonce.read', () => parameters.nonce!, {
                source: 'provided',
              })
            : traceAsync(
                context.trace,
                'nonce.read',
                (trace) =>
                  getNonce(scopeContext(context, trace), account, nonceKey),
                { source: 'rpc' },
              )
          : (parameters.nonce ?? getNonce(context, account, nonceKey)),
        estimateFeesPerGas(context, parameters),
        account.getDeployment && context.trace
          ? traceAsync(context.trace, 'deployment', (trace) =>
              account.getDeployment!(scopeContext(context, trace)),
            )
          : account.getDeployment?.(context),
      ])
      const operation: Operation = {
        sender: account.address,
        nonce: (nonceKey << 64n) | nonce,
        callData,
        ...fees,
        callGasLimit: parameters.gas ?? 0n,
        verificationGasLimit: 0n,
        preVerificationGas: 0n,
        signature: account.stubSignature,
        ...(deployment
          ? { factory: deployment.factory, factoryData: deployment.data }
          : {}),
      }
      const sponsorContext = {
        chainId: context.chain.id,
        entryPoint,
        version,
        context: parameters.sponsorContext ?? context.sponsorContext ?? {},
      }
      async function quote(
        stage: SponsorStage,
        phaseContext: Context,
        scoped = false,
      ): Promise<StubSponsorship> {
        // Finalization can run beside sender signing in a later operation.
        if (phaseContext.trace && !scoped)
          return traceAsync(
            phaseContext.trace,
            stage === 'stub' ? 'sponsor.stub' : 'sponsor.finalize',
            (trace) => quote(stage, scopeContext(phaseContext, trace), true),
          )
        if (!sponsor) throw new CetaneError('No sponsor is configured.')
        if ('request' in sponsor)
          return requestSponsorship(
            phaseContext.trace
              ? {
                  ...sponsor,
                  request: traceRequestFunction(
                    sponsor.request.bind(sponsor),
                    phaseContext.trace,
                    'sponsor',
                  ),
                }
              : sponsor,
            stage,
            toRpc(operation, version),
            entryPoint,
            phaseContext.chain.id,
            version,
            sponsorContext.context,
          )
        const callback = stage === 'stub' ? sponsor.stub : sponsor.finalize
        if (!callback)
          throw new CetaneError(
            'Sponsor must finalize its estimate or return isFinal: true.',
          )
        return parseSponsorship(
          await callback.call(
            sponsor,
            Object.freeze({ ...operation }),
            sponsorContext,
          ),
          version,
          stage,
          false,
        )
      }
      const stub = sponsor ? await quote('stub', context) : undefined
      if (stub) applySponsorship(operation, stub)
      const verificationBudget = deployment
        ? options.gas?.deploymentVerificationGasLimit
        : options.gas?.verificationGasLimit
      const canSkipEstimate =
        parameters.gas !== undefined &&
        verificationBudget !== undefined &&
        options.gas !== undefined &&
        (!operation.paymaster ||
          operation.paymasterVerificationGasLimit !== undefined)
      if (canSkipEstimate) {
        const span = context.trace
          ? beginSpan(context.trace, 'gas.budget', { source: 'configured' })
          : undefined
        try {
          operation.verificationGasLimit = verificationBudget
          operation.preVerificationGas =
            typeof options.gas!.preVerificationGas === 'function'
              ? options.gas!.preVerificationGas(Object.freeze({ ...operation }))
              : options.gas!.preVerificationGas
          word(operation.verificationGasLimit, 16)
          word(operation.preVerificationGas)
          span?.end()
        } catch (error) {
          span?.end('error')
          throw error
        }
      }
      const estimate = canSkipEstimate
        ? {
            callGasLimit: toQuantity(operation.callGasLimit),
            verificationGasLimit: toQuantity(operation.verificationGasLimit),
            preVerificationGas: toQuantity(operation.preVerificationGas),
            ...(operation.paymasterVerificationGasLimit !== undefined
              ? {
                  paymasterVerificationGasLimit: toQuantity(
                    operation.paymasterVerificationGasLimit,
                  ),
                }
              : {}),
          }
        : context.trace
          ? await traceAsync(context.trace, 'gas.estimate', (trace) =>
              scopeContext(context, trace).relay<Record<string, Hex>>({
                method: 'eth_estimateUserOperationGas',
                params: [toRpc(operation, version), entryPoint],
              }),
            )
          : await context.relay<Record<string, Hex>>({
              method: 'eth_estimateUserOperationGas',
              params: [toRpc(operation, version), entryPoint],
            })
      operation.callGasLimit =
        parameters.gas ?? fromQuantity(estimate.callGasLimit)
      operation.verificationGasLimit = fromQuantity(
        estimate.verificationGasLimit,
      )
      operation.preVerificationGas = fromQuantity(estimate.preVerificationGas)
      if (operation.paymaster) {
        const verification =
          estimate.paymasterVerificationGasLimit === undefined
            ? operation.paymasterVerificationGasLimit
            : fromQuantity(estimate.paymasterVerificationGasLimit)
        if (verification === undefined)
          throw new CetaneError('Missing sponsor verification gas estimate.')
        const reservedVerification =
          operation.paymasterVerificationGasLimit ?? 0n
        operation.paymasterVerificationGasLimit =
          verification > reservedVerification
            ? verification
            : reservedVerification
        // The sponsor pays for postOp and supplies its own budget (ERC-7677).
      }
      const signedSponsorData =
        sponsor && !stub!.isFinal && version === '0.9'
          ? paymasterData(operation, version, true).toLowerCase()
          : undefined
      const parallelSponsor =
        signedSponsorData !== undefined &&
        signedSponsorData !== paymasterData(operation, version).toLowerCase()
      if (sponsor && !stub!.isFinal && !parallelSponsor) {
        const final = await quote('final', context)
        assertFinalSponsorship(operation, final)
        applySponsorship(operation, final)
      }
      const gas =
        operation.callGasLimit +
        operation.preVerificationGas +
        operation.verificationGasLimit +
        (operation.paymasterVerificationGasLimit ?? 0n) +
        (operation.paymasterPostOpGasLimit ?? 0n)
      const chainId = context.chain.id
      const hash = context.trace
        ? traceSync(context.trace, 'hash.signing', () =>
            getSigningHash(operation, chainId, entryPoint, version),
          )
        : getSigningHash(operation, chainId, entryPoint, version)
      const maxSize = context.chain.limits?.maxTransactionSize
      if (maxSize !== undefined && submissionSize(operation, version) > maxSize)
        throw new CetaneError('Transaction exceeds the chain size cap.')
      let signed: Operation | undefined
      return {
        transaction: {
          chainId,
          from: account.address,
          calls: parameters.calls,
          nonce,
          executionGas: operation.callGasLimit,
          gas,
          ...fees,
          maxFee: gas * fees.maxFeePerGas,
        },
        async sign({ signer, trace } = {}) {
          const [signature, final] = await Promise.all([
            trace
              ? traceAsync(trace, 'sign.sender', () =>
                  signTransaction(account, parameters, hash, signer),
                )
              : signTransaction(account, parameters, hash, signer),
            parallelSponsor
              ? quote('final', scopeContext(context, trace))
              : undefined,
          ])
          if (final) {
            assertFinalSponsorship(operation, final)
            applySponsorship(operation, final)
            // Only sponsor fields can change: callbacks receive frozen copies,
            // parsing excludes account fields, and the check above fixes gas.
            // Compare the exact committed bytes through the same footer parser
            // instead of hashing unchanged calls, deployment data and domain.
            if (
              context.chain.id !== chainId ||
              paymasterData(operation, version, true).toLowerCase() !==
                signedSponsorData
            )
              throw new CetaneError(
                'Sponsor changed sender-signed data during parallel authorization.',
              )
          }
          assertHex(signature)
          assertStubCoverage(
            account.stubSignature!,
            signature,
            'Account signature',
            false,
          )
          signed = { ...operation, signature }
          if (
            maxSize !== undefined &&
            submissionSize(signed, version) > maxSize
          )
            throw new CetaneError('Transaction exceeds the chain size cap.')
        },
        async submit({ trace } = {}) {
          if (!signed)
            throw new CetaneError(
              'Transaction must be signed before submission.',
            )
          const rpc = trace
            ? traceSync(trace, 'serialization', () => toRpc(signed!, version))
            : toRpc(signed, version)
          const result = await scopeContext(context, trace).relay<Hex>({
            method: 'eth_sendUserOperation',
            params: [rpc, entryPoint],
          })
          const span = trace ? beginSpan(trace, 'ack.validate') : undefined
          try {
            assertHex(result, 32)
            if (result.toLowerCase() !== hash)
              throw new CetaneError(
                'Submission endpoint returned an unexpected transaction identifier.',
              )
            span?.end()
          } catch (error) {
            span?.end('error')
            throw error
          }
          return result
        },
      }
    },
    getReceipt,
    ...(waitForReceipt ? { waitForReceipt } : {}),
  }
}
