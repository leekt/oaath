import type { TraceContext } from './trace/types.js'

export type Hex = `0x${string}`
export type Address = Hex
export type Hash = Hex
export type Awaitable<T> = T | Promise<T>
export type BlockTag = 'latest' | 'pending' | 'earliest' | 'safe' | 'finalized'
export type RpcRequest = { method: string; params?: readonly unknown[] }
export type RequestOptions = { signal?: AbortSignal }
export type Request = <T = unknown>(
  request: RpcRequest,
  options?: RequestOptions,
) => Promise<T>
export type Transport = { request: Request }
export type NativeAA = '8130' | '8141' | 'tempo'
export type ChainMetadata = Readonly<{
  chainId: number
  nativeAA: NativeAA | false | 'unknown'
}>

export type Call = {
  readonly to: Address
  readonly data?: Hex
  readonly value?: bigint
}
export type Signer = {
  /** Optional key identity; never used as the smart account's address. */
  readonly address?: Address
  sign(parameters: { hash: Hash }): Awaitable<Hex>
}
/** Public account-adapter descriptor, containing no signing capability. */
export type Authorization = { readonly id: Hex }
export type AuthorizationChange =
  | { readonly type: 'grant'; readonly authorization: Authorization }
  | { readonly type: 'revoke'; readonly authorization: Authorization }
  | {
      readonly type: 'replace'
      readonly current: Authorization
      readonly next: Authorization
    }
/** ERC-7579 module configuration; the gas budgets include that module's account-side install/uninstall work. */
export type Module = Readonly<{
  type: bigint
  address: Address
  initData: Hex
  deInitData?: Hex
  gas?: Readonly<{ enable?: bigint; disable?: bigint }>
}>
export type ModuleChange = {
  readonly type: 'enable' | 'disable'
  readonly module: Module
}
/** A sponsor service or a local fee payer, interpreted by the chain's execution module. */
export type FeePayer = {
  readonly account: Account
  readonly signer: Signer
  readonly authorization?: Authorization
}
export type Sponsor = Transport | Signer | FeePayer
export type SponsorContext = Readonly<Record<string, unknown>>
export type Deployment = { factory: Address; data: Hex }
/** Account behavior, supplied by the chain's account factory or an extension. */
export type Account = {
  readonly address: Address
  /** Read adapter identity; keeps discovery code out of the transaction send graph. */
  readonly moduleDiscovery?: {
    readonly type: 'kernel'
    readonly version: '4'
  }
  readonly signTransaction?: (parameters: {
    hash: Hash
    signer: Signer
    authorization?: Authorization
  }) => Awaitable<Hex>
  readonly getNonceKey?: (key: bigint, authorization?: Authorization) => bigint
  readonly encodeAuthorizationChanges?: (
    changes: readonly AuthorizationChange[],
    context: Context,
    parameters: TransactionParameters,
  ) => Awaitable<{ calls: readonly Call[]; gas?: bigint }>
  readonly encodeModuleChanges?: (changes: readonly ModuleChange[]) => {
    calls: readonly Call[]
    gas?: bigint
  }
  readonly encodeCalls?: (calls: readonly Call[]) => Hex
  readonly getDeployment?: (
    context: Context,
  ) => Awaitable<Deployment | undefined>
  readonly stubSignature?: Hex
}
export type AccountFactory = (parameters: {
  /** Public initialization data, independent of the signer used to send. */
  owner?: Address
  client: Client
  address?: Address
  index?: bigint
}) => Awaitable<Account>

export type Fees = { maxFeePerGas: bigint; maxPriorityFeePerGas: bigint }
export type FeeParameters = Partial<Fees> & { blockMode?: 'small' | 'big' }
export type TransactionParameters = FeeParameters & {
  account?: Account
  signer?: Signer
  authorization?: Authorization
  /** Sequence within nonceKey; execution-specific nonce packing stays internal. */
  nonce?: bigint
  nonceKey?: bigint
  /** Execution limit; reusable from estimateGas or prepared.executionGas. */
  gas?: bigint
  /** Maximum gas fee liability, in the same units as gas * maxFeePerGas. */
  maxFee?: bigint
  feeToken?: Address
  validAfter?: number
  validBefore?: number
  /** Require sponsorship, or explicitly disable the configured sponsor. */
  sponsor?: boolean
  sponsorContext?: SponsorContext
}
export type SendCallsParameters = TransactionParameters & {
  calls: readonly Call[]
}
export type SendTransactionParameters = TransactionParameters & Call
export type PreparedTransaction = Readonly<
  Fees & {
    chainId: number
    from: Address
    calls: readonly Call[]
    /** Sequence within the selected nonce key, not a protocol-packed nonce. */
    nonce: bigint
    /** Limit accepted by request `gas`, before separate validation/payer reserves. */
    executionGas: bigint
    /** Total gas reserved, including validation and data gas where applicable. */
    gas: bigint
    maxFee: bigint
    feeToken?: Address
  }
>
export type TransactionReceipt = {
  /** The identifier returned by sendTransaction/sendCalls. */
  id: Hash
  /** The actual enclosing onchain transaction. */
  transactionHash: Hash
  blockHash: Hash
  blockNumber: bigint
  status: 'success' | 'reverted'
  gasUsed: bigint
  effectiveGasPrice: bigint
  logs: readonly Log[]
}
export type Log = {
  address: Address
  data: Hex
  topics: readonly Hex[]
  blockNumber: bigint | null
  transactionHash: Hash | null
  logIndex: number | null
}
export type ExecutionPlan = {
  transaction: PreparedTransaction
  /** Local authorization, before any submission. Failure must not consume a nonce. */
  sign?(parameters?: { signer?: Signer; trace?: TraceContext }): Promise<void>
  submit(parameters?: { trace?: TraceContext }): Promise<Hash>
}
/** Execution modules own encoding, nonce semantics, signing and receipt lookup. */
export type Execution = {
  readonly nativeAA?: NativeAA
  /** Adapter permits nonce reservation before acknowledgment; endpoint support is configured separately. */
  readonly supportsNoncePipelining?: true
  /** Experimental opt-in guarantee: independent plans can authorize concurrently. */
  readonly supportsParallelSigning?: true
  prepare(
    context: Context,
    parameters: SendCallsParameters & { account: Account },
  ): Promise<ExecutionPlan>
  getReceipt(context: Context, hash: Hash): Promise<TransactionReceipt | null>
  /** Optional held receipt read. Implementations must respect the remaining wait deadline. */
  waitForReceipt?(
    context: Context,
    hash: Hash,
    parameters: { timeout: number },
  ): Promise<TransactionReceipt | null>
  getNonce(context: Context, account: Account, key: bigint): Promise<bigint>
}
export type Chain = {
  readonly id: number
  readonly name: string
  /** false explicitly disables discovery; undefined asks the client's discovery hook. */
  readonly nativeAA?: NativeAA | false
  readonly rpcUrls?: { readonly default: { readonly http: readonly string[] } }
  readonly nativeCurrency?: {
    readonly name: string
    readonly symbol: string
    readonly decimals: number
  }
  readonly blockTime?: number
  readonly pollingInterval?: number
  readonly blockMode?: 'small' | 'big'
  readonly execution?: Execution
  readonly account?: AccountFactory
  /** Explicit endpoint capability. Applies independently to each client/account/nonce key. */
  readonly submission?: {
    /** Concurrent unacknowledged submissions; >1 requires future-nonce admission. Default 1. */
    readonly maxInFlight: number
    /** Experimental parallel signing. Default 1; local failures cancel the unsubmitted suffix. */
    readonly maxSigning?: number
    /** Additional queued sends beyond that window. Default 1024 when a policy is configured. */
    readonly maxQueued?: number
  }
  readonly fees?: {
    readonly minPriorityFeePerGas?: bigint
    readonly maxPriorityFeePerGas?: bigint
    readonly maxFeePerGas?: bigint
    /** Basis points. 20_000 = twice the current base fee. */
    readonly baseFeeMultiplier?: number
    readonly estimate?: (
      context: Context,
      parameters: FeeParameters,
    ) => Promise<Fees>
  }
  readonly limits?: {
    /** Inclusive eth_getLogs window; refused ranges are bisected within the read budget. */
    readonly maxLogBlockRange?: bigint | number
    /** Reaching this cap triggers splitting to avoid accepting possibly truncated results. */
    readonly maxLogResults?: number
    readonly maxGas?: bigint
    readonly maxTransactionSize?: number
    readonly maxFee?: bigint
  }
  readonly validateCalls?: (
    calls: readonly Call[],
    parameters: TransactionParameters,
  ) => void
  readonly validateTransaction?: (
    transaction: PreparedTransaction,
    parameters: TransactionParameters,
  ) => void
  /** Runs once when a client is made, with no network work. */
  readonly setup?: (context: Context) => void
}
export type Context = {
  /** Optional operation-scoped diagnostics. No transaction payloads are emitted. */
  readonly trace?: TraceContext
  readonly chain: Chain
  readonly request: Request
  /** A submission endpoint, e.g. a bundler, separate from the execution RPC. */
  readonly relay: Request
  readonly sponsor?: Sponsor
  readonly sponsorContext?: SponsorContext
  readonly signer?: Signer
}
export type Client = Context & {
  /** One shared initialization result, including cached chain ID and native-AA capability. */
  readonly ready: Promise<ChainMetadata>
  readonly account?: Account
  readonly pollingInterval: number
  extend<const T extends object, Self extends Client>(
    this: Self,
    extension: (client: Self) => T,
  ): Self & T
}
