# Changelog

## 0.0.3 (2026-10-07)

- Add ordinary RPC-wallet submission with account binding and no automatic retry.
- Expose a frozen, identifiable built-in EVM engine for provider review.
- Add the ABI, address, digest recovery and hex utilities needed by Moesi.
- Preserve block-number pins in code reads; support code overrides and block-header capability reads.
- Add general EIP-712 hashing and serialized digest-signature recovery (#2, #3).
- Add typed, canonical calldata/event/error evidence codecs (#4).
- Add versioned packed/unpacked ERC-4337 conversion and verify local handleOps submission through it (#5).
- Add offline EIP-1559 and EIP-155 legacy signing with exact bytes/hash before broadcast (#6).
- Add budgeted, range-aware log scans and released Kernel 0.4.0 module discovery with explicit partial coverage (#1).
- Add canonical, block-hash-pinned account module inventories through `cetane/observation/modules`, including explicit completeness and adapter coverage (#8).
- Include released Kernel v4 test creation artifacts, provenance and checksums in the package for local-chain consumers.
- Replace the prerelease Kernel v4 adapter, fixtures and benchmark profiles with `version: '4'`, pinned to upstream tag `v4.0`. Export `releaseReference` for the release pin.
- Preserve null pending-block numbers instead of rejecting valid pending headers.
- Add CSPRNG-backed private-key generation and validated compressed/uncompressed SEC1 public-key address derivation (#7).
- Verify 48-byte CSPRNG requests against viem, expand adversarial and differential tests, and retain paired Bun/Node performance measurements for the new primitives.
- Pin reorg-test transaction fees so replaying the same transaction after a snapshot revert preserves its hash.
- Add a combined release check and CI, and include this changelog in the published package.

The migration is verified against independent viem vectors and local Moesi
fixtures; it makes no live-network latency or cost claim.
Shared OAAth EIP-712 vectors and mutations run through the packed public API
in Node, Bun and a browser context. Kernel discovery is tested against the
pinned 0.4.0 release, including every module category, silent root removal,
historical block pins and provider range refusals.
